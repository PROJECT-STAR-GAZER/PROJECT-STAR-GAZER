JESTER AUDIO CONVERTER v3.1 - WINDOWS INSTALL (SETUP FIX)

1. Download JesterAudio_v3_1.zip.
2. Open Windows PowerShell and run:

   cd "$HOME\Desktop\JesterAudio"
   Expand-Archive "$HOME\Downloads\JesterAudio_v3_1.zip" -DestinationPath . -Force
   .\Start-Jester.bat

3. The setup checks the Python environment, Python packages, FFmpeg,
   FFprobe and Deno. If anything is missing, follow the setup prompts.
4. The app opens. Paste a YouTube video URL and click Add links to queue.
5. Choose MP3 or WAV and click DOWNLOAD AUDIO to start.
6. Up to 5 videos can be converted in each batch.

For later starts:
   cd "$HOME\Desktop\JesterAudio"
   .\Start-Jester.bat

If the ZIP is not in Downloads, use the actual path where the browser saved it.
The app's Install / Repair button reopens the setup to update Python packages
and install missing tools. The Activity Log displays download errors.

Requires internet access and Python 3.11 or newer.
Use only with video/audio you own or have permission to download.
MP3 output at 320 kbps does not add detail beyond the original YouTube stream;
WAV is uncompressed output from the source, not restoration of lost quality.

Version 3.1 resolves the PowerShell 5.1 quoting bug in the EJS package check.
