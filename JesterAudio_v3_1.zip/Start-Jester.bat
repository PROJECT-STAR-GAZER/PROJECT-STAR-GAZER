@echo off
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Setup-Jester.ps1"
if errorlevel 1 (
    echo.
    echo Jester setup or app reported an error. Read the message above.
    pause
)
