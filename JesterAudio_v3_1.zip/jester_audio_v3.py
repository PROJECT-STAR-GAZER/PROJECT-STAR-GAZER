"""Jester Audio Converter v3 - 1 to 5 YouTube audio downloads.

Requirements: customtkinter, yt-dlp[default], FFmpeg and FFprobe; Deno recommended.
Only download media you own or are authorized to save.
"""

from __future__ import annotations

import logging
from importlib import metadata
import os
import queue
import re
import shutil
import subprocess
import sys
import threading
import time
from pathlib import Path
from tkinter import filedialog, messagebox
from urllib.parse import urlsplit

import customtkinter as ctk
from yt_dlp import YoutubeDL

MAX_JOBS = 5
BG = "#11111A"
PANEL = "#202032"
INNER = "#29293D"
TEXT = "#F3F2FA"
MUTED = "#AEAEC4"
ACCENT = "#9061F9"
SUCCESS = "#61D6AE"
ERROR = "#FF8B98"

ctk.set_appearance_mode("dark")
ctk.set_default_color_theme("blue")


def is_video_url(url: str) -> bool:
    try:
        p = urlsplit(url)
        host = (p.hostname or "").lower()
        allowed = host in {"youtu.be", "youtube.com", "www.youtube.com", "m.youtube.com", "music.youtube.com"}
        if p.scheme not in {"http", "https"} or not allowed:
            return False
        if host == "youtu.be":
            return bool(p.path.strip("/"))
        if p.path == "/watch":
            return "v=" in p.query or bool(re.search(r"(?:^|&)v=", p.query))
        return p.path.startswith(("/shorts/", "/live/", "/embed/"))
    except ValueError:
        return False



def refresh_windows_path() -> None:
    """Best-effort PATH refresh after a new winget installation."""
    if os.name != "nt":
        return
    import winreg
    fragments = []
    for root, subkey in ((winreg.HKEY_LOCAL_MACHINE, r"SYSTEM\CurrentControlSet\Control\Session Manager\Environment"),
                         (winreg.HKEY_CURRENT_USER, r"Environment")):
        try:
            with winreg.OpenKey(root, subkey) as key:
                val, _ = winreg.QueryValueEx(key, "Path")
                fragments.append(os.path.expandvars(val))
        except OSError:
            pass
    if fragments:
        existing = os.environ.get("PATH", "")
        os.environ["PATH"] = os.pathsep.join(fragments + [existing])

def find_ffmpeg_dir() -> Path | None:
    """Locate both executables, including common winget folders missed by PATH."""
    ffmpeg, ffprobe = shutil.which("ffmpeg"), shutil.which("ffprobe")
    if ffmpeg and ffprobe:
        # If installed separately, PATH itself works for yt-dlp.
        return Path(ffmpeg).parent if Path(ffmpeg).parent == Path(ffprobe).parent else Path("")

    locations = [
        Path.home() / "AppData/Local/Microsoft/WinGet/Packages",
        Path(os.environ.get("PROGRAMFILES", "C:/Program Files")) / "ffmpeg",
        Path("C:/ffmpeg"),
        Path.home() / "scoop/apps/ffmpeg/current",
        Path.home() / "AppData/Local/Programs/ffmpeg",
        Path(sys.executable).resolve().parent,
    ]
    for root in locations:
        if not root.exists():
            continue
        try:
            candidates = [root / "bin" / "ffmpeg.exe", root / "ffmpeg.exe"]
            if "WinGet" in str(root) or "scoop" in str(root):
                candidates.extend(root.glob("**/bin/ffmpeg.exe"))
            for ff in candidates:
                probe = ff.with_name("ffprobe.exe")
                if ff.is_file() and probe.is_file():
                    return ff.parent
        except (OSError, PermissionError):
            continue
    return None


def detect_js_runtime() -> tuple[str, str] | None:
    # Deno is the preferred runtime for yt-dlp. Node requires explicit enablement.
    for name in ("deno",):
        exe = shutil.which(name)
        if not exe and name == "deno":
            for candidate in (Path.home() / ".deno/bin/deno.exe",
                              Path.home() / "AppData/Local/Microsoft/WinGet/Links/deno.exe"):
                if candidate.is_file():
                    exe = str(candidate)
                    break
        if exe:
            return name, exe
    return None


def human_size(number: float | int | None) -> str:
    if number is None:
        return ""
    n = float(number)
    for unit in ("B", "KB", "MB", "GB"):
        if n < 1024 or unit == "GB":
            return f"{n:.1f} {unit}" if unit != "B" else f"{n:.0f} B"
        n /= 1024
    return ""


def find_finished_audio(directory: Path, video_id: str, ext: str) -> Path | None:
    # Avoid glob's special treatment of [brackets] in our file names.
    suffix = f" [{video_id}].{ext}".lower()
    for file in directory.iterdir():
        if file.is_file() and file.name.lower().endswith(suffix):
            return file
    return None


class UILogger:
    def __init__(self, events: queue.Queue, job_id: int) -> None:
        self.events = events
        self.job_id = job_id

    def debug(self, message: str) -> None:
        # yt-dlp sends normal diagnostic output here too; show warnings/errors only.
        if message.startswith("[debug]"):
            logging.debug("%s", message)

    def warning(self, message: str) -> None:
        self.events.put(("log", f"Warning: {message}"))
        logging.warning("%s", message)

    def error(self, message: str) -> None:
        self.events.put(("log", f"Error: {message}"))
        logging.error("%s", message)


class JesterAudio(ctk.CTk):
    def __init__(self) -> None:
        super().__init__()
        self.title("Jester Audio Converter v3")
        self.geometry("880x800")
        self.minsize(690, 660)
        self.configure(fg_color=BG)
        self.jobs: list[dict] = []
        self.rows: dict[int, dict] = {}
        self.next_id = 1
        self.running = False
        self.events: queue.Queue = queue.Queue()
        self.completed = 0
        self.failed = 0
        self.active_progress = 0.0
        self.folder = Path.home() / "Music"
        if not self.folder.is_dir():
            self.folder = Path.home() / "Downloads"
        self.ffmpeg_dir: Path | None = None
        self.js_runtime: tuple[str, str] | None = None
        self.ejs_ready = False
        self.repairing = False
        self.build_ui()
        self.check_dependencies()
        self.after(100, self.handle_events)
        self.protocol("WM_DELETE_WINDOW", self.close_app)

    def build_ui(self) -> None:
        outer = ctk.CTkFrame(self, fg_color="transparent")
        outer.pack(fill="both", expand=True, padx=20, pady=14)
        ctk.CTkLabel(outer, text="JESTER AUDIO", font=("Segoe UI", 28, "bold"), text_color=TEXT).pack(anchor="w")
        ctk.CTkLabel(outer, text="YouTube audio to MP3 / WAV  ·  Maximum 5 videos per batch", font=("Segoe UI", 12), text_color=MUTED).pack(anchor="w", pady=(0, 12))

        input_panel = ctk.CTkFrame(outer, fg_color=PANEL, corner_radius=13)
        input_panel.pack(fill="x", pady=(0, 9))
        ctk.CTkLabel(input_panel, text="STEP 1  ·  Paste up to five links (one per line)", font=("Segoe UI", 13, "bold")).pack(anchor="w", padx=14, pady=(12, 6))
        self.link_input = ctk.CTkTextbox(input_panel, height=65, font=("Segoe UI", 12), fg_color="#151520", wrap="word")
        self.link_input.pack(fill="x", padx=14)
        input_actions = ctk.CTkFrame(input_panel, fg_color="transparent")
        input_actions.pack(fill="x", padx=14, pady=9)
        self.count_label = ctk.CTkLabel(input_actions, text="0 / 5 in queue", text_color=MUTED)
        self.count_label.pack(side="left")
        self.add_btn = ctk.CTkButton(input_actions, text="+ Add links to queue", command=self.add_links, width=170, fg_color=ACCENT, hover_color="#7445DA")
        self.add_btn.pack(side="right")

        options = ctk.CTkFrame(outer, fg_color=PANEL, corner_radius=13)
        options.pack(fill="x", pady=(0, 9))
        opt_top = ctk.CTkFrame(options, fg_color="transparent")
        opt_top.pack(fill="x", padx=14, pady=(10, 5))
        ctk.CTkLabel(opt_top, text="STEP 2  ·  Select audio format", font=("Segoe UI", 13, "bold")).pack(side="left")
        self.format_select = ctk.CTkSegmentedButton(opt_top, values=["MP3", "WAV"], fg_color="#13131E", selected_color=ACCENT, selected_hover_color="#7445DA", width=220)
        self.format_select.set("MP3")
        self.format_select.pack(side="right")
        ctk.CTkLabel(options, text="Best source audio  ·  MP3: 320 kbps encoding  ·  WAV: uncompressed (not lossless restoration)", font=("Segoe UI", 11), text_color=MUTED).pack(anchor="w", padx=14)
        dest_row = ctk.CTkFrame(options, fg_color="transparent")
        dest_row.pack(fill="x", padx=14, pady=(7, 11))
        self.folder_label = ctk.CTkLabel(dest_row, text=f"Save to: {self.folder}", text_color="#DBDAEC", anchor="w", font=("Segoe UI", 11))
        self.folder_label.pack(side="left", fill="x", expand=True)
        self.folder_btn = ctk.CTkButton(dest_row, text="Choose folder", width=100, fg_color="#45445F", command=self.select_folder)
        self.folder_btn.pack(side="right")

        action = ctk.CTkFrame(outer, fg_color=PANEL, corner_radius=13)
        action.pack(fill="x", pady=(0, 10))
        ctk.CTkLabel(action, text="STEP 3  ·  Click Download to start", font=("Segoe UI", 13, "bold")).pack(anchor="w", padx=14, pady=(11, 5))
        self.download_btn = ctk.CTkButton(action, text="▶  DOWNLOAD AUDIO (0/5)", height=44, font=("Segoe UI", 15, "bold"), command=self.start_downloads, fg_color=ACCENT, hover_color="#7445DA")
        self.download_btn.pack(fill="x", padx=14, pady=(0, 8))
        self.stage_label = ctk.CTkLabel(action, text="Waiting for links. Downloads start ONLY after you click the button.", text_color=MUTED, anchor="w", font=("Segoe UI", 11), wraplength=760)
        self.stage_label.pack(fill="x", padx=14)
        self.global_bar = ctk.CTkProgressBar(action, height=10, progress_color=SUCCESS, fg_color="#45455A")
        self.global_bar.pack(fill="x", padx=14, pady=(5, 12))
        self.global_bar.set(0)

        header = ctk.CTkFrame(outer, fg_color="transparent")
        header.pack(fill="x", pady=(0, 5))
        ctk.CTkLabel(header, text="Download queue", font=("Segoe UI", 15, "bold")).pack(side="left")
        self.clear_btn = ctk.CTkButton(header, text="Clear queue", width=95, command=self.clear_queue, fg_color="#45445F")
        self.clear_btn.pack(side="right")
        self.queue_list = ctk.CTkScrollableFrame(outer, fg_color=PANEL, height=160, corner_radius=12)
        self.queue_list.pack(fill="both", expand=True)
        self.display_jobs()

        dependencies = ctk.CTkFrame(outer, fg_color="transparent")
        dependencies.pack(fill="x", pady=(8, 0))
        self.tools_label = ctk.CTkLabel(dependencies, text="Checking download tools...", text_color=MUTED, font=("Segoe UI", 11), anchor="w")
        self.tools_label.pack(side="left", fill="x", expand=True)
        ctk.CTkButton(dependencies, text="Recheck", width=75, height=27, command=self.check_dependencies, fg_color="#45445F").pack(side="right", padx=(8, 0))
        self.repair_btn = ctk.CTkButton(dependencies, text="Install / Repair", width=107, height=27, command=self.repair_dependencies, fg_color=ACCENT)
        self.repair_btn.pack(side="right")

        self.log_box = ctk.CTkTextbox(outer, height=80, fg_color="#181824", text_color="#D4D3E7", font=("Consolas", 10), wrap="word")
        self.log_box.pack(fill="x", pady=(8, 0))
        self.log_box.configure(state="disabled")
        footer = ctk.CTkFrame(outer, fg_color="transparent")
        footer.pack(fill="x", pady=(5, 0))
        ctk.CTkLabel(footer, text="Only download videos you own or have permission to save.", text_color=MUTED, font=("Segoe UI", 10)).pack(side="left")
        ctk.CTkButton(footer, text="Open folder", command=self.open_folder, width=100, height=26, fg_color="#45445F").pack(side="right")

    def log(self, message: str) -> None:
        stamp = time.strftime("%H:%M:%S")
        self.log_box.configure(state="normal")
        self.log_box.insert("end", f"[{stamp}] {message}\n")
        self.log_box.see("end")
        self.log_box.configure(state="disabled")
        logging.info("%s", message)

    def check_dependencies(self) -> None:
        # Refresh to find winget-installed tools in an app opened before a PATH update.
        if os.name == "nt":
            refresh_windows_path()
        self.ffmpeg_dir = find_ffmpeg_dir()
        self.js_runtime = detect_js_runtime()
        try:
            metadata.version("yt-dlp-ejs")
            self.ejs_ready = True
        except metadata.PackageNotFoundError:
            self.ejs_ready = False
        ff = "FFmpeg + FFprobe ✓" if self.ffmpeg_dir is not None else "FFmpeg/FFprobe ✗"
        js = "Deno ✓" if self.js_runtime and self.js_runtime[0] == "deno" else "Deno ✗"
        ejs = "EJS ✓" if self.ejs_ready else "EJS ✗"
        ready = self.ffmpeg_dir is not None and bool(self.js_runtime and self.js_runtime[0] == "deno") and self.ejs_ready
        self.tools_label.configure(text=f"Python packages ✓  |  {ff}  |  {js}  |  {ejs}", text_color=SUCCESS if ready else ERROR)
        if ready:
            self.log("All download dependencies are ready.")
        else:
            self.log("Missing a dependency. Click 'Install / Repair' below, or run Start-Jester.bat.")

    def repair_dependencies(self) -> None:
        if self.running or self.repairing:
            return
        if os.name != "nt":
            messagebox.showinfo("Windows setup", "The guided bootstrapper is made for Windows.")
            return
        bootstrap = Path(__file__).resolve().with_name("Setup-Jester.ps1")
        if not bootstrap.exists():
            messagebox.showerror("Bootstrapper not found", "Setup-Jester.ps1 must be in the same folder as this Python file. Extract the whole ZIP.")
            return
        if not messagebox.askyesno("Install / Repair", "This opens a PowerShell setup window. It can update Python packages and install missing FFmpeg or Deno using winget. Continue?"):
            return
        try:
            flags = getattr(subprocess, "CREATE_NEW_CONSOLE", 0)
            command = ["powershell.exe", "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", str(bootstrap), "-InstallOnly"]
            proc = subprocess.Popen(command, cwd=str(bootstrap.parent), creationflags=flags)
            self.repairing = True
            self.repair_btn.configure(state="disabled", text="Repair running...")
            self.log("Setup opened. Follow the PowerShell prompts; the tools will be rechecked when it finishes.")
            threading.Thread(target=self.wait_for_repair, args=(proc,), daemon=True).start()
        except Exception as exc:
            messagebox.showerror("Could not start setup", str(exc))

    def wait_for_repair(self, proc: subprocess.Popen) -> None:
        code = proc.wait()
        self.events.put(("repair_finished", code))

    def add_links(self) -> None:
        if self.running:
            return
        content = self.link_input.get("1.0", "end").strip()
        if not content:
            messagebox.showinfo("No links", "Paste one or more YouTube video URLs first.")
            return
        incoming = content.split()
        if any(not is_video_url(link) for link in incoming):
            messagebox.showwarning("Invalid URL", "Use YouTube video URLs (watch, Shorts or youtu.be), one per line. Playlist-only URLs aren't supported.")
            return
        existing = {item["url"] for item in self.jobs}
        new = []
        for link in incoming:
            if link not in existing:
                new.append(link)
                existing.add(link)
        if len(self.jobs) + len(new) > MAX_JOBS:
            messagebox.showwarning("5 video limit", f"You already have {len(self.jobs)} link(s). You can add at most {MAX_JOBS - len(self.jobs)} more.")
            return
        if not new:
            messagebox.showinfo("Already queued", "Those URLs are already in your queue.")
            return
        for link in new:
            self.jobs.append({"id": self.next_id, "url": link, "title": link, "status": "Queued", "progress": 0.0, "file": None})
            self.next_id += 1
        self.link_input.delete("1.0", "end")
        self.display_jobs()
        self.refresh_count()
        self.stage_label.configure(text=f"{len(self.jobs)} link(s) queued. Click DOWNLOAD AUDIO to begin.")
        self.log(f"Added {len(new)} link(s). Ready to download.")

    def refresh_count(self) -> None:
        n = len(self.jobs)
        self.count_label.configure(text=f"{n} / {MAX_JOBS} in queue")
        if not self.running:
            self.download_btn.configure(text=f"▶  DOWNLOAD AUDIO ({n}/5)")

    def display_jobs(self) -> None:
        for child in self.queue_list.winfo_children():
            child.destroy()
        self.rows.clear()
        if not self.jobs:
            ctk.CTkLabel(self.queue_list, text="Nothing queued yet. Paste a YouTube link above and click Add.", text_color=MUTED).pack(pady=45)
            return
        for idx, job in enumerate(self.jobs, 1):
            outer = ctk.CTkFrame(self.queue_list, fg_color=INNER, corner_radius=9)
            outer.pack(fill="x", padx=5, pady=4)
            title_row = ctk.CTkFrame(outer, fg_color="transparent")
            title_row.pack(fill="x", padx=10, pady=(7, 0))
            title = ctk.CTkLabel(title_row, text=f"{idx}. {job['title'][:92]}", text_color=TEXT, font=("Segoe UI", 11, "bold"), anchor="w")
            title.pack(side="left", fill="x", expand=True)
            remove = ctk.CTkButton(title_row, text="Remove", width=70, height=25, fg_color="#624254", hover_color="#88495D", command=lambda job_id=job["id"]: self.remove_job(job_id))
            remove.pack(side="right", padx=(8, 0))
            status = ctk.CTkLabel(outer, text=job["status"], font=("Segoe UI", 11), text_color=MUTED, anchor="w")
            status.pack(fill="x", padx=10)
            bar = ctk.CTkProgressBar(outer, height=6, progress_color=ACCENT, fg_color="#444459")
            bar.set(job["progress"])
            bar.pack(fill="x", padx=10, pady=(3, 9))
            if self.running:
                remove.configure(state="disabled")
            self.rows[job["id"]] = {"title": title, "status": status, "bar": bar, "remove": remove}

    def remove_job(self, job_id: int) -> None:
        if self.running:
            return
        self.jobs = [job for job in self.jobs if job["id"] != job_id]
        self.display_jobs()
        self.refresh_count()
        self.global_bar.set(0)
        self.stage_label.configure(text="Queue updated. Click DOWNLOAD AUDIO to start.")

    def clear_queue(self) -> None:
        if self.running:
            return
        self.jobs.clear()
        self.display_jobs()
        self.refresh_count()
        self.global_bar.set(0)
        self.stage_label.configure(text="Queue cleared. Add links to continue.")

    def select_folder(self) -> None:
        folder = filedialog.askdirectory(initialdir=str(self.folder), title="Select your downloads folder")
        if folder:
            self.folder = Path(folder)
            self.folder_label.configure(text=f"Save to: {self.folder}")

    def open_folder(self) -> None:
        try:
            if os.name == "nt":
                os.startfile(str(self.folder))
            elif sys.platform == "darwin":
                subprocess.Popen(["open", str(self.folder)])
            else:
                subprocess.Popen(["xdg-open", str(self.folder)])
        except Exception as exc:
            messagebox.showerror("Folder error", str(exc))

    def toggle_running(self, value: bool) -> None:
        self.running = value
        state = "disabled" if value else "normal"
        for widget in (self.link_input, self.add_btn, self.folder_btn, self.clear_btn, self.format_select):
            widget.configure(state=state)
        for row in self.rows.values():
            row["remove"].configure(state=state)
        self.download_btn.configure(state=state, text=("DOWNLOADING..." if value else f"▶  DOWNLOAD AUDIO ({len(self.jobs)}/5)"))

    def start_downloads(self) -> None:
        if self.running:
            return
        if not self.jobs:
            messagebox.showinfo("No videos queued", "Paste a link and click Add links to queue first.")
            return
        self.check_dependencies()
        if self.ffmpeg_dir is None:
            messagebox.showerror("FFmpeg missing", "MP3 and WAV need both ffmpeg.exe and ffprobe.exe.\n\nRun this in PowerShell:\nwinget install -e --id Gyan.FFmpeg\n\nThen restart PowerShell and the app.")
            self.stage_label.configure(text="Cannot start: FFmpeg and FFprobe are missing. See tool status below.")
            return
        if not (self.js_runtime and self.js_runtime[0] == "deno") or not self.ejs_ready:
            messagebox.showerror("YouTube support missing", "A compatible Deno runtime and yt-dlp-ejs are recommended for reliable YouTube downloads.\n\nClick Install / Repair, then try again.")
            return
        if not self.folder.is_dir():
            messagebox.showerror("Output folder missing", "Please choose an existing folder.")
            return
        if not os.access(self.folder, os.W_OK):
            messagebox.showerror("Output folder", "The selected folder is not writable.")
            return
        self.completed = 0
        self.failed = 0
        self.active_progress = 0
        for job in self.jobs:
            job.update(status="Waiting to start...", progress=0.0, file=None)
        fmt = self.format_select.get().lower()
        snapshot = [(job["id"], job["url"]) for job in self.jobs]
        self.display_jobs()
        self.toggle_running(True)
        self.global_bar.set(0)
        self.stage_label.configure(text=f"Starting download 1 of {len(snapshot)} as {fmt.upper()}...")
        self.log(f"DOWNLOAD clicked. Starting {len(snapshot)} video(s), output: {fmt.upper()}.")
        worker = threading.Thread(target=self.download_worker, args=(snapshot, fmt, self.folder, self.ffmpeg_dir, self.js_runtime), daemon=True)
        worker.start()

    def download_worker(self, items: list[tuple[int, str]], fmt: str, folder: Path, ffmpeg_dir: Path, js: tuple[str, str] | None) -> None:
        for number, (job_id, url) in enumerate(items, 1):
            self.events.put(("phase", number, f"Reading video information ({number}/{len(items)})..."))
            self.events.put(("job", job_id, None, "Getting video information...", 0.01))
            try:
                previous = [0.0]

                def progress_hook(data: dict) -> None:
                    if data.get("status") == "downloading":
                        now = time.monotonic()
                        if now - previous[0] < 0.12:
                            return
                        previous[0] = now
                        total = data.get("total_bytes") or data.get("total_bytes_estimate")
                        bytes_now = data.get("downloaded_bytes", 0)
                        fraction = min(1.0, bytes_now / total) if total else 0.02
                        speed = data.get("speed")
                        message = f"Downloading audio: {fraction:.0%}"
                        if speed:
                            message += f" · {human_size(speed)}/s"
                        if data.get("eta") is not None:
                            message += f" · ETA {data['eta']}s"
                        self.events.put(("job", job_id, None, message, 0.02 + fraction * 0.91))
                    elif data.get("status") == "finished":
                        self.events.put(("job", job_id, None, "Audio downloaded. Preparing conversion...", 0.94))

                def postprocess_hook(data: dict) -> None:
                    status = data.get("status")
                    if status == "started":
                        self.events.put(("job", job_id, None, f"Converting audio to {fmt.upper()}...", 0.96))
                    elif status == "finished":
                        self.events.put(("job", job_id, None, "Finishing file...", 0.99))

                options = {
                    "format": "bestaudio/best",
                    "noplaylist": True,
                    "ignoreerrors": False,
                    "quiet": True,
                    "no_warnings": False,
                    "logger": UILogger(self.events, job_id),
                    "outtmpl": str(folder / "%(title).100s [%(id)s].%(ext)s"),
                    "windowsfilenames": True,
                    "overwrites": False,
                    "continuedl": True,
                    "retries": 3,
                    "fragment_retries": 3,
                    "socket_timeout": 25,
                    "progress_hooks": [progress_hook],
                    "postprocessor_hooks": [postprocess_hook],
                    "postprocessors": [{"key": "FFmpegExtractAudio", "preferredcodec": fmt, **({"preferredquality": "320"} if fmt == "mp3" else {})}],
                }
                # Path('.') means the tools were found on PATH in different folders.
                if ffmpeg_dir != Path(""):
                    options["ffmpeg_location"] = str(ffmpeg_dir)
                if js is not None:
                    options["js_runtimes"] = {js[0]: {"path": js[1]}}
                with YoutubeDL(options) as ydl:
                    info = ydl.extract_info(url, download=True)
                if not isinstance(info, dict):
                    raise RuntimeError("YouTube returned no video information")
                video_id = str(info.get("id") or "")
                file = find_finished_audio(folder, video_id, fmt) if video_id else None
                if not file:
                    raise RuntimeError(f"Conversion finished but the .{fmt} file was not found in the selected folder")
                title = str(info.get("title") or "Audio")
                self.events.put(("job", job_id, title, f"✓ Saved: {file.name}", 1.0))
                self.events.put(("log", f"Saved: {file}"))
                self.events.put(("tally", True))
            except Exception as exc:
                full = str(exc).strip().replace("\n", " ") or type(exc).__name__
                short = re.sub(r"^ERROR:\s*", "", full)
                self.events.put(("job", job_id, None, f"FAILED: {short[:180]}", 0))
                self.events.put(("log", f"Download {number} failed: {full}"))
                self.events.put(("tally", False))
        self.events.put(("finished",))

    def handle_events(self) -> None:
        try:
            while True:
                event = self.events.get_nowait()
                kind = event[0]
                if kind == "job":
                    _, job_id, title, status, fraction = event
                    job = next((j for j in self.jobs if j["id"] == job_id), None)
                    if job is None:
                        continue
                    if title:
                        job["title"] = title
                    job["status"], job["progress"] = status, fraction
                    row = self.rows.get(job_id)
                    if row:
                        if title:
                            position = self.jobs.index(job) + 1
                            row["title"].configure(text=f"{position}. {title[:92]}")
                        row["status"].configure(text=status, text_color=(ERROR if status.startswith("FAILED:") else SUCCESS if status.startswith("✓") else MUTED))
                        row["bar"].set(fraction)
                    self.active_progress = fraction
                    if self.jobs:
                        self.global_bar.set(min(1.0, (self.completed + self.failed + fraction) / len(self.jobs)))
                    if status.startswith("Downloading") or status.startswith("Converting"):
                        self.stage_label.configure(text=status)
                elif kind == "phase":
                    self.active_progress = 0.0
                    self.stage_label.configure(text=event[2])
                    self.log(event[2])
                elif kind == "tally":
                    if event[1]:
                        self.completed += 1
                    else:
                        self.failed += 1
                    self.active_progress = 0
                    self.global_bar.set((self.completed + self.failed) / len(self.jobs))
                elif kind == "log":
                    self.log(event[1])
                elif kind == "repair_finished":
                    self.repairing = False
                    self.repair_btn.configure(state="normal", text="Install / Repair")
                    self.check_dependencies()
                    self.log(f"Bootstrapper exited with code {event[1]}." + (" Tools checked again." if event[1] == 0 else " Read the PowerShell setup output."))
                elif kind == "finished":
                    self.toggle_running(False)
                    result = f"Finished: {self.completed} saved, {self.failed} failed."
                    self.stage_label.configure(text=result + " Check the queue and activity log below.")
                    self.log(result)
                    if self.failed:
                        messagebox.showwarning("Downloads finished", result + " Read the failure details in the queue or log.")
                    else:
                        messagebox.showinfo("Downloads finished", result + " Click Open folder to find your audio.")
        except queue.Empty:
            pass
        if self.winfo_exists():
            self.after(100, self.handle_events)

    def close_app(self) -> None:
        if self.running:
            if not messagebox.askyesno("Download in progress", "Downloads are running. Closing will stop the app and may leave partial files. Exit anyway?"):
                return
        self.destroy()


def main() -> None:
    try:
        base = Path(__file__).resolve().parent
        logging.basicConfig(filename=str(base / "jester_audio.log"), level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s", encoding="utf-8")
    except OSError:
        logging.basicConfig(level=logging.INFO)
    JesterAudio().mainloop()


if __name__ == "__main__":
    main()
