﻿param([switch]$InstallOnly)

$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath $PSScriptRoot
Write-Host ''
Write-Host '===============================' -ForegroundColor Cyan
Write-Host ' JESTER AUDIO - SETUP CHECK v3.1' -ForegroundColor Cyan
Write-Host '===============================' -ForegroundColor Cyan
Write-Host "Project folder: $PSScriptRoot"
Write-Host ''

function Refresh-Path {
    $machine = [Environment]::GetEnvironmentVariable('Path', 'Machine')
    $user = [Environment]::GetEnvironmentVariable('Path', 'User')
    $env:Path = "$machine;$user;$env:Path"
}

function Has-Tool([string] $name) {
    return $null -ne (Get-Command $name -ErrorAction SilentlyContinue)
}

function Ask-Install([string] $name) {
    $answer = Read-Host "$name is missing. Install with winget? [Y/n]"
    return [string]::IsNullOrWhiteSpace($answer) -or $answer.Trim().ToLower() -eq 'y'
}

function Install-Tool([string] $display, [string] $id) {
    if (-not (Has-Tool 'winget.exe')) {
        Write-Warning "Windows Package Manager (winget) is unavailable. Please install $display manually."
        return
    }
    if (Ask-Install $display) {
        Write-Host "Installing $display with winget..." -ForegroundColor Yellow
        & winget.exe install -e --id $id --accept-package-agreements --accept-source-agreements
        if ($LASTEXITCODE -ne 0) {
            Write-Warning "winget returned code $LASTEXITCODE while installing $display."
        }
        Refresh-Path
    } else {
        Write-Warning "Skipped $display. The converter might not work until it is installed."
    }
}

try {
    $python = Join-Path $PSScriptRoot '.venv\Scripts\python.exe'
    if (-not (Test-Path -LiteralPath $python)) {
        Write-Host 'Creating local Python environment...' -ForegroundColor Yellow
        if (Has-Tool 'py.exe') {
            & py.exe -3 -m venv (Join-Path $PSScriptRoot '.venv')
        } elseif (Has-Tool 'python.exe') {
            & python.exe -m venv (Join-Path $PSScriptRoot '.venv')
        } else {
            throw 'Python was not found. Install Python 3.11 or newer, then run Start-Jester.bat again.'
        }
        if ($LASTEXITCODE -ne 0 -or -not (Test-Path -LiteralPath $python)) {
            throw 'Could not create the Python virtual environment.'
        }
    }
    Write-Host '[OK] Python virtual environment' -ForegroundColor Green

    # On Windows PowerShell 5.1, nested double quotes in python -c can be stripped.
    # Check importable modules and the EJS distribution separately without nested quotes.
    & $python -c 'import customtkinter, yt_dlp, PIL'
    $importsOK = $LASTEXITCODE -eq 0
    & $python -m pip show yt-dlp-ejs | Out-Null
    $ejsOK = $LASTEXITCODE -eq 0
    $modulesMissing = -not ($importsOK -and $ejsOK)
    if ($InstallOnly -or $modulesMissing) {
        Write-Host 'Installing/updating Python packages, including the YouTube EJS solver...' -ForegroundColor Yellow
        & $python -m pip install --upgrade 'yt-dlp[default]' customtkinter pillow
        if ($LASTEXITCODE -ne 0) {
            throw 'Python package installation failed. Check your internet connection and pip output.'
        }
        & $python -c 'import customtkinter, yt_dlp, PIL'
        if ($LASTEXITCODE -ne 0) { throw 'One or more required Python modules failed to import.' }
        & $python -m pip show yt-dlp-ejs | Out-Null
        if ($LASTEXITCODE -ne 0) { throw 'yt-dlp-ejs was not found in the active Python environment.' }
    }
    Write-Host '[OK] customtkinter, Pillow, yt-dlp and yt-dlp-ejs' -ForegroundColor Green

    Refresh-Path
    if ((Has-Tool 'ffmpeg.exe') -and (Has-Tool 'ffprobe.exe')) {
        Write-Host '[OK] FFmpeg and FFprobe' -ForegroundColor Green
    } else {
        Install-Tool 'FFmpeg / FFprobe' 'Gyan.FFmpeg'
    }
    Refresh-Path
    if (Has-Tool 'deno.exe') {
        Write-Host '[OK] Deno' -ForegroundColor Green
    } else {
        Install-Tool 'Deno' 'DenoLand.Deno'
    }
    Refresh-Path

    Write-Host ''
    foreach ($tool in @('ffmpeg.exe', 'ffprobe.exe', 'deno.exe')) {
        if (Has-Tool $tool) {
            Write-Host "[OK] $tool" -ForegroundColor Green
        } else {
            Write-Warning "$tool is not currently available on PATH. The app will also search common winget folders."
        }
    }
    Write-Host ''
    if ($InstallOnly) {
        Write-Host 'Setup/repair complete. Return to Jester Audio and click Recheck.' -ForegroundColor Cyan
        exit 0
    }

    $app = Join-Path $PSScriptRoot 'jester_audio_v3.py'
    if (-not (Test-Path -LiteralPath $app)) {
        throw "The application file was not found: $app. Extract the entire JesterAudio_v3.zip first."
    }
    Write-Host 'Launching Jester Audio Converter v3...' -ForegroundColor Cyan
    & $python $app
    if ($LASTEXITCODE -ne 0) { throw "The app exited with status $LASTEXITCODE." }
} catch {
    Write-Host ''
    Write-Host "SETUP ERROR: $_" -ForegroundColor Red
    exit 1
}
