"""Create a synthetic offline TCP/HTTP training PCAP; never sends network traffic.

All addresses are reserved for documentation and all credentials are fictional.
The traffic is intentionally plaintext to demonstrate risk detection in a lab.
"""
from __future__ import annotations

import ipaddress
from pathlib import Path
import struct


def checksum(raw: bytes) -> int:
    if len(raw) % 2:
        raw += b'\0'
    words = struct.unpack('!' + 'H' * (len(raw) // 2), raw)
    total = sum(words)
    while total >> 16:
        total = (total & 0xFFFF) + (total >> 16)
    return (~total) & 0xFFFF


def frame(src: str, dst: str, sport: int, dport: int, seq: int, ack: int, payload: bytes,
          flags: int = 0x18) -> bytes:
    src_ip = ipaddress.IPv4Address(src).packed
    dst_ip = ipaddress.IPv4Address(dst).packed
    tcp_header = struct.pack('!HHIIHHHH', sport, dport, seq, ack, (5 << 12) | flags, 65535, 0, 0)
    pseudo = src_ip + dst_ip + struct.pack('!BBH', 0, 6, len(tcp_header) + len(payload))
    tcp_sum = checksum(pseudo + tcp_header + payload)
    tcp_header = struct.pack('!HHIIHHHH', sport, dport, seq, ack, (5 << 12) | flags, 65535, tcp_sum, 0)
    ip_header = struct.pack('!BBHHHBBH4s4s', 0x45, 0, 20 + len(tcp_header) + len(payload), 0x1234, 0, 64, 6, 0, src_ip, dst_ip)
    ip_sum = checksum(ip_header)
    ip_header = struct.pack('!BBHHHBBH4s4s', 0x45, 0, 20 + len(tcp_header) + len(payload), 0x1234, 0, 64, 6, ip_sum, src_ip, dst_ip)
    ethernet_header = bytes.fromhex('0200000000020200000000010800')
    return ethernet_header + ip_header + tcp_header + payload


def generate(path: Path) -> int:
    client='192.0.2.25'; server='198.51.100.10'
    port=54001
    password=b'jester123'
    body=b'username=jester&password=' + password
    req=(b'POST /lab-login HTTP/1.1\r\nHost: synthetic.invalid\r\n'
         b'Content-Type: application/x-www-form-urlencoded\r\n'
         + f'Content-Length: {len(body)}\r\n\r\n'.encode() + body)
    resp=(b'HTTP/1.1 200 OK\r\nSet-Cookie: session=jw9fj29fj29f; Path=/\r\n'
          b'Content-Length: 0\r\n\r\n')
    items=[]
    items.append(frame(client,server,port,80,1000,0,b'',0x02))
    items.append(frame(server,client,80,port,5000,1001,b'',0x12))
    items.append(frame(client,server,port,80,1001,5001,b'',0x10))
    c1,c2,c3=req[:43],req[43:94],req[94:]
    items.append(frame(client,server,port,80,1001,5001,c1))
    # Out-of-order on purpose: third part arrives before second.
    items.append(frame(client,server,port,80,1001+len(c1)+len(c2),5001,c3))
    items.append(frame(client,server,port,80,1001+len(c1),5001,c2))
    # Retransmitted request fragment should be ignored.
    items.append(frame(client,server,port,80,1001+len(c1),5001,c2))
    r1,r2=resp[:38],resp[38:]
    items.append(frame(server,client,80,port,5001,1001+len(req),r1))
    items.append(frame(server,client,80,port,5001+len(r1),1001+len(req),r2))
    with path.open('wb') as f:
        f.write(struct.pack('<IHHIIII', 0xA1B2C3D4, 2, 4, 0, 0, 65535, 1))
        for i, payload in enumerate(items):
            f.write(struct.pack('<IIII', 1732000000+i, 0, len(payload), len(payload)))
            f.write(payload)
    return len(items)

if __name__ == '__main__':
    out=Path(__file__).with_name('synthetic_split_login.pcap')
    n=generate(out)
    print(f'Created {out.name} with {n} synthetic Ethernet/TCP packets; nothing sent over network.')
