"""Extra app/engine smoke checks on a host without Scapy or Npcap."""
import sys
import types
from pathlib import Path

base = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(base))
scapy = types.ModuleType('scapy'); scapy.__path__=[]
a = types.ModuleType('scapy.all')

class IP: pass
class IPv6: pass
class TCP: pass
class UDP: pass
class Raw: pass
class DNS: pass
class DNSQR: pass
class ARP: pass
class ICMP: pass

for cls in [IP, IPv6, TCP, UDP, Raw, DNS, DNSQR, ARP, ICMP]:
    setattr(a, cls.__name__, cls)
class NoPacketCapture: pass
for name in ('PcapReader','AsyncSniffer'):
    setattr(a, name, NoPacketCapture)
a.get_if_list = lambda: []
a.conf = types.SimpleNamespace(iface='stub', ifaces={})
sys.modules['scapy'] = scapy
sys.modules['scapy.all'] = a

import engine
from plans import build_plan, build_overview_plan
from streams import HTTPStreamReassembler

class FakeLayer:
    def __init__(self, **values):
        self.__dict__.update(values)

class Packet:
    def __init__(self, src='192.0.2.22', dst='198.51.100.30', sport=55555, dport=80, seq=0, flags=0x18, data=None, t=1):
        self.layers = {IP: FakeLayer(src=src, dst=dst), TCP: FakeLayer(sport=sport,dport=dport,seq=seq,flags=flags)}
        if data is not None:
            self.layers[Raw] = FakeLayer(load=data)
        self.time = t
    def __contains__(self, item):
        return item in self.layers
    def __getitem__(self, item):
        return self.layers[item]


def test_engine():
    detector=engine.Detector()
    secret=b'never-show-this-password-123'
    body=b'username=example&password='+secret
    request=(b'POST /signin HTTP/1.1\r\nHost: safe.test\r\nCookie: session=private-cookie-value\r\n'
             + f'Content-Length: {len(body)}\r\nContent-Type: application/x-www-form-urlencoded\r\n\r\n'.encode() + body)
    detector.analyze(Packet(seq=999,flags=0x02,data=None))
    chunks=[request[:45],request[45:79],request[79:110],request[110:]]
    findings=[];seq=1000
    for i, part in enumerate(chunks):
        found=detector.analyze(Packet(seq=seq, data=part,t=2+i))
        findings.extend(found)
        seq+=len(part)
    assert detector.http_message_count==1,detector.http_message_count
    assert any(f.category=='Credential Leaks' for f in findings)
    assert any(f.category=='Session/Cookie Risks' for f in findings)
    assert any(f.title=='HTTP POST request' for f in findings)
    joined=str([f.to_dict() for f in findings])
    assert secret.decode() not in joined and 'private-cookie-value' not in joined and 'example' not in joined
    assert any('TCP reconstruction: 4' in evidence for finding in findings for evidence in finding.evidence)
    plan=build_plan(next(f for f in findings if f.category=='Credential Leaks'),stage='Lab',elaborate=True)
    assert 'Validation and remediation checklist' in plan and 'Credential reuse' in plan
    overview=build_overview_plan(findings,stage='Lab',elaborate=True,packet_count=5,adapter='Ethernet')
    assert 'reassembled' in overview and 'PRIORITY' in overview
    print('PASS: engine detects split login and cookie indicators, no secret values in findings/plans')

if __name__ == '__main__':
    test_engine()
    # Validate UI opens and plan buttons still work with simulated capture backend.
    import tkinter as tk
    from tkinter import filedialog
    from app import JesterWireApp
    # Demo uses Scapy packet constructors, replace with synthetic fake findings here.
    engine.demo_findings=lambda: ([engine.Finding('Credential Leaks','HIGH','Possible cleartext login data','Synthetic example',
                   '192.0.2.1','198.51.100.1','HTTP','12:00',('TCP reconstruction: 3 data segment(s)',))],3)
    import app
    app.demo_findings=engine.demo_findings
    ui=JesterWireApp();ui.withdraw();ui.update()
    assert 'v0.7' in ui.title()
    assert 'http' in ui.stat_labels
    ui.open_overview_plan();ui.update()
    windows=[w for w in ui.winfo_children() if isinstance(w,tk.Toplevel)]
    assert len(windows)==1
    assert 'Full Report' in windows[0].title()
    windows[0].destroy()
    # v0.3 JSON still loads
    filedialog.askopenfilename=lambda **kwargs: '/mnt/data/test scan 2.json'
    ui.open_report();ui.update()
    assert len(ui.findings)==104
    ui.open_overview_plan();ui.update()
    windows=[w for w in ui.winfo_children() if isinstance(w,tk.Toplevel)]
    assert len(windows)==1
    windows[0].destroy()
    ui.destroy()
    print('PASS: v0.5 GUI, full plan, v0.3 JSON import')

# Process the actual bundled PCAP bytes using a tiny stdlib Ethernet/IPv4/TCP
# decoder; this checks the exact fixture without depending on Scapy installation.
import struct
import ipaddress

def verify_bundled_pcap():
    path=base/'examples'/'synthetic_split_login.pcap'
    data=path.read_bytes()
    assert struct.unpack_from('<I', data, 0)[0] == 0xA1B2C3D4
    offset=24; d=engine.Detector(); all_findings=[]; records=0
    while offset < len(data):
        sec,usec,inc,original=struct.unpack_from('<IIII',data,offset)
        offset+=16
        f=data[offset:offset+inc]
        offset+=inc
        assert f[12:14]==b'\x08\x00'
        ip=f[14:]
        src=str(ipaddress.IPv4Address(ip[12:16]))
        dst=str(ipaddress.IPv4Address(ip[16:20]))
        tcp=ip[(ip[0]&0xF)*4:]
        sport,dport,seq,ack,flagsword=struct.unpack_from('!HHIIH',tcp,0)
        header_len=((flagsword >> 12)&15)*4
        payload=tcp[header_len:]
        p=Packet(src=src,dst=dst,sport=sport,dport=dport,seq=seq,flags=flagsword&0x1FF,
                 data=payload if payload else None,t=sec+usec*0.000001)
        all_findings.extend(d.analyze(p))
        records+=1
    assert records==9, records
    assert d.http_message_count==2,d.http_message_count
    assert d.streams.out_of_order>=1
    assert d.streams.retransmissions>=1
    assert any(f.category=='Credential Leaks' for f in all_findings)
    assert any(f.category=='Session/Cookie Risks' for f in all_findings)
    assert 'fictional-lab-only-123' not in str([f.to_dict() for f in all_findings])
    assert 'fictional-cookie' not in str([f.to_dict() for f in all_findings])
    print('PASS: bundled nine-packet PCAP reconstructed into two HTTP messages and redacted findings')

verify_bundled_pcap()
