"""Standard-library tests for the TShark command bridge (no Wireshark required)."""
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

sys.path.insert(0,str(Path(__file__).resolve().parent.parent))
import tshark_bridge as bridge


class TSharkBridgeTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.path=Path(self.tmp.name)/'test.pcap'
        self.path.write_bytes(b'PCAP-FOR-MOCK-ONLY')
    def tearDown(self):
        self.tmp.cleanup()
    def test_packet_list_and_filter(self):
        sample='"5"\t"0.12"\t"192.0.2.1"\t""\t"192.0.2.2"\t""\t"TCP"\t"65"\t"3"\t"5000"\t"80"\t""\t""\t"GET /index HTTP/1.1"\n'
        with patch.object(bridge, 'locate_tshark',return_value='tshark'), patch.object(subprocess,'run',return_value=subprocess.CompletedProcess([],0,sample.encode(),b'')) as run:
            rows,status=bridge.list_packets(self.path,'tcp',100)
        self.assertEqual(len(rows),1)
        self.assertEqual(rows[0].stream,3)
        self.assertEqual(rows[0].source_port,'5000')
        self.assertIn('matching packets',status)
        args=run.call_args.args[0]
        self.assertIn('-Y',args)
        self.assertIn('tcp',args)
        self.assertIn('-T',args)
    def test_detail_and_hex_are_different_modes(self):
        with patch.object(bridge,'locate_tshark',return_value='tshark'), patch.object(subprocess,'run',return_value=subprocess.CompletedProcess([],0,b'Protocol Details\n',b'')) as run:
            output=bridge.packet_details(self.path,5)
            self.assertIn('Protocol Details',output)
            self.assertIn('-V',run.call_args.args[0])
            bridge.packet_details(self.path,5,True)
            self.assertIn('-x',run.call_args.args[0])
    def test_follow_stream_is_standard_tshark(self):
        with patch.object(bridge,'locate_tshark',return_value='tshark'), patch.object(subprocess,'run',return_value=subprocess.CompletedProcess([],0,b'Follow: tcp,ascii\n',b'')) as run:
            self.assertIn('Follow:',bridge.follow_tcp(self.path,9))
            self.assertIn('follow,tcp,ascii,9',run.call_args.args[0])
    def test_invalid_capture_and_stream_rejected(self):
        with self.assertRaises(bridge.TSharkError):
            bridge.list_packets(self.path.with_suffix('.txt'))
        with self.assertRaises(bridge.TSharkError):
            bridge.follow_tcp(self.path,-1)
    def test_bad_filter_not_shell_command(self):
        with self.assertRaises(bridge.TSharkError):
            bridge.list_packets(self.path,'tcp\nmalformed')
    def test_missing_tshark_message(self):
        with patch.object(bridge,'locate_tshark',return_value=None):
            with self.assertRaisesRegex(bridge.TSharkError,'Install Wireshark'):
                bridge.list_packets(self.path)
    def test_tshark_failure_visible(self):
        with patch.object(bridge,'locate_tshark',return_value='tshark'), patch.object(subprocess,'run',return_value=subprocess.CompletedProcess([],1,b'',b'Invalid filter')):
            with self.assertRaisesRegex(bridge.TSharkError,'Invalid filter'):
                bridge.list_packets(self.path,'badfilter')


if __name__=='__main__': unittest.main()
