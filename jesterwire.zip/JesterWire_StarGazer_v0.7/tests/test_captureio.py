from datetime import datetime
from pathlib import Path
import struct
import pytest
from captureio import CaptureWriter, default_capture_dir, duplicate_pcap, suggested_filename


class MiniPcapWriter:
    """Stub PCAP writer using stdlib, to test PCAP persistence without Npcap."""
    def __init__(self, name, append=False, sync=False):
        self.file = open(name,'wb')
        self.file.write(struct.pack('<IHHIIII',0xa1b2c3d4,2,4,0,0,65535,1))
    def write(self,payload):
        data=bytes(payload)
        self.file.write(struct.pack('<IIII',123,456,len(data),len(data)))
        self.file.write(data)
    def close(self):
        self.file.close()


def test_writer_recording_and_copy(tmp_path):
    path=tmp_path/'capture.pcap'
    writer=CaptureWriter(path, writer_factory=MiniPcapWriter)
    writer.start()
    writer.write(b'abc')
    writer.write(b'xyz')
    writer.close()
    writer.close()
    raw=path.read_bytes()
    assert raw[:4]==bytes.fromhex('d4c3b2a1')
    assert writer.packet_count==2
    assert b'abc' in raw and b'xyz' in raw
    assert len(raw)==24 + (16+3)*2
    duplicate_pcap(path,tmp_path/'copy.pcap')
    assert path.read_bytes()==(tmp_path/'copy.pcap').read_bytes()
    with pytest.raises(FileExistsError):
        CaptureWriter(path,writer_factory=MiniPcapWriter).start()


def test_writer_failure_and_path_handling(tmp_path):
    with pytest.raises(ValueError):
        CaptureWriter(tmp_path/'capture.pcapng',writer_factory=MiniPcapWriter).start()
    path=tmp_path/'capture.pcap'
    writer=CaptureWriter(path,writer_factory=MiniPcapWriter)
    writer.start();writer.close()
    with pytest.raises(ValueError):
        duplicate_pcap(path,tmp_path/'copy.pcapng')
    with pytest.raises(ValueError):
        duplicate_pcap(path,path)
    assert default_capture_dir(tmp_path).name=='Captures'
    assert suggested_filename(datetime(2026,11,19,17,30,20))=='JesterWire_20261119_173020.pcap'
