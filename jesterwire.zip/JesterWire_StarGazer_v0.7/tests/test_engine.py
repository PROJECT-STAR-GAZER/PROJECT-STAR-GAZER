from scapy.all import IP, Raw, TCP
from engine import Detector, demo_findings
from plans import build_plan


def make_packet(raw: bytes):
    return IP(src="192.0.2.5", dst="198.51.100.10") / TCP(sport=41000, dport=80) / Raw(load=raw)


def test_credential_values_never_displayed():
    secret = "supersecret-PASSWORD-6789"
    packet = make_packet(("POST /login HTTP/1.1\r\nContent-Type: application/x-www-form-urlencoded\r\n\r\n"
                          "username=alice&password=" + secret).encode())
    findings = Detector().analyze(packet)
    assert any(f.category == "Credential Leaks" for f in findings)
    assert all(secret not in str(f.to_dict()) for f in findings)
    assert all("alice" not in str(f.to_dict()) for f in findings)


def test_cookie_values_redacted():
    secret = "session-XYZ-2345"
    packet = make_packet(("GET /home HTTP/1.1\r\nCookie: sid=" + secret + "\r\n\r\n").encode())
    results = Detector().analyze(packet)
    assert any(f.category == "Session/Cookie Risks" for f in results)
    assert all(secret not in str(f.to_dict()) for f in results)


def test_syn_burst_detection():
    detector = Detector()
    results = []
    for port in range(1000, 1009):
        pkt = IP(src="203.0.113.1", dst="192.0.2.25") / TCP(dport=port, flags="S")
        pkt.time = float(port)
        results.extend(detector.analyze(pkt))
    assert any(f.category == "Possible Intrusion" for f in results)


def test_demo_and_plan():
    findings, packets = demo_findings()
    assert packets >= 10
    cats = {f.category for f in findings}
    assert {"Credential Leaks", "Session/Cookie Risks", "Possible Intrusion", "Network Traffic"} <= cats
    for item in findings:
        plan = build_plan(item)
        assert item.title in plan
        assert "Authorized Pentest Assessment Plan" in plan
        assert "example-not-real" not in str(item.to_dict())
