"""GUI smoke using a fake Scapy and fake TShark backend."""
import sys,types,pathlib, tempfile,time
from unittest.mock import patch
base=pathlib.Path(__file__).resolve().parent.parent
sys.path.insert(0,str(base))
scapy=types.ModuleType('scapy'); scapy.__path__=[]
a=types.ModuleType('scapy.all')
for n in ['IP','IPv6','TCP','UDP','Raw','DNS','DNSQR','ARP','ICMP']:
    setattr(a,n,type(n,(),{}))
a.PcapReader=object;a.AsyncSniffer=object;a.get_if_list=lambda:[]
a.conf=types.SimpleNamespace(iface='none',ifaces={})
sys.modules['scapy']=scapy;sys.modules['scapy.all']=a
import engine,app,tkinter as tk
import tshark_bridge as bridge
engine.demo_findings=lambda: ([],0)
app.demo_findings=engine.demo_findings
ui=app.JesterWireApp();ui.withdraw();ui.update()
assert ui.title().startswith('JesterWire v0.7')
with tempfile.TemporaryDirectory() as tmp:
    path=pathlib.Path(tmp)/'synthetic.pcap'
    path.write_bytes(b'placeholder')
    row=bridge.PacketRow(1,'0.001','192.0.2.1','192.0.2.2','TCP','128','5001','80',0,'Synthetic test')
    with patch('tshark_bridge.tshark_version',return_value='TShark test'),\
        patch('tshark_explorer.tshark_version',return_value='TShark test'),\
        patch('tshark_explorer.list_packets',return_value=([row],'1 packet displayed')),\
        patch('tshark_explorer.packet_details',return_value='Fake TCP decoded detail'),\
        patch('tshark_explorer.follow_tcp',return_value='Fake TCP conversation'):
        ui.active_pcap_path=str(path)
        ui.open_tshark_explorer();ui.update()
        from tshark_explorer import TSharkExplorer
        windows=[w for w in ui.winfo_children() if isinstance(w,TSharkExplorer)]
        assert len(windows)==1,windows
        popup=windows[0]
        for _ in range(80):
            ui.update();time.sleep(.02)
            if popup.rows:break
        assert len(popup.rows)==1, popup.status_var.get()
        popup.table.selection_set('1');popup.on_selection()
        popup.show_packet(False)
        for _ in range(80):
            ui.update();time.sleep(.02)
            if 'Fake TCP decoded detail' in popup.detail.get('1.0','end'):break
        assert 'Fake TCP decoded detail' in popup.detail.get('1.0','end')
        popup.show_stream()
        for _ in range(80):
            ui.update();time.sleep(.02)
            if 'Fake TCP conversation' in popup.stream_text.get('1.0','end'):break
        assert 'Fake TCP conversation' in popup.stream_text.get('1.0','end')
        popup.filter_stream_packets()
        assert popup.filter_var.get()=='tcp.stream == 0'
        popup._selected=row
        popup.launch_plan();ui.update()
        plans=[w for w in ui.winfo_children() if isinstance(w,tk.Toplevel) and 'Pentest' in w.title()]
        assert len(plans)==1
        plans[0].destroy()
        popup.destroy()
ui.destroy()
print('PASS: JesterWire TShark Explorer opens, lists, filters, dissects, follows TCP.')
