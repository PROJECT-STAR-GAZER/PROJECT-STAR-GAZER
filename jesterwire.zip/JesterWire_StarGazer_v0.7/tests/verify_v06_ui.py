"""GUI smoke test on a machine without Npcap or Scapy."""
import sys, types, pathlib, tempfile, struct, time
base=pathlib.Path(__file__).resolve().parent.parent
sys.path.insert(0,str(base))
scapy=types.ModuleType('scapy'); scapy.__path__=[]
a=types.ModuleType('scapy.all')
for name in ['IP','IPv6','TCP','UDP','Raw','DNS','DNSQR','ARP','ICMP']:
    setattr(a,name,type(name,(),{}))
a.get_if_list=lambda: []
a.conf=types.SimpleNamespace(iface='none',ifaces={})

class FakePacket:
    time=123.0
    def __contains__(self, item):return False
    def __getitem__(self,item):raise KeyError(item)
    def __bytes__(self):return b'fake-packet-test'

class FakeSniffer:
    def __init__(self, iface, prn, store=False, **kw):
        self.prn=prn; self.iface=iface; self.options=kw;self.running=False
    def start(self):
        self.running=True
        self.prn(FakePacket());self.prn(FakePacket())
    def stop(self,join=True):
        self.running=False

class FakePcapReader:
    def __init__(self,path):self.path=path
    def __enter__(self):return self
    def __exit__(self,*args):return None
    def __iter__(self):return iter([FakePacket(),FakePacket()])

class FakePcapWriter:
    def __init__(self,path,append=False,sync=False):
        self.out=open(path,'wb');self.out.write(struct.pack('<IHHIIII',0xa1b2c3d4,2,4,0,0,65535,1))
    def write(self,packet):
        data=bytes(packet)
        self.out.write(struct.pack('<IIII',123,0,len(data),len(data)));self.out.write(data)
    def close(self):self.out.close()

a.AsyncSniffer=FakeSniffer
a.PcapReader=FakePcapReader
a.PcapWriter=FakePcapWriter
sys.modules['scapy']=scapy;sys.modules['scapy.all']=a
import engine, app
from tkinter import filedialog, messagebox
from interfaces import Adapter
engine.demo_findings=lambda:([],0)
app.demo_findings=engine.demo_findings
import tkinter as tk
ui=app.JesterWireApp();ui.withdraw();ui.update()
assert ui.title().startswith('JesterWire v0.7')
with tempfile.TemporaryDirectory() as tmp:
    target=pathlib.Path(tmp)/'capture.pcap'
    filedialog.asksaveasfilename=lambda **kw:str(target)
    messagebox.askyesno=lambda *args,**kw:True
    messagebox.showinfo=lambda *args,**kw:None
    messagebox.showerror=lambda *args,**kw:print("ERROR MESSAGE",args,flush=True)
    ui.interface_choices={'fake':types.SimpleNamespace(capture_name='fake0',medium='Wired (Ethernet)')}
    ui.interface_var.set('fake')
    ui.focus_ip_var.set('192.0.2.1')
    ui.start_live();ui.update()
    assert ui.mode=='LIVE CAPTURE',ui.mode
    assert ui.capture_writer.packet_count==2
    assert ui.sniffer.options['filter']=='host 192.0.2.1'
    ui.stop_live()
    for _ in range(100):
        ui.update()
        if ui.mode=='CAPTURE STOPPED':break
        time.sleep(.01)
    assert ui.mode=='CAPTURE STOPPED',(ui.mode,ui.status.cget('text'))
    assert target.is_file() and target.stat().st_size==24+2*(16+len(b'fake-packet-test'))
    assert ui.capture_writer is None
    ui.open_last_capture()
    for _ in range(100):
        ui.update()
        if not ui.worker_running:break
        time.sleep(.01)
    assert ui.packet_count==2
    assert ui.active_pcap_path==str(target)
    ui.explore_traffic();ui.update()
    windows=[w for w in ui.winfo_children() if isinstance(w,tk.Toplevel)]
    assert len(windows)==1
    windows[0].destroy()
    ui.open_overview_plan();ui.update()
    windows=[w for w in ui.winfo_children() if isinstance(w,tk.Toplevel)]
    assert len(windows)==1
    windows[0].destroy()
    report=pathlib.Path(tmp)/'report.json'
    filedialog.asksaveasfilename=lambda **kw:str(report)
    # Report exporting works even when no heuristic findings were emitted.
    ui.export_report()
    import json
    assert report.exists()
    exported=json.loads(report.read_text(encoding='utf-8'))
    assert exported['packet_count']==2
    assert exported['pcap_filename']=='capture.pcap'
    assert exported['protocol_counts']['Other link-layer traffic']==2
    # Copy the recorded PCAP using the visible button.
    copy=pathlib.Path(tmp)/'capture_copy.pcap'
    filedialog.asksaveasfilename=lambda **kw:str(copy)
    ui.save_capture_copy()
    assert copy.read_bytes()==target.read_bytes()
ui.destroy()
print('PASS: GUI live capture writes PCAP, stops, reopens recording, shows Explorer and plan, copies raw file')
