"""GUI smoke of the new evidence explorer with a fake Scapy import."""
import sys, types, pathlib
base=pathlib.Path(__file__).resolve().parent.parent
sys.path.insert(0,str(base))
scapy=types.ModuleType('scapy');scapy.__path__=[]
a=types.ModuleType('scapy.all')
for name in ['IP','IPv6','TCP','UDP','Raw','DNS','DNSQR','ARP','ICMP']:
    setattr(a,name,type(name,(),{}))
a.PcapReader=object;a.AsyncSniffer=object;a.get_if_list=lambda:[]
a.conf=types.SimpleNamespace(iface='none',ifaces={})
sys.modules['scapy']=scapy;sys.modules['scapy.all']=a
import engine, app
engine.demo_findings=lambda: ([],0)
app.demo_findings=engine.demo_findings
import tkinter as tk
from tkinter import filedialog
ui=app.JesterWireApp();ui.withdraw();ui.update()
ui.detector.http_observations=[dict(time='10:00',type='Request',method='GET',route='/health',status='',source='192.0.2.10',source_port=5000,destination='192.0.2.20',destination_port=80,segments=1,header_names=['host'],content_type='Not specified',body_bytes_seen=0,body_complete=True,cookie_header=False,set_cookie_header=False,authorization_header=False)]
ui.detector.tcp_flows={('fake',):dict(a='192.0.2.10',a_port=5000,b='192.0.2.20',b_port=80,packets=4,payload_bytes=100,syn=1,syn_ack=1,rst=0,fin=0,initiator='192.0.2.10',target='192.0.2.20',target_port=80)}
ui.detector.dns_observations=[dict(source='192.0.2.10',destination='192.0.2.53',domain='example.test',count=1)]
ui.explore_traffic();ui.update()
windows=[w for w in ui.winfo_children() if isinstance(w,tk.Toplevel)]
assert len(windows)==1
assert 'Evidence Explorer' in windows[0].title()
windows[0].destroy()
# The actual old v0.4 report has no retained http_observations; GUI must not claim it does.
filedialog.askopenfilename=lambda **kwargs: '/mnt/data/test 3.json'
ui.open_report();ui.update()
assert len(ui.findings)==196
assert ui.mode=='REPORT REVIEW'
assert ui.loaded_summary['http']==[]
ui.explore_traffic();ui.update()
windows=[w for w in ui.winfo_children() if isinstance(w,tk.Toplevel)]
assert len(windows)==1
windows[0].destroy()
ui.destroy()
print('PASS: Evidence Explorer opens with real metadata and handles v0.4 JSON without inventing metadata.')
