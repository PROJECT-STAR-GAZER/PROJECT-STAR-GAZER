"""No Scapy or capture privileges required: pure TCP reassembly checks."""
from streams import HTTPStreamReassembler, MAX_FLOWS

SRC = ("192.0.2.12", 54320, "198.51.100.20", 80)
REV = ("198.51.100.20", 80, "192.0.2.12", 54320)


def send(r, key, seq, payload=b"", flags=0x18, t=1.0):
    return r.push(key, seq, flags, payload, t)


def test_header_and_body_split_at_arbitrary_byte_boundaries():
    r = HTTPStreamReassembler()
    body = b"username=demo&password=lab-only"
    raw = (b"POST /login HTTP/1.1\r\nHost: test.invalid\r\nCookie: demo=fictional\r\n"
           + f"Content-Length: {len(body)}\r\nContent-Type: application/x-www-form-urlencoded\r\n\r\n".encode() + body)
    seq = 1000
    assert send(r, SRC, seq - 1, flags=0x02) == []
    packets = [raw[:2], raw[2:31], raw[31:48], raw[48:96], raw[96:-6], raw[-6:]]
    got = []
    for piece in packets:
        got.extend(send(r, SRC, seq, piece))
        seq += len(piece)
    assert len(got) == 1
    assert got[0].payload == raw
    assert got[0].body_complete
    assert got[0].segments == len(packets)
    assert r.messages == 1


def test_out_of_order_and_retransmission_no_duplicate_messages():
    r = HTTPStreamReassembler()
    a = b"GET /page HTTP/1.1\r\nHost: "
    b = b"safe.invalid\r\nCookie: x=fictional\r\n\r\n"
    send(r, SRC, 199, flags=0x02)
    assert send(r, SRC, 200 + len(a), b) == []
    out = send(r, SRC, 200, a)
    assert len(out) == 1 and out[0].payload == a + b
    assert send(r, SRC, 200 + len(a), b) == []
    assert r.out_of_order >= 1 and r.retransmissions >= 1


def test_missing_tcp_segment_does_not_report_false_safe_message():
    r = HTTPStreamReassembler()
    send(r, SRC, 9, flags=0x02)
    a = b"POST /login HTTP/1.1\r\nContent-Length: 8\r\n\r\n"
    send(r, SRC, 10, a)
    assert send(r, SRC, 10 + len(a) + 5, b"789") == []
    assert r.messages == 0
    out = send(r, SRC, 10 + len(a), b"12345")
    assert len(out) == 1
    assert out[0].payload.endswith(b"12345789")


def test_request_response_direction_kept_separate():
    r = HTTPStreamReassembler()
    req = b"GET / HTTP/1.1\r\nHost: example.invalid\r\n\r\n"
    resp = b"HTTP/1.1 302 Found\r\nSet-Cookie: sid=fictional; Secure\r\nContent-Length: 0\r\n\r\n"
    assert len(send(r, SRC, 100, req)) == 1
    assert len(send(r, REV, 900, resp)) == 1
    assert r.messages == 2


def test_binary_tls_not_decoded_as_http():
    r = HTTPStreamReassembler()
    data = b"\x16\x03\x03\x00\x10" + b"examplepayload"
    assert send(r, SRC, 10, data) == []
    assert r.messages == 0


def test_many_flows_evicted_before_memory_growth():
    r = HTTPStreamReassembler()
    for i in range(MAX_FLOWS + 30):
        key = ("192.0.2.1", 1024 + i, "198.51.100.10", 80)
        send(r, key, 10, b"POST /abc HTTP/1.1\r\n")
    assert r.active_flows <= MAX_FLOWS
    assert r.dropped_flows >= 1


def test_large_body_is_not_buffered():
    r = HTTPStreamReassembler()
    raw = b"POST /upload HTTP/1.1\r\nContent-Length: 9999999\r\n\r\n" + b"abc"
    out = send(r, SRC, 1, raw)
    assert len(out) == 1
    assert not out[0].body_complete
    assert len(out[0].payload) < 100


def test_chunked_body_reports_headers_only():
    r = HTTPStreamReassembler()
    raw = (b"POST / HTTP/1.1\r\nTransfer-Encoding: chunked\r\n"
           b"Cookie: x=synthetic\r\n\r\n5\r\nhello\r\n0\r\n\r\n")
    result = send(r, SRC, 1, raw)
    assert len(result) == 1
    assert b"Cookie:" in result[0].payload
    assert b"hello" not in result[0].payload
    assert not result[0].body_complete
