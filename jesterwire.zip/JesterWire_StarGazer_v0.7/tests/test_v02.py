from engine import Detector, Finding
from plans import build_plan
from interfaces import Adapter, enumerate_adapters, infer_medium, adapter_explanation
from scapy.all import IP, TCP, Raw


def test_readable_adapters_and_capture_name():
    class MockIface:
        name = "Wi-Fi"
        description = "Intel(R) Wireless-AC 8265"
        network_name = "\\\\Device\\NPF_{12345678-1234-1234-1234-123456789012}"
        guid = "{12345678-1234-1234-1234-123456789012}"
    raw = MockIface.network_name
    choices = enumerate_adapters([raw], [MockIface()], windows={})
    assert len(choices) == 1
    assert choices[0].capture_name == raw
    assert choices[0].medium == "Wireless (Wi-Fi)"
    assert "Wi-Fi" in choices[0].label
    assert "monitor-mode" in adapter_explanation(choices[0])


def test_types_not_simplistic_access_labels():
    assert infer_medium("Ethernet") == "Wired (Ethernet)"
    assert infer_medium("Ethernet", "Hyper-V Virtual Ethernet Adapter") == "Virtual/VPN"
    assert infer_medium("Npcap Loopback") == "Loopback"
    assert infer_medium("Ambiguous Driver") == "Unknown"


def test_elaborate_attack_risks_without_sensitive_values():
    finding = Finding("Session/Cookie Risks", "MEDIUM", "Cookie transmitted over HTTP",
                      "A cookie header was observed.", "192.0.2.25", "198.51.100.10",
                      "HTTP", "12:00:00", ("Cookie header present",))
    plan = build_plan(finding, "Lab", elaborate=True)
    assert "Session hijacking" in plan
    assert "synthetic tokens" in plan
    assert "How to evaluate safely" in plan
    assert "lab" in plan.lower()
    assert "Lab" in plan
    assert "not evidence" in plan.lower()
    external = build_plan(finding, "External")
    assert "passive" in external.lower()
    assert "outside" in external.lower()


def test_http_response_details_and_request_headers():
    request = IP(src="192.0.2.1", dst="192.0.2.2") / TCP(dport=80) / Raw(load=b"GET / HTTP/1.1\r\nCookie: x=test-secret\r\n\r\n")
    response = IP(src="192.0.2.2", dst="192.0.2.1") / TCP(sport=80) / Raw(load=b"HTTP/1.1 200 OK\r\nSet-Cookie: sid=secret-test\r\n\r\n")
    findings = Detector().analyze(request) + Detector().analyze(response)
    assert any(f.title == "HTTP response observed" for f in findings)
    assert any("Cookie header: present" in f.evidence for f in findings)
    assert all("test-secret" not in str(f.to_dict()) and "secret-test" not in str(f.to_dict()) for f in findings)
