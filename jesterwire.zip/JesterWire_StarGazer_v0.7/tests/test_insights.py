from insights import summarize_http_message, grouped_dns, safe_path, summarize_legacy_findings


def test_sensitive_values_not_persisted():
    sample = (b'POST /signin?password=supersecret HTTP/1.1\r\nHost: example.test\r\n'
              b'Cookie: sess=REAL-COOKIE\r\nAuthorization: Bearer REAL-TOKEN\r\n'
              b'Content-Type: application/x-www-form-urlencoded\r\n\r\nusername=alice&password=REAL-PASSWORD')
    row = summarize_http_message(sample,'192.0.2.1',43211,'198.51.100.3',80,'10:00',4,True)
    rendered = str(row)
    for secret in ('supersecret', 'REAL-COOKIE', 'REAL-TOKEN', 'alice','REAL-PASSWORD'):
        assert secret not in rendered
    assert row['method'] == 'POST'
    assert row['route'] == '/signin'
    assert 'authorization' in row['header_names']
    assert row['cookie_header'] is True
    assert row['body_bytes_seen'] > 0
    assert row['segments'] == 4


def test_response_sanitization_and_flags():
    result=summarize_http_message(b'HTTP/1.1 200 OK\r\nSet-Cookie: sid=myverysecretcookie\r\nContent-Length: 0\r\n\r\n',
        '198.51.100.3',80,'192.0.2.1',43211,'10:01',1,True)
    assert result['type'] == 'Response' and result['status'] == '200'
    assert result['set_cookie_header'] is True
    assert 'myverysecretcookie' not in str(result)


def test_safe_path_removes_query_and_opaque_ids():
    assert safe_path('/portal/?token=abcdef') == '/portal/'
    assert '[segment hidden]' in safe_path('/reset/7f8cb498ad78430d7fee922a1a9b74d3')
    assert safe_path('https://example.com/a') == '[non-origin-form target]'


def test_dns_group_and_old_json():
    rows = grouped_dns([{'domain':'example.local','source':'a','count':1},
        {'domain':'example.local','source':'b','count':1}])
    assert rows[0]['count'] == 2 and 'a' in rows[0]['sources']
    legacy = summarize_legacy_findings([{'title':'DNS lookup observed','protocol':'DNS',
        'evidence':['Requested domain: test.local']}])
    assert legacy['domains']['test.local'] == 1
