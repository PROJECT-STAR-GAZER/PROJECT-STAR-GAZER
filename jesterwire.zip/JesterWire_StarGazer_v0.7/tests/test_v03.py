from engine import Finding
from plans import build_overview_plan


def test_full_plan_with_no_findings():
    result = build_overview_plan([], "Internal", True)
    assert "No events have been loaded" in result
    assert "Full Capture" in result


def test_full_plan_from_scan_categories():
    sample = [
        Finding("Network Traffic", "INFO", "DNS lookup observed", "DNS discovery", "192.0.2.1", "224.0.0.251", "DNS", "10:00"),
        Finding("Network Traffic", "INFO", "HTTP GET request", "HTTP message", "192.0.2.1", "192.0.2.2", "HTTP", "10:01"),
        Finding("Network Traffic", "INFO", "TCP connection attempt", "SYN", "192.0.2.1", "192.0.2.2", "TCP", "10:01"),
    ]
    result = build_overview_plan(sample, stage="Lab", elaborate=True, packet_count=11981, adapter="Wired (Ethernet)")
    assert "11,981" in result
    assert "HTTP GET request: 1" in result
    assert "A SYN alone does not establish" in result
    assert "Tor onion services" in result
    assert "illegal" in result.lower()


def test_full_plan_with_credential_indicator():
    sample = [Finding("Credential Leaks", "MEDIUM", "Password field detected", "HTTP plain-text field name", "192.0.2.1", "192.0.2.2", "HTTP", "10:00")]
    result = build_overview_plan(sample)
    assert "PRIORITY" in result
    assert "disposable accounts" in result
    assert "password" in result.lower()
