@echo off
setlocal
cd /d "%~dp0"
py -3 -m venv .venv
if errorlevel 1 (
  echo Python 3 was not found. Install Python then rerun this file.
  pause
  exit /b 1
)
.venv\Scripts\python.exe -m pip install --upgrade pip
.venv\Scripts\python.exe -m pip install -r requirements.txt
if errorlevel 1 (
  echo Package installation failed. See error above.
  pause
  exit /b 1
)
echo.
echo Setup complete. Run launch_windows.bat to start JesterWire.
echo For TShark Explorer, install Wireshark and include the TShark command-line component.
echo For LIVE capture, install Npcap from https://npcap.com and use an authorized adapter.
pause
