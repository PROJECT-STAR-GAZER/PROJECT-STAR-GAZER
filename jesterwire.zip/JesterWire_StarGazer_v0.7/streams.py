"""Bounded, passive TCP payload reconstruction for HTTP/1.x detection.

This module is intentionally stdlib-only, making its behavior testable without
packet-capture privileges. Raw bytes exist transiently in memory. Findings must
never include secrets or full payloads. Not a replacement for Wireshark's
advanced TCP analysis: capture gaps, connection reuse, HTTP/2, and encrypted
traffic have important limitations.
"""
from __future__ import annotations

from collections import OrderedDict
from dataclasses import dataclass, field

MAX_FLOWS = 256
MAX_PENDING = 48
MAX_STREAM_BYTES = 128 * 1024
MAX_HEADER_BYTES = 16 * 1024
MAX_MESSAGE_BODY = 64 * 1024
FLOW_TIMEOUT = 120.0
METHODS = (b"GET ", b"POST ", b"PUT ", b"PATCH ", b"DELETE ", b"HEAD ", b"OPTIONS ")
RESPONSES = (b"HTTP/1.0 ", b"HTTP/1.1 ")


@dataclass(frozen=True)
class HTTPMessage:
    payload: bytes
    segments: int
    body_complete: bool = True


@dataclass
class _Flow:
    expected: int | None = None
    data: bytearray = field(default_factory=bytearray)
    pending: dict[int, bytes] = field(default_factory=dict)
    last_seen: float = 0.0
    segments: int = 0
    discarded_body_bytes: int = 0
    disabled: bool = False


class HTTPStreamReassembler:
    """TCP-direction-keyed reassembly using sequence numbers, with strict caps.

    The caller supplies a direction-specific (src, sport, dst, dport) key.
    Packets must be processed in capture order, but data segments may arrive
    out of order. If capture begins mid-stream, an incomplete first message
    may be ignored rather than incorrectly reported as safe.
    """

    def __init__(self) -> None:
        self._flows: OrderedDict[tuple[str, int, str, int], _Flow] = OrderedDict()
        self.messages = 0
        self.retransmissions = 0
        self.out_of_order = 0
        self.dropped_flows = 0

    @property
    def active_flows(self) -> int:
        return len(self._flows)

    def push(self, key: tuple[str, int, str, int], seq: int, flags: int,
             payload: bytes, timestamp: float) -> list[HTTPMessage]:
        # A new SYN restarts direction state. This matters when 4-tuples are reused.
        if flags & 0x02 and not (flags & 0x10):
            self._flows.pop(key, None)
        if key not in self._flows:
            if not payload and not flags & 0x02:
                return []
            if len(self._flows) >= MAX_FLOWS:
                self._flows.popitem(last=False)
                self.dropped_flows += 1
            self._flows[key] = _Flow()
        flow = self._flows[key]
        self._flows.move_to_end(key)
        flow.last_seen = timestamp
        # Sweep expired flows occasionally, not for each packet.
        if self.messages % 32 == 0 and len(self._flows) > MAX_FLOWS // 2:
            for old_key, state in list(self._flows.items()):
                if timestamp - state.last_seen > FLOW_TIMEOUT:
                    del self._flows[old_key]
        if flags & 0x02 and flow.expected is None:
            flow.expected = (seq + 1) & 0xFFFFFFFF
        if flow.disabled:
            return []
        if not payload:
            if flags & 0x05:
                self._flows.pop(key, None)
            return []
        data_seq = (seq + 1) & 0xFFFFFFFF if flags & 0x02 else seq
        if flow.expected is None:
            flow.expected = data_seq
        # Capture windows are short; ignore sequence-number wraparound (rare).
        if data_seq > flow.expected:
            if data_seq not in flow.pending:
                self.out_of_order += 1
                flow.pending[data_seq] = payload[:MAX_STREAM_BYTES]
            if len(flow.pending) > MAX_PENDING or sum(map(len, flow.pending.values())) > MAX_STREAM_BYTES:
                flow.disabled = True
                flow.pending.clear()
                flow.data.clear()
                self.dropped_flows += 1
            return []
        if data_seq + len(payload) <= flow.expected:
            self.retransmissions += 1
            return []
        offset = flow.expected - data_seq
        flow.data.extend(payload[offset:])
        flow.expected += len(payload) - offset
        flow.segments += 1
        # Incorporate queued out-of-order segments as the gap closes.
        while flow.pending:
            eligible = [s for s in flow.pending if s <= flow.expected]
            if not eligible:
                break
            start = min(eligible)
            chunk = flow.pending.pop(start)
            if start + len(chunk) <= flow.expected:
                self.retransmissions += 1
                continue
            extra = chunk[flow.expected - start:]
            flow.data.extend(extra)
            flow.expected += len(extra)
            flow.segments += 1
        if len(flow.data) > MAX_STREAM_BYTES:
            flow.disabled = True
            flow.pending.clear()
            flow.data.clear()
            self.dropped_flows += 1
            return []
        result = self._read_messages(flow)
        self.messages += len(result)
        if flags & 0x05:
            self._flows.pop(key, None)
        return result

    @staticmethod
    def _http_prefix(data: bytes) -> bool:
        probes = METHODS + RESPONSES
        return any(data.startswith(probe) or probe.startswith(data) for probe in probes)

    @staticmethod
    def _length_and_chunked(headers: bytes) -> tuple[int | None, bool]:
        content_length = None
        chunked = False
        for line in headers.split(b"\r\n")[1:]:
            if b":" not in line:
                continue
            name, value = line.split(b":", 1)
            low = name.strip().lower()
            if low == b"content-length":
                try:
                    content_length = int(value.strip())
                except ValueError:
                    content_length = None
            if low == b"transfer-encoding" and b"chunked" in value.lower():
                chunked = True
        return content_length, chunked

    def _read_messages(self, flow: _Flow) -> list[HTTPMessage]:
        output: list[HTTPMessage] = []
        for _ in range(20):  # Upper bound for pipelined messages in one packet.
            if flow.discarded_body_bytes:
                skip = min(len(flow.data), flow.discarded_body_bytes)
                del flow.data[:skip]
                flow.discarded_body_bytes -= skip
                if flow.discarded_body_bytes:
                    break
            if not flow.data:
                break
            if not self._http_prefix(bytes(flow.data[:16])):
                # This could be a partial stream, HTTP/2 or TLS. Never scan raw
                # arbitrary data looking for credentials.
                flow.disabled = True
                flow.data.clear()
                flow.pending.clear()
                break
            head_end = flow.data.find(b"\r\n\r\n")
            if head_end < 0:
                if len(flow.data) > MAX_HEADER_BYTES:
                    flow.disabled = True
                    flow.data.clear()
                    self.dropped_flows += 1
                break
            head_end += 4
            if head_end > MAX_HEADER_BYTES:
                flow.disabled = True
                flow.data.clear()
                self.dropped_flows += 1
                break
            headers = bytes(flow.data[:head_end])
            content_length, chunked = self._length_and_chunked(headers)
            is_response = headers.startswith(b"HTTP/")
            method = headers.split(b" ", 1)[0]
            # HTTP response with unframed body: parse headers and stop parsing
            # this direction rather than misidentifying HTML as a request.
            if chunked:
                # Transfer-encoded bodies are not decoded in v0.4. Header
                # presence and cookie flags remain analyzable.
                output.append(HTTPMessage(headers, max(1, flow.segments), False))
                flow.data.clear()
                flow.disabled = True
                break
            if content_length is not None and content_length < 0:
                flow.disabled = True
                flow.data.clear()
                break
            if content_length is not None and content_length > MAX_MESSAGE_BODY:
                output.append(HTTPMessage(headers, max(1, flow.segments), False))
                del flow.data[:head_end]
                flow.discarded_body_bytes = content_length
                flow.segments = 0
                continue
            if content_length is not None:
                length = head_end + content_length
                if len(flow.data) < length:
                    break
            elif is_response:
                length = head_end
            elif method in (b"GET", b"HEAD", b"DELETE", b"OPTIONS"):
                length = head_end
            else:
                # Rare malformed HTTP/1.x requests without Content-Length:
                # inspect already-present body, but do not claim completeness.
                length = len(flow.data)
            message = bytes(flow.data[:length])
            output.append(HTTPMessage(message, max(1, flow.segments), content_length is not None or method in (b"GET", b"HEAD", b"DELETE", b"OPTIONS")))
            del flow.data[:length]
            flow.segments = 0
            if is_response and content_length is None:
                flow.data.clear()
                flow.disabled = True
                break
        return output
