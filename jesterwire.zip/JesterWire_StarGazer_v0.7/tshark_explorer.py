"""TShark evidence viewer for JesterWire, built using Tkinter only."""
from __future__ import annotations

from collections import Counter
import queue
import threading
import tkinter as tk
from tkinter import filedialog, messagebox, ttk
from tkinter.scrolledtext import ScrolledText
from pathlib import Path
from typing import Callable

from tshark_bridge import (PacketRow, TSharkError, follow_tcp, list_packets,
                           locate_tshark, packet_details, tshark_version)

BG = '#0B1020'
SURFACE = '#131C2E'
SURFACE2 = '#1B2840'
TEXT = '#EDF3FB'
MUTED = '#9DACBF'
ACCENT = '#56DDC5'


class TSharkExplorer(tk.Toplevel):
    def __init__(self, master: tk.Misc, pcap_path: str,
                 open_plan: Callable[[], None] | None = None):
        super().__init__(master)
        self.title('JesterWire | TShark Packet Explorer')
        self.geometry('1240x820')
        self.minsize(930, 620)
        self.configure(bg=BG)
        self.capture = str(pcap_path)
        self.rows: dict[str, PacketRow] = {}
        self._request_id = 0
        self._results = queue.Queue()
        self._selected: PacketRow | None = None
        self._open_plan = open_plan
        self.filter_var = tk.StringVar()
        self.status_var = tk.StringVar(value='Ready. Apply a display filter to load packets.')
        self.version_var = tk.StringVar(value='Checking TShark...')
        style=ttk.Style(self)
        style.configure('Dark.Treeview',background=SURFACE,foreground=TEXT,fieldbackground=SURFACE,rowheight=29,font=('Segoe UI',9),borderwidth=0)
        style.configure('Dark.Treeview.Heading',background=SURFACE2,foreground=MUTED,font=('Segoe UI',9,'bold'))
        style.map('Dark.Treeview',background=[('selected','#264A58')],foreground=[('selected','#FFFFFF')])
        self._create_layout()
        self.after(100, self._load_version)
        self.after(100, self._poll_results)
        self.after(200, self.apply_filter)

    def _btn(self, parent: tk.Widget, title: str, callback, accent: bool = False):
        result = tk.Button(parent, text=title, command=callback,
                           bg=ACCENT if accent else SURFACE2,
                           fg=BG if accent else TEXT, relief='flat', bd=0,
                           cursor='hand2', padx=12, pady=8,
                           font=('Segoe UI', 9, 'bold'))
        return result

    def _text(self, parent: tk.Widget, title: str, foreground: str = TEXT):
        return tk.Label(parent, text=title, fg=foreground, bg=BG, font=('Segoe UI', 10))

    def _create_layout(self):
        header=tk.Frame(self,bg=BG)
        header.pack(fill='x',padx=18,pady=(16,9))
        tk.Label(header,text='◈ TSHARK PACKET EXPLORER',bg=BG,fg=ACCENT,
                 font=('Segoe UI',17,'bold')).pack(side='left')
        self._btn(header,'Build Plan for Packet',self.launch_plan).pack(side='right',padx=(8,0))
        self._btn(header,'Open in Wireshark',self.open_external_wireshark).pack(side='right')
        tk.Label(self,text=f'Local capture: {Path(self.capture).name}   |   Read-only inspection',
                 bg=BG,fg=MUTED,font=('Segoe UI',10)).pack(anchor='w',padx=18,pady=(0,6))
        self._text(self, 'Use standard Wireshark display filters. Examples: http, dns, tcp, ip.addr == 192.0.2.10', MUTED).pack(anchor='w',padx=18)

        f=tk.Frame(self,bg=SURFACE)
        f.pack(fill='x',padx=18,pady=(10,6))
        tk.Label(f,text='DISPLAY FILTER',bg=SURFACE,fg=MUTED,
                 font=('Segoe UI',9,'bold')).pack(side='left',padx=(12,8))
        e=tk.Entry(f,textvariable=self.filter_var,bg=SURFACE2,fg=TEXT,insertbackground=TEXT,
                   relief='flat',font=('Consolas',11))
        e.pack(side='left',fill='x',expand=True,ipady=9,padx=(0,6))
        e.bind('<Return>',lambda _e:self.apply_filter())
        self._btn(f,'Apply Filter',self.apply_filter,accent=True).pack(side='left',padx=(0,6),pady=6)
        self._btn(f,'Reset',self.reset_filter).pack(side='left',padx=(0,10),pady=6)

        holder=tk.Frame(self,bg=SURFACE)
        holder.pack(fill='both',expand=True,padx=18,pady=(4,5))
        columns=('number','time','source','destination','protocol','length','info')
        self.table=ttk.Treeview(holder,columns=columns,show='headings',selectmode='browse',height=11,style='Dark.Treeview')
        specs={'number':('#',64),'time':('TIME',90),'source':('SOURCE',151),
               'destination':('DESTINATION',151),'protocol':('PROTOCOL',88),
               'length':('LEN',64),'info':('INFO',410)}
        for col,(name,width) in specs.items():
            self.table.heading(col,text=name)
            self.table.column(col,width=width,stretch=col=='info',minwidth=45)
        tree_scroll=ttk.Scrollbar(holder,orient='vertical',command=self.table.yview)
        tree_scroll.pack(side='right',fill='y')
        self.table.pack(side='left',fill='both',expand=True)
        self.table.configure(yscrollcommand=tree_scroll.set)
        self.table.bind('<<TreeviewSelect>>',self.on_selection)

        action=tk.Frame(self,bg=BG)
        action.pack(fill='x',padx=18,pady=(6,5))
        self._btn(action,'Decoded Packet Details',lambda:self.show_packet(False),accent=True).pack(side='left',padx=(0,8))
        self._btn(action,'Hex / ASCII',lambda:self.show_packet(True)).pack(side='left',padx=(0,8))
        self._btn(action,'Follow TCP Stream',self.show_stream).pack(side='left',padx=(0,8))
        self._btn(action,'TCP Packets Only',self.filter_stream_packets).pack(side='left',padx=(0,8))
        self.current_label=self._text(action,'Select a packet.',MUTED)
        self.current_label.pack(side='right')

        self.notebook=ttk.Notebook(self)
        self.notebook.pack(fill='both',expand=True,padx=18,pady=(4,8))
        detail_frame=tk.Frame(self.notebook,bg=SURFACE)
        stream_frame=tk.Frame(self.notebook,bg=SURFACE)
        stats_frame=tk.Frame(self.notebook,bg=SURFACE)
        self.notebook.add(detail_frame,text='  Packet Details / Hex  ')
        self.notebook.add(stream_frame,text='  TCP Conversation  ')
        self.notebook.add(stats_frame,text='  Quick Statistics  ')
        self.detail=ScrolledText(detail_frame,bg=SURFACE,fg=TEXT,insertbackground=TEXT,
                                 font=('Consolas',10),wrap='none',padx=12,pady=9)
        self.detail.pack(fill='both',expand=True,padx=7,pady=7)
        self.detail.insert('1.0','Choose a packet to view its complete TShark protocol dissection.\n\n'
                          'Hex / ASCII shows the packet bytes, not just a finding counter.\n'
                          'A saved capture may contain private information; keep it protected.')
        self.detail.configure(state='disabled')
        self.stream_text=ScrolledText(stream_frame,bg=SURFACE,fg=TEXT,insertbackground=TEXT,
                                      font=('Consolas',10),wrap='none',padx=12,pady=9)
        self.stream_text.pack(fill='both',expand=True,padx=7,pady=7)
        self._replace(self.stream_text,'Choose a TCP packet, then click Follow TCP Stream.\n'
                                    'The original capture remains unchanged.')
        self.stats=ScrolledText(stats_frame,bg=SURFACE,fg=TEXT,font=('Consolas',11),
                                wrap='word',padx=12,pady=9)
        self.stats.pack(fill='both',expand=True,padx=7,pady=7)
        self._replace(self.stats,'Waiting for packet list...')

        footer=tk.Frame(self,bg=BG)
        footer.pack(fill='x',padx=18,pady=(3,12))
        tk.Label(footer,textvariable=self.status_var,bg=BG,fg=MUTED,
                 font=('Segoe UI',9),anchor='w').pack(side='left',fill='x',expand=True)
        tk.Label(footer,textvariable=self.version_var,bg=BG,fg=MUTED,
                 font=('Segoe UI',9)).pack(side='right')

    def _replace(self,widget: ScrolledText, contents: str):
        widget.configure(state='normal')
        widget.delete('1.0','end')
        widget.insert('1.0',contents)
        widget.configure(state='disabled')

    def _async(self, label: str, function, on_success):
        self.status_var.set(label)
        self._request_id += 1
        request = self._request_id
        def run():
            try:
                result = function()
            except (TSharkError, ValueError, OSError) as exc:
                self._results.put(('request', request, False, str(exc), on_success))
            else:
                self._results.put(('request', request, True, result, on_success))
        threading.Thread(target=run, daemon=True).start()

    def _poll_results(self):
        if not self.winfo_exists():
            return
        for _ in range(40):
            try:
                message = self._results.get_nowait()
            except queue.Empty:
                break
            if message[0] == 'version':
                self.version_var.set(message[1][:90])
                if len(message)>2 and message[2]:
                    self.status_var.set(message[2])
                continue
            _, request, success, payload, on_success = message
            if request != self._request_id:
                continue
            if success:
                on_success(payload)
            else:
                self.status_var.set(payload)
        self.after(80, self._poll_results)

    def _load_version(self):
        def run():
            try:
                version = tshark_version()
                error = ''
            except TSharkError as exc:
                version = 'TShark missing'
                error = str(exc)
            self._results.put(('version', version, error))
        threading.Thread(target=run, daemon=True).start()

    def apply_filter(self):
        expression=self.filter_var.get().strip()
        self.table.delete(*self.table.get_children())
        self.rows.clear()
        self._selected=None
        self._async(f'Analyzing capture: {expression or "all packets"}...',
                    lambda:list_packets(self.capture,expression),self._render_rows)

    def _render_rows(self,result):
        rows,status=result
        for row in rows:
            key=str(row.number)
            self.rows[key]=row
            self.table.insert('','end',iid=key,values=(row.number,row.time,row.source,
                    row.destination,row.protocol,row.length,row.info))
        self.status_var.set(status if rows else 'No packets matched this filter (within the preview frame limit).')
        types=Counter(row.protocol or 'Unknown' for row in rows)
        sources=Counter(row.source or 'Unknown' for row in rows)
        streams={row.stream for row in rows if row.stream is not None}
        lines=['TShark protocol overview (preview only)',
               '',f'Packets in preview: {len(rows):,}',f'TCP stream indices visible: {len(streams)}',
               '', 'PROTOCOL COUNTS']
        lines.extend(f'  {name:<16} {count:,}' for name,count in types.most_common(30))
        lines.extend(['','TOP SOURCES'])
        lines.extend(f'  {name:<38} {count:,}' for name,count in sources.most_common(20))
        lines.extend(['',status,'',
                      'This view uses TShark dissectors. Port labels do not prove a vulnerability.',
                      'Capture files and TCP streams can contain sensitive traffic.'])
        self._replace(self.stats,'\n'.join(lines))
        if rows:
            self.table.selection_set(str(rows[0].number))
            self.table.see(str(rows[0].number))
            self.on_selection()

    def reset_filter(self):
        self.filter_var.set('')
        self.apply_filter()

    def on_selection(self,_event=None):
        ids=self.table.selection()
        self._selected=self.rows.get(ids[0]) if ids else None
        if self._selected:
            row=self._selected
            stream='none' if row.stream is None else str(row.stream)
            self.current_label.configure(text=f'Frame #{row.number} | TCP stream {stream}')
            self.show_packet(False)
        else:
            self.current_label.configure(text='Select a packet.')

    def show_packet(self,hex_view: bool):
        row=self._selected
        if row is None:
            messagebox.showinfo('Select a packet','Select a row first.',parent=self)
            return
        self.notebook.select(0)
        name='hex / ASCII' if hex_view else 'decoded protocol details'
        self._async(f'Loading frame #{row.number} {name}...',
                    lambda:packet_details(self.capture,row.number,hex_view),
                    lambda output:self._show_text(output,self.detail,f'Loaded frame #{row.number} {name}.'))

    def show_stream(self):
        row=self._selected
        if row is None or row.stream is None:
            messagebox.showinfo('Select TCP traffic','Select a packet with a TCP stream number first.',parent=self)
            return
        self.notebook.select(1)
        stream=row.stream
        self._async(f'Following TCP stream {stream}...',
                    lambda:follow_tcp(self.capture,stream),
                    lambda output:self._show_text(output,self.stream_text,f'TCP stream {stream} loaded.'))

    def _show_text(self,output: str,box: ScrolledText,notice: str):
        self._replace(box,output)
        self.status_var.set(notice)

    def filter_stream_packets(self):
        row=self._selected
        if row is None or row.stream is None:
            messagebox.showinfo('Select TCP traffic','Select a TCP packet first.',parent=self)
            return
        self.filter_var.set(f'tcp.stream == {row.stream}')
        self.apply_filter()

    def launch_plan(self):
        if self._open_plan:
            self._open_plan(self._selected)
        else:
            messagebox.showinfo('Assessment plan','Open JesterWire to build a finding-specific plan.',parent=self)

    def open_external_wireshark(self):
        import os,shutil,subprocess,sys
        candidate=shutil.which('wireshark')
        if not candidate and sys.platform=='win32':
            candidate=str(Path(os.environ.get('ProgramFiles',r'C:\Program Files')) / 'Wireshark' / 'Wireshark.exe')
        if not candidate or not Path(candidate).is_file():
            messagebox.showinfo('Wireshark unavailable',
                                'Install Wireshark to open the capture in its native desktop interface.',parent=self)
            return
        try:
            subprocess.Popen([candidate,self.capture],stdin=subprocess.DEVNULL,
                             stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
        except OSError as exc:
            messagebox.showerror('Could not start Wireshark',str(exc),parent=self)


def launch_explorer(master:tk.Misc,pcap_path:str,open_plan=None)->TSharkExplorer:
    if not Path(pcap_path).is_file():
        raise TSharkError('No saved capture found. Start + Save PCAP, stop, then open the file first.')
    return TSharkExplorer(master,pcap_path,open_plan=open_plan)
