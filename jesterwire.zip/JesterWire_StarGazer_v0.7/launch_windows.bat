@echo off
cd /d "%~dp0"
if exist ".venv\Scripts\python.exe" (
    ".venv\Scripts\python.exe" app.py
) else (
    echo Please run setup_windows.bat first.
    pause
    exit /b 1
)
if errorlevel 1 pause
