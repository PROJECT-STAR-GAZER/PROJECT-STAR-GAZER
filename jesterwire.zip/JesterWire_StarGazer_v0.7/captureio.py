"""Scapy-backed, local PCAP recording for captures on authorized interfaces.

A PCAP is a complete packet recording, unlike JesterWire's sanitized JSON reports.
It may contain sensitive information. Keep files local and protect them appropriately.
"""
from __future__ import annotations

from datetime import datetime
from pathlib import Path
from threading import Lock
from typing import Any, Callable
import shutil


def default_capture_dir(home: Path | None = None) -> Path:
    """Choose a user-controlled folder; caller creates it on demand."""
    root = home if home is not None else Path.home()
    documents = root / "Documents"
    return (documents if documents.exists() else root) / "JesterWire" / "Captures"


def suggested_filename(now: datetime | None = None) -> str:
    instant = now or datetime.now().astimezone()
    return "JesterWire_" + instant.strftime("%Y%m%d_%H%M%S") + ".pcap"


class CaptureWriter:
    """One writer per capture. The sniffer callback feeds packets serially."""

    def __init__(self, path: Path | str, writer_factory: Callable[..., Any] | None = None):
        self.path = Path(path)
        self._factory = writer_factory
        self._writer: Any | None = None
        self._lock = Lock()
        self.packet_count = 0
        self.closed = True
        self.error: str | None = None

    def start(self) -> None:
        if self._factory is None:
            # Import at runtime so basic tests and metadata tools work without Scapy.
            from scapy.all import PcapWriter
            self._factory = PcapWriter
        if self.path.suffix.lower() != '.pcap':
            raise ValueError("Choose a .pcap file. PCAPNG writing is not supported in this version.")
        self.path.parent.mkdir(parents=True, exist_ok=True)
        if self.path.exists():
            raise FileExistsError(f"Refusing to overwrite existing capture: {self.path}")
        self._writer = self._factory(str(self.path), append=False, sync=False)
        self.closed = False

    def write(self, packet: Any) -> None:
        with self._lock:
            if self.closed or self._writer is None:
                return
            try:
                self._writer.write(packet)
                self.packet_count += 1
            except Exception as exc:
                self.error = str(exc)
                raise

    def close(self) -> None:
        with self._lock:
            if self.closed:
                return
            self.closed = True
            try:
                if self._writer is not None:
                    self._writer.close()  # Flushes the PCAP header and any buffered packets.
            finally:
                self._writer = None


def duplicate_pcap(source: str | Path, destination: str | Path) -> None:
    """Copy a completed PCAP without altering its data or format."""
    src, dst = Path(source), Path(destination)
    if not src.is_file() or src.suffix.lower() not in {'.pcap', '.pcapng'}:
        raise ValueError('Source must be an existing PCAP or PCAPNG file.')
    if dst.suffix.lower() != src.suffix.lower():
        raise ValueError('Destination must preserve the original capture extension.')
    if src.resolve() == dst.resolve():
        raise ValueError('Choose a different destination file.')
    shutil.copy2(src, dst)
