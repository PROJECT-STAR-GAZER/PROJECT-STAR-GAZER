"""JesterWire v0.5: read-only packet analysis with bounded HTTP TCP reassembly.

Only process captures and network interfaces you are authorized to inspect.
The detector never intentionally records credential or cookie *values*.
"""
from __future__ import annotations

from collections import Counter, defaultdict, deque
from dataclasses import asdict, dataclass
from datetime import datetime
import re
import time
from typing import Any
from urllib.parse import parse_qs, urlsplit

from scapy.all import ARP, DNS, DNSQR, ICMP, IP, IPv6, Raw, TCP, UDP
from streams import HTTPStreamReassembler
from insights import summarize_http_message, MAX_HTTP_ROWS, MAX_TCP_ROWS, MAX_DNS_ROWS, SERVICE_HINTS


CREDENTIAL_KEYS = {"username", "user", "login", "email", "password", "passwd", "pwd", "pass", "token", "api_key", "apikey"}
PASSWORD_KEYS = {"password", "passwd", "pwd", "pass"}
USERNAME_KEYS = {"username", "user", "login", "email"}
HTTP_METHODS = (b"GET ", b"POST ", b"PUT ", b"PATCH ", b"DELETE ", b"HEAD ", b"OPTIONS ")


@dataclass(frozen=True)
class Finding:
    category: str
    severity: str
    title: str
    description: str
    source: str
    destination: str
    protocol: str
    timestamp: str
    evidence: tuple[str, ...] = ()

    def to_dict(self) -> dict[str, Any]:
        result = asdict(self)
        result["evidence"] = list(self.evidence)
        return result


def _now(packet: Any) -> str:
    try:
        return datetime.fromtimestamp(float(packet.time)).strftime("%H:%M:%S")
    except (ValueError, TypeError, OSError, AttributeError):
        return datetime.now().strftime("%H:%M:%S")


def _packet_endpoints(packet: Any) -> tuple[str, str]:
    if IP in packet:
        return str(packet[IP].src), str(packet[IP].dst)
    if IPv6 in packet:
        return str(packet[IPv6].src), str(packet[IPv6].dst)
    return "Unknown", "Unknown"


def _safe_hostname(value: bytes | str) -> str:
    if isinstance(value, bytes):
        value = value.decode("utf-8", "replace")
    # Names can include control characters; remove them for the GUI.
    value = "".join(ch for ch in value if ch.isprintable())
    return value.strip(".")[:120]


def _http_field_names(body: str, content_type: str) -> set[str]:
    """Find field *names* only. Never return field contents."""
    if "application/json" in content_type:
        return set(re.findall(r'"([a-zA-Z_][\w-]{0,39})"\s*:', body[:8192]))
    # HTML form data and query strings only; no loose regex over arbitrary text.
    if "application/x-www-form-urlencoded" in content_type or "=" in body:
        parsed = parse_qs(body[:8192], keep_blank_values=True)
        return set(parsed.keys())
    return set()


def _analyze_http(data: bytes, src: str, dst: str, timestamp: str,
                  segment_count: int = 1, body_complete: bool = True) -> list[Finding]:
    # No plaintext packet data is retained in Finding objects or log files.
    if not (data.startswith(HTTP_METHODS) or data.startswith(b"HTTP/1.")):
        return []
    text = data[:16384].decode("latin-1", "replace")
    headers, _, body = text.partition("\r\n\r\n")
    header_lines = headers.split("\r\n")
    first_line = header_lines[0][:150]
    header_map: dict[str, list[str]] = defaultdict(list)
    for line in header_lines[1:]:
        if ":" in line:
            key, value = line.split(":", 1)
            header_map[key.strip().lower()].append(value.strip())
    is_request = not first_line.startswith("HTTP/")
    fields: set[str] = set()
    if is_request:
        parts = first_line.split(" ")
        if len(parts) >= 2:
            try:
                query = urlsplit(parts[1]).query
                fields.update(parse_qs(query, keep_blank_values=True).keys())
            except ValueError:
                pass
        fields.update(_http_field_names(body, " ".join(header_map.get("content-type", []))))
    normalized = {name.lower() for name in fields}
    password_found = bool(normalized & PASSWORD_KEYS)
    username_found = bool(normalized & USERNAME_KEYS)
    findings: list[Finding] = []
    context = (f"TCP reconstruction: {segment_count} data segment(s)",
               "HTTP body complete: " + ("yes" if body_complete else "not confirmed"))

    if password_found or username_found:
        names = []
        if username_found:
            names.append("Username field detected: [REDACTED]")
        if password_found:
            names.append("Password field detected: [REDACTED]")
        findings.append(Finding(
            "Credential Leaks", "HIGH" if password_found else "MEDIUM",
            "Possible cleartext login data", "A plaintext HTTP request contains login-related field names. This does not prove the values are valid credentials.",
            src, dst, "HTTP", timestamp, tuple(names + ["Transport: unencrypted HTTP"]) + context
        ))

    if "authorization" in header_map:
        schemes = set()
        for header in header_map["authorization"]:
            scheme = header.split(None, 1)[0].lower() if header else "unknown"
            schemes.add(scheme if scheme in ("basic", "bearer", "digest") else "other")
        findings.append(Finding(
            "Credential Leaks", "HIGH", "Authorization header over HTTP",
            "An authentication header is visible over unencrypted HTTP. Its value is hidden by JesterWire.",
            src, dst, "HTTP", timestamp, tuple("Authorization scheme: " + scheme for scheme in sorted(schemes)) + context
        ))

    if "cookie" in header_map:
        findings.append(Finding(
            "Session/Cookie Risks", "MEDIUM", "Cookie transmitted over HTTP",
            "A Cookie header is visible in plaintext traffic. Its value is redacted; sensitivity and exploitability are unverified.",
            src, dst, "HTTP", timestamp, ("Cookie header detected: [REDACTED]", "Transport: unencrypted HTTP") + context
        ))

    if "set-cookie" in header_map:
        missing: set[str] = set()
        for cookie in header_map["set-cookie"]:
            attributes = {part.strip().split("=", 1)[0].lower() for part in cookie.split(";")[1:]}
            for flag in ("secure", "httponly", "samesite"):
                if flag not in attributes:
                    missing.add(flag)
        findings.append(Finding(
            "Session/Cookie Risks", "MEDIUM", "Cookie configuration needs review",
            "A Set-Cookie header was observed over HTTP. Review whether this cookie is sensitive and whether its protection attributes are appropriate.",
            src, dst, "HTTP", timestamp,
            ("Set-Cookie detected: [REDACTED]",) + (("Attributes missing on at least one cookie: " + ", ".join(sorted(missing)),) if missing else ()) + context
        ))

    if is_request:
        # Never include the URL: a URL could contain a token or password.
        method = first_line.split(" ", 1)[0]
        findings.append(Finding(
            "Network Traffic", "INFO", f"HTTP {method} request",
            "Observed an HTTP/1.x request reconstructed from captured TCP data. Sensitive values are omitted. A missing field may reflect an incomplete capture or unsupported encoding.",
            src, dst, "HTTP", timestamp, (
                "Method: " + method,
                "Cookie header: " + ("present" if "cookie" in header_map else "not observed in this message"),
                "Authorization header: " + ("present" if "authorization" in header_map else "not observed in this message"),
                "Login field names: " + ("seen" if password_found or username_found else "not observed in parsed data"),
            ) + context
        ))
    else:
        status = first_line.split(" ", 2)[1] if len(first_line.split(" ", 2)) >= 2 else "Unknown"
        findings.append(Finding(
            "Network Traffic", "INFO", "HTTP response observed",
            "Observed a plaintext HTTP response. Response body and sensitive header values are not retained.",
            src, dst, "HTTP", timestamp, (
                "HTTP status: " + (status if status.isdigit() else "Unknown"),
                "Set-Cookie header: " + ("present" if "set-cookie" in header_map else "not observed in this message"),
            ) + context
        ))
    return findings


class Detector:
    """Stateful lightweight heuristics for packet capture and offline PCAP review."""

    def __init__(self) -> None:
        self.packet_count = 0
        self._syn_ports: dict[tuple[str, str], deque[tuple[float, int]]] = defaultdict(deque)
        self._scan_alerted: dict[tuple[str, str], float] = {}
        self._seen_dns: set[tuple[str, str, str]] = set()
        self.streams = HTTPStreamReassembler()
        self.http_message_count = 0
        self.http_observations: list[dict] = []
        self.tcp_flows: dict[tuple,dict] = {}
        self.dns_observations: list[dict] = []
        self.protocol_counts: Counter[str] = Counter()
        self.peer_counts: Counter[str] = Counter()

    def analyze(self, packet: Any) -> list[Finding]:
        self.packet_count += 1
        timestamp = _now(packet)
        src, dst = _packet_endpoints(packet)
        # Protocol counts cover EVERY packet, including those with no security findings.
        if DNS in packet:
            protocol_group = 'DNS / mDNS'
        elif TCP in packet:
            tcp_meta = packet[TCP]
            ports = {int(tcp_meta.sport), int(tcp_meta.dport)}
            if 443 in ports or 8443 in ports:
                protocol_group = 'TCP on HTTPS port (contents encrypted or unknown)'
            else:
                protocol_group = 'Other TCP'
        elif UDP in packet:
            udp_meta = packet[UDP]
            protocol_group = 'UDP/443 (possible QUIC)' if 443 in (int(udp_meta.sport), int(udp_meta.dport)) else 'Other UDP'
        elif ARP in packet:
            protocol_group = 'ARP'
        elif ICMP in packet:
            protocol_group = 'ICMP'
        else:
            protocol_group = 'Other link-layer traffic'
        self.protocol_counts[protocol_group] += 1
        if src == "Unknown":
            return []
        if src in self.peer_counts or len(self.peer_counts) < 3000:
            self.peer_counts[src] += 1
        findings: list[Finding] = []

        if DNS in packet and DNSQR in packet and getattr(packet[DNS], "qr", 1) == 0:
            domain = _safe_hostname(packet[DNSQR].qname)
            key = (src, dst, domain)
            if key not in self._seen_dns:
                if len(self._seen_dns) > 10000:
                    self._seen_dns.clear()
                self._seen_dns.add(key)
                if len(self.dns_observations) < MAX_DNS_ROWS:
                    self.dns_observations.append({'source':src, 'destination':dst, 'domain':domain, 'count':1})
                findings.append(Finding(
                    "Network Traffic", "INFO", "DNS lookup observed",
                    "A device requested a domain name. DNS lookups alone are not evidence of compromise.",
                    src, dst, "DNS", timestamp, (f"Requested domain: {domain}",)
                ))

        if TCP in packet:
            tcp = packet[TCP]
            flags = int(tcp.flags)
            # Always tally flows, even when no heuristic alert was emitted.
            sport, dport = int(tcp.sport), int(tcp.dport)
            endpoint_a, endpoint_b = sorted(((src, sport),(dst, dport)))
            flowkey=(endpoint_a,endpoint_b)
            if flowkey not in self.tcp_flows and len(self.tcp_flows) < MAX_TCP_ROWS:
                self.tcp_flows[flowkey] = {'a':endpoint_a[0], 'a_port':endpoint_a[1],
                    'b':endpoint_b[0], 'b_port':endpoint_b[1],
                    'packets':0, 'payload_bytes':0, 'syn':0, 'syn_ack':0, 'rst':0,
                    'fin':0, 'initiator':'Unknown', 'target':'Unknown', 'target_port':None}
            observed = self.tcp_flows.get(flowkey)
            if observed is not None:
                observed['packets']+=1
                observed['payload_bytes']+=len(bytes(packet[Raw].load)) if Raw in packet else 0
                if flags & 0x02 and flags & 0x10:observed['syn_ack']+=1
                elif flags & 0x02:
                    observed['syn']+=1
                    observed['initiator']=src
                    observed['target']=dst
                    observed['target_port']=dport
                if flags & 0x04:observed['rst']+=1
                if flags & 0x01:observed['fin']+=1
            is_initial_syn = bool(flags & 0x02) and not bool(flags & 0x10)
            if is_initial_syn:
                try:
                    event_time = float(packet.time)
                except (TypeError, ValueError, AttributeError):
                    event_time = time.time()
                key = (src, dst)
                history = self._syn_ports[key]
                history.append((event_time, int(tcp.dport)))
                while history and event_time - history[0][0] > 20:
                    history.popleft()
                distinct_ports = len({port for _, port in history})
                if distinct_ports >= 8 and event_time - self._scan_alerted.get(key, -1e12) > 30:
                    self._scan_alerted[key] = event_time
                    findings.append(Finding(
                        "Possible Intrusion", "MEDIUM", "Possible multi-port SYN scan",
                        "One source attempted initial TCP connections to eight or more destination ports within 20 seconds. This can be legitimate administration or scanning.",
                        src, dst, "TCP", timestamp,
                        (f"Distinct destination ports: {distinct_ports}", "Window: 20 seconds", "Finding: heuristic, not confirmed intrusion")
                    ))
                # Avoid a flood of one-row-per-SYN activity entries.
                if self.packet_count % 15 == 0:
                    findings.append(Finding(
                        "Network Traffic", "INFO", "TCP connection attempt",
                        "Observed an initial TCP handshake packet (SYN).",
                        src, dst, "TCP", timestamp, (f"Destination port: {int(tcp.dport)}",)
                    ))

        if TCP in packet:
            tcp = packet[TCP]
            try:
                event_time = float(packet.time)
            except (TypeError, ValueError, AttributeError):
                event_time = time.time()
            key = (src, int(tcp.sport), dst, int(tcp.dport))
            payload = bytes(packet[Raw].load) if Raw in packet else b""
            for message in self.streams.push(key, int(tcp.seq), int(tcp.flags), payload, event_time):
                self.http_message_count += 1
                if len(self.http_observations) < MAX_HTTP_ROWS:
                    self.http_observations.append(summarize_http_message(
                        message.payload, src, int(tcp.sport), dst, int(tcp.dport),
                        timestamp, message.segments, message.body_complete))
                findings.extend(_analyze_http(message.payload, src, dst, timestamp,
                                              message.segments, message.body_complete))

        return findings


def demo_findings() -> tuple[list[Finding], int]:
    """Generate example findings from synthetic traffic using reserved documentation IPs."""
    from scapy.all import DNS, DNSQR, IP, TCP, UDP, Raw

    detector = Detector()
    packets = []
    base = time.time()

    def put(packet: Any, seconds: float) -> None:
        packet.time = base + seconds
        packets.append(packet)

    # A synthetic split HTTP request; login field names are detected only
    # after reconstruction. No real credentials are present or exported.
    body = b"username=example&password=not-a-real-password"
    data = (b"POST /login HTTP/1.1\r\nHost: lab.example\r\nContent-Type: application/x-www-form-urlencoded\r\n"
            + f"Content-Length: {len(body)}\r\n\r\n".encode() + body)
    chunks = (data[:32], data[32:105], data[105:])
    base_seq = 10001
    put(IP(src="192.0.2.25", dst="198.51.100.10") / TCP(sport=54001, dport=80, seq=base_seq-1, flags="S"), 0)
    cursor = base_seq
    for i, chunk in enumerate(chunks):
        put(IP(src="192.0.2.25", dst="198.51.100.10") / TCP(sport=54001, dport=80, seq=cursor, flags="PA") /
            Raw(load=chunk), 0.1 + i * 0.1)
        cursor += len(chunk)
    put(IP(src="192.0.2.25", dst="198.51.100.10") / TCP(sport=54002, dport=80) /
        Raw(load=b"GET /dashboard HTTP/1.1\r\nHost: lab.example\r\nCookie: sid=example-not-real\r\n\r\n"), 1)
    put(IP(src="198.51.100.10", dst="192.0.2.25") / TCP(sport=80, dport=54002) /
        Raw(load=b"HTTP/1.1 200 OK\r\nSet-Cookie: sid=example-not-real; Path=/\r\nContent-Length: 0\r\n\r\n"), 2)
    put(IP(src="192.0.2.25", dst="192.0.2.53") / UDP(sport=49844, dport=53) /
        DNS(rd=1, qd=DNSQR(qname="training.example")), 3)
    for i, port in enumerate((21, 22, 23, 25, 53, 80, 443, 3389, 8080)):
        put(IP(src="203.0.113.50", dst="192.0.2.25") / TCP(sport=41000 + i, dport=port, flags="S"), 4 + i)
    results: list[Finding] = []
    for packet in packets:
        results.extend(detector.analyze(packet))
    return results, detector.packet_count
