"""Safe human-readable network evidence, never credential/token values.

TCP stream reconstruction happens elsewhere. This module describes only the
reconstructed messages and observable metadata. Real headers/bodies aren't kept.
"""
from __future__ import annotations
from collections import Counter
import re
from urllib.parse import urlsplit, unquote

MAX_HTTP_ROWS = 750
MAX_TCP_ROWS = 3000
MAX_DNS_ROWS = 1500
SERVICE_HINTS = {20:'FTP data',21:'FTP control',22:'SSH',23:'Telnet',25:'SMTP',53:'DNS',80:'HTTP',110:'POP3',123:'NTP',139:'NetBIOS',143:'IMAP',443:'HTTPS',445:'SMB',465:'SMTPS',587:'Mail submission',631:'IPP printing',993:'IMAPS',995:'POP3S',1433:'SQL Server',3306:'MySQL',3389:'RDP',5432:'PostgreSQL',5900:'VNC',6379:'Redis',7680:'Windows Delivery Optimization',8080:'Alternate HTTP',8443:'Alternate HTTPS'}


def safe_path(path: str) -> str:
    """Keep a useful route but omit queries, fragments and opaque identifiers."""
    if not path.startswith('/'):
        return '[non-origin-form target]'
    path = urlsplit(path).path
    chunks=[]
    for segment in path.split('/')[:12]:
        segment = unquote(segment)
        if (len(segment)>32 or re.search(r'(?i)(token|secret|key|auth|password|passwd|pwd|session|jwt)',segment)
             or re.fullmatch(r'[0-9a-fA-F]{16,}',segment) or re.fullmatch(r'[A-Za-z0-9_=-]{24,}',segment)):
            chunks.append('[segment hidden]')
        else:
            chunks.append(re.sub(r'[^a-zA-Z0-9_.~-]', '_', segment)[:32])
    return '/'.join(chunks)[:140] or '/'


def summarize_http_message(data: bytes, src: str, sport: int, dst: str, dport: int,
                           timestamp: str, segments: int, body_complete: bool) -> dict:
    """Return display-only metadata. Never retain raw header or body values."""
    head, sep, body = data.partition(b'\r\n\r\n')
    lines = head[:16384].decode('latin1','replace').split('\r\n')
    first = (lines[0] if lines else '')[:300]
    names=[]
    header_info={}
    for line in lines[1:]:
        if ':' not in line: continue
        k,v=line.split(':',1)
        k=k.strip().lower()
        if not re.fullmatch('[a-z0-9-]{1,45}',k):continue
        if k not in names:names.append(k)
        if k in ('content-type',):
            header_info[k]=v.split(';')[0].strip()[:60]
    is_response=first.startswith('HTTP/')
    kind='Response' if is_response else 'Request'
    method=''; route=''; status=''
    if is_response:
        match=re.match(r'^HTTP/1\.[01] (\d{3})(?: |$)',first)
        status=match.group(1) if match else 'Unknown'
    else:
        match=re.match(r'^(GET|POST|PUT|PATCH|DELETE|HEAD|OPTIONS) (\S+) HTTP/1\.[01]$',first)
        method=match.group(1) if match else 'Unknown'
        route=safe_path(match.group(2)) if match else '[unknown]'
    return {'time':timestamp,'source':str(src)[:80], 'source_port':int(sport),
            'destination':str(dst)[:80],'destination_port':int(dport),
            'type':kind,'method':method,'route':route,'status':status,
            'header_names':names[:70], 'cookie_header':('cookie' in names),
            'set_cookie_header':('set-cookie' in names),
            'authorization_header':('authorization' in names),
            'content_type':header_info.get('content-type','Not specified'),
            'body_bytes_seen': len(body) if sep else 0,
            'body_complete':bool(body_complete), 'segments':int(segments),
            'note':('Metadata from reconstructed plaintext HTTP; header values and response body are not stored. '
                    'A request does not prove a vulnerability.')}


def summarize_legacy_findings(findings: list[dict]) -> dict:
    """Clearly label what can be inferred from a findings-only old JSON."""
    titles=Counter(str(f.get('title','')) for f in findings)
    proto=Counter(str(f.get('protocol','')) for f in findings)
    domains=Counter()
    for f in findings:
        for evidence in f.get('evidence', []):
            if isinstance(evidence,str) and evidence.startswith('Requested domain: '):
                domains[evidence[len('Requested domain: '):]]+=1
    return {'titles':titles,'protocols':proto,'domains':domains}


def grouped_dns(rows: list[dict]) -> list[dict]:
    byname={}
    for r in rows:
        domain=r['domain']
        if domain not in byname:
            byname[domain]={'domain':domain,'count':0,'sources':set()}
        byname[domain]['count']+=r.get('count',1)
        byname[domain]['sources'].add(r['source'])
    return [dict(domain=x['domain'],count=x['count'],sources=', '.join(sorted(x['sources'])[:5]))
            for x in sorted(byname.values(),key=lambda x:(-x['count'],x['domain']))]
