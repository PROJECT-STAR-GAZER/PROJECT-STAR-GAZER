"""Readable Scapy/Npcap adapters without changing interface capture permissions.

The network medium is diagnostic information, not evidence of authority or access.
If Windows cannot confirm a type, report the classification as an estimate.
"""
from __future__ import annotations

from dataclasses import dataclass
import json
import os
import re
import subprocess
from typing import Iterable, Any


@dataclass(frozen=True)
class Adapter:
    capture_name: str
    friendly_name: str
    description: str
    medium: str
    source: str = "name/description estimate"
    status: str = "Unknown"

    @property
    def label(self) -> str:
        desc = f" — {self.description}" if self.description and self.description.lower() != self.friendly_name.lower() else ""
        text = f"{self.friendly_name} [{self.medium}]{desc}"
        return (text[:102] + "…") if len(text) > 103 else text


def infer_medium(*parts: object) -> str:
    value = " ".join(str(part or "") for part in parts).lower()
    if any(word in value for word in ("loopback", "npcap loopback", "npcap_loopback")):
        return "Loopback"
    if any(word in value for word in ("virtual", "hyper-v", "vmware", "virtualbox", "vbox", "tap-", "tunnel", "wireguard", "openvpn", "tailscale", "wintun", "vpn", "pseudo-interface")):
        return "Virtual/VPN"
    if any(word in value for word in ("wi-fi", "wifi", "wireless", "wlan", "802.11", "aironet")):
        return "Wireless (Wi-Fi)"
    if any(word in value for word in ("ethernet", "gigabit", "10gbe", "2.5gbe", "lan adapter", "gbe", "i219", "i225")):
        return "Wired (Ethernet)"
    return "Unknown"


def _guid(value: object) -> str:
    match = re.search(r"\{?([a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12})\}?", str(value or ""), flags=re.I)
    return ("{" + match.group(1).upper() + "}") if match else ""


def _windows_adapters() -> dict[str, dict[str, str]]:
    """Optional local Windows API wrapper; no administrator privileges needed."""
    if os.name != "nt":
        return {}
    command = (
        "Get-NetAdapter -IncludeHidden | "
        "Select-Object Name,InterfaceDescription,InterfaceGuid,PhysicalMediaType,MediaType,Status | "
        "ConvertTo-Json -Compress"
    )
    try:
        result = subprocess.run(
            ["powershell.exe", "-NoProfile", "-NonInteractive", "-Command", command],
            capture_output=True, text=True, timeout=5, check=True,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
        )
        data = json.loads(result.stdout.strip())
        values = data if isinstance(data, list) else [data]
        return {_guid(item.get("InterfaceGuid")): item for item in values if isinstance(item, dict) and _guid(item.get("InterfaceGuid"))}
    except (OSError, subprocess.SubprocessError, json.JSONDecodeError, ValueError):
        return {}


def _medium_from_windows(raw: dict[str, str], fallback: str) -> tuple[str, str]:
    physical = str(raw.get("PhysicalMediaType") or "").lower()
    media = str(raw.get("MediaType") or "").lower()
    if fallback in ("Virtual/VPN", "Loopback"):
        return fallback, "name/description estimate"
    if "802.11" in physical or "native 802.11" in physical or "wireless" in physical or "wi-fi" in physical:
        return "Wireless (Wi-Fi)", "Windows network adapter properties"
    if "802.3" in physical or "ethernet" in media:
        return "Wired (Ethernet)", "Windows network adapter properties"
    return fallback, "name/description estimate"


def enumerate_adapters(names: Iterable[str], scapy_interfaces: Iterable[Any] = (), windows: dict[str, dict[str, str]] | None = None) -> list[Adapter]:
    windows = _windows_adapters() if windows is None else windows
    records = list(scapy_interfaces)
    choices: list[Adapter] = []
    for raw_name in names:
        candidate = next((item for item in records if raw_name in (
            str(getattr(item, "network_name", "")), str(getattr(item, "name", "")),
            str(getattr(item, "description", "")), str(getattr(item, "guid", ""))
        )), None)
        friendly = str(getattr(candidate, "name", "") or "").strip()
        description = str(getattr(candidate, "description", "") or "").strip()
        info = windows.get(_guid(raw_name)) or windows.get(_guid(getattr(candidate, "guid", ""))) or {}
        friendly = str(info.get("Name") or friendly or description or raw_name)
        description = str(info.get("InterfaceDescription") or description or "")
        medium = infer_medium(friendly, description)
        medium, source = _medium_from_windows(info, medium) if info else (medium, "name/description estimate")
        choices.append(Adapter(raw_name, friendly, description, medium, source, str(info.get("Status") or "Unknown")))
    return choices


def adapter_explanation(adapter: Adapter) -> str:
    lines = [
        f"Friendly name: {adapter.friendly_name}",
        f"Connection type: {adapter.medium}",
        f"Type evidence: {adapter.source}",
        f"Windows status: {adapter.status}",
        "",
        "WHAT THIS MEANS",
    ]
    if adapter.medium == "Wireless (Wi-Fi)":
        lines += [
            "Your adapter is identified as Wi-Fi. This does not establish whether you are already associated with a network or authorized to test it.",
            "Normal managed-mode capture mainly shows traffic available to this device.",
            "Raw 802.11 monitor-mode visibility requires compatible hardware, drivers, and Npcap settings.",
        ]
    elif adapter.medium == "Wired (Ethernet)":
        lines += [
            "Your adapter appears to use Ethernet. Being connected by cable does not mean you have administrator control.",
            "On switched networks, an ordinary capture won't automatically see traffic from other computers.",
        ]
    elif adapter.medium == "Virtual/VPN":
        lines += [
            "This looks like a virtual, tunnel, or VPN adapter. It might show only traffic handled by that interface.",
            "The actual underlying network could be wired or wireless.",
        ]
    else:
        lines += ["JesterWire cannot reliably determine the medium from available metadata. Confirm the type in Windows Network Connections."]
    lines += ["", "A network interface's type does not grant access or permission. Only inspect traffic you own or are authorized to assess."]
    return "\n".join(lines)
