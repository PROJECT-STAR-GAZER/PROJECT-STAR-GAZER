"""Finding-grounded pentest assessment guidance for authorized environments.

The educational 'Elaborate' material explains threats and validation without
providing account takeover, cookie replay, or traffic redirection tooling.
"""
from __future__ import annotations
from engine import Finding
from collections import Counter

STEPS: dict[str, tuple[str, ...]] = {
    "Credential Leaks": (
        "Confirm the traffic belongs to your explicitly authorized scope and establish test accounts.",
        "Reproduce the request with disposable credentials in a controlled lab, not production user passwords.",
        "Identify whether the input is inside an HTTP URL, form body, or Authorization header.",
        "Check for HTTPS enforcement, HSTS, secret-free URLs, and secret-free access logs.",
        "If real secrets might have been exposed, follow the owner's incident process and rotate them.",
        "Retest with a fresh controlled capture and document the before/after result.",
    ),
    "Session/Cookie Risks": (
        "Identify which authorized test application sent the cookie; classify whether it is an authentication cookie.",
        "Check Secure, HttpOnly, and SameSite flags and whether cookies appear over plain HTTP.",
        "Using a dedicated test account, verify the application's logout, expiry, and session rotation policy.",
        "Require HTTPS and keep session identifiers out of URLs and logs.",
        "Invalidate exposed test sessions; coordinate any real exposure with the application owner.",
        "Retest in a controlled environment and document cookie settings without storing session values.",
    ),
    "Possible Intrusion": (
        "Check scope, owner, time window, and whether any scheduled maintenance explains the pattern.",
        "Correlate with firewall, DNS, endpoint, and authentication logs.",
        "Compare targeted ports and services with a known-good asset inventory.",
        "If approved, run a bounded baseline scan within the test scope.",
        "Reduce unnecessary exposed services and tune alerting to avoid repeated false alarms.",
        "Preserve timestamps and sanitized indicators for any incident follow-up.",
    ),
    "Network Traffic": (
        "Identify the device and application expected to generate this traffic.",
        "Compare protocol, DNS name, and endpoint information with a documented baseline.",
        "Check whether the connection is local, internet-facing, or routine service discovery.",
        "For a known test system, inspect additional relevant packets without exposing third-party data.",
        "Record a conclusion, confidence level, and what evidence is still missing.",
    ),
}

EXTERNAL_STEPS = (
    "Define written authorization, targets, exclusions, time limits, and contact information.",
    "Map only in-scope public domains and IP ranges using passive sources such as DNS and certificate transparency.",
    "Identify exposed services from owner-provided inventory or explicitly approved assessment results.",
    "Document candidate risks; do not assume that public visibility gives permission to test access.",
    "Move to internal validation only after access and test methods are explicitly approved.",
)

TECHNIQUES: dict[str, tuple[tuple[str, str, str], ...]] = {
    "Credential Leaks": (
        ("Credential reuse / account login", "If a working password is exposed, someone could try it to impersonate an account holder.", "Use a disposable test account to verify that a login request never exposes its secret; review MFA and account alerts. Never try captured real-user passwords."),
        ("Plaintext network exposure", "On an unencrypted connection, anyone with legitimate access to an appropriate capture point may observe transmitted application data.", "Show that the same lab request becomes unreadable to a packet sniffer when protected with correctly configured HTTPS."),
        ("Unauthorized interception / MITM", "A machine positioned on a communication path might tamper with or observe unprotected traffic; encryption and endpoint authentication are intended to prevent this.", "Review TLS enforcement, HSTS, and certificate-validation behavior in a lab. JesterWire does not redirect live traffic."),
    ),
    "Session/Cookie Risks": (
        ("Session hijacking", "If a valid authentication session token is stolen, it may allow account impersonation without the password, depending on the application's defenses.", "Assess the exposure conditions and session lifecycle with synthetic tokens and a dedicated test application. Never replay captured real-user cookies."),
        ("Session cookie flags", "Missing Secure, HttpOnly, or appropriate SameSite protections can widen exposure to transport, script, or cross-site attacks, respectively.", "Review the Set-Cookie attributes and apply defenses appropriate to the cookie's role. A missing flag isn't proof of exploitability."),
        ("Traffic path control / interception", "Capturing or changing traffic requires a real vantage point and authorization; it is not guaranteed simply because the target uses Wi-Fi.", "Diagram the network's trust boundaries and validate that TLS protects sensitive application traffic in a controlled lab."),
    ),
    "Possible Intrusion": (
        ("Service discovery / scanning", "Many quick connections to different ports can reflect a scanner, normal management, or software discovery.", "Correlate the observed ports and timestamps with approved scan schedules and device logs."),
        ("Initial access", "An externally reachable vulnerable service could provide a path into a system if safeguards are weak.", "Compare exposure with asset inventories and approved vulnerability assessment results; prioritize patching and access restrictions."),
        ("Pivoting / lateral movement", "An intruder with existing access might try to reach additional internal systems.", "Use network segmentation reviews and lab-only simulations to check containment and detection coverage."),
    ),
    "Network Traffic": (
        ("Traffic baseline", "Ordinary DNS and TCP events aren't automatically evidence of compromise.", "Compare expected destinations, applications, and time windows to a known-good environment."),
        ("Network vantage point", "Your capture location determines which packets are observable; wired or wireless labels don't imply control.", "Map where data can be legitimately captured and where a mirrored port or authorized sensor would be required."),
    ),
}


def build_plan(finding: Finding, stage: str = "Internal", elaborate: bool = False) -> str:
    if stage not in ("External", "Internal", "Lab"):
        stage = "Internal"
    lines = [
        "# JesterWire | Authorized Pentest Assessment Plan", "",
        f"Finding: {finding.title}",
        f"Category: {finding.category}",
        f"Severity: {finding.severity}",
        f"Observed: {finding.timestamp}",
        f"Source: {finding.source}",
        f"Destination: {finding.destination}",
        f"Current phase: {stage}",
        "", "## What JesterWire actually observed", finding.description,
        "", "## Evidence (sensitive values not retained)",
    ]
    lines.extend(f"- {e}" for e in (finding.evidence or ("No additional evidence available",)))
    if stage == "External":
        lines += ["", "## Phase: Outside-in reconnaissance"]
        lines.extend(f"{i}. {step}" for i, step in enumerate(EXTERNAL_STEPS, 1))
        lines += ["", "Note: This packet finding may have originated in an internal capture. It does not prove the traffic is reachable from outside the network."]
    elif stage == "Lab":
        lines += ["", "## Phase: Isolated training lab", "Use deliberately vulnerable training apps, disposable test accounts, synthetic cookies, and lab-only network paths. No production access or real user secrets."]
    else:
        lines += ["", "## Phase: Authorized internal assessment", "Confirm you have access to the specific host, interface, and traffic in scope. Being connected to a network is not itself permission to test it."]
    lines += ["", "## Validation and remediation checklist"]
    lines.extend(f"{i}. {step}" for i, step in enumerate(STEPS.get(finding.category, STEPS['Network Traffic']), 1))
    if elaborate:
        lines += ["", "## Elaborate: relevant attack paths and risk meaning", "These are educational threat models tied to the evidence, not evidence that any attack succeeded."]
        for name, concept, validation in TECHNIQUES.get(finding.category, TECHNIQUES['Network Traffic']):
            lines += ["", f"### {name}", f"What it means: {concept}", f"How to evaluate safely: {validation}"]
        lines += ["", "## Confidence and limitations", "A named header or field does not prove that a valid credential or authenticated session was captured. Encrypted HTTPS content cannot ordinarily be read from a passive capture."]
    lines += ["", "Authorization, least privilege, and evidence minimization apply throughout. No credential reuse, session replay, forced traffic interception, or unapproved pivoting."]
    return "\n".join(lines)



def build_overview_plan(
    findings: list[Finding], stage: str = "Internal", elaborate: bool = False,
    packet_count: int = 0, adapter: str = "Unknown"
) -> str:
    """Create a useful assessment even when no individual finding is selected.

    This function uses reported evidence only. It does not infer an open port,
    compromised account, or illegal service from a DNS request or a TCP SYN.
    """
    if stage not in ("External", "Internal", "Lab"):
        stage = "Internal"
    counts = Counter(f.category for f in findings)
    titles = Counter(f.title for f in findings)
    lines = [
        "# JesterWire | Full Capture Pentest Assessment Plan", "",
        f"Assessment phase: {stage}",
        f"Capture adapter: {adapter}",
        f"Packets captured: {packet_count:,}",
        f"Reported findings: {len(findings):,}",
        "", "## Executive summary",
        "JesterWire is a passive sensor. These observations do not prove a host is vulnerable, a port is open, or a website is illegal.",
    ]
    if not findings:
        lines += [
            "No events have been loaded. Begin with a synthetic demo, import a JesterWire report, or capture traffic that you are authorized to analyze.",
        ]
    else:
        lines += ["", "## Findings by category"]
        for category, count in counts.most_common():
            lines.append(f"- {category}: {count:,}")
        lines += ["", "## Most common observations"]
        for title, count in titles.most_common(8):
            lines.append(f"- {title}: {count:,}")
    lines += ["", f"## {stage} assessment phase"]
    if stage == "External":
        lines += [f"{i}. {step}" for i, step in enumerate(EXTERNAL_STEPS, 1)]
    elif stage == "Lab":
        lines += [
            "1. Work only with disposable lab VMs and deliberately synthetic accounts, cookies, and traffic.",
            "2. Produce an unencrypted test-login request, then repeat with HTTPS and compare the visible field indicators.",
            "3. Use a segmented synthetic HTTP request and confirm reassembly finds split field names without emitting test secret values.",
            "4. Compare results with a known-good test capture and document detection gaps.",
        ]
    else:
        lines += [
            "1. Document the authorized target hosts, IP ranges, capture point, test window, and owner contact.",
            "2. Identify which IP addresses belong to approved assets; do not interpret third-party traffic as permission to test them.",
            "3. Correlate notable observations with system, firewall, application, and authentication logs where access is explicitly approved.",
        ]
    lines += ["", "## Prioritized follow-up"]
    if counts["Credential Leaks"]:
        lines += [
            "1. PRIORITY: Review plaintext authentication field indicators in the approved application; reproduce with disposable accounts, verify HTTPS enforcement, and rotate any confirmed exposed real secrets through the owner's process.",
        ]
    if counts["Session/Cookie Risks"]:
        lines += [
            "2. PRIORITY: Review unencrypted cookie exposure and Secure / HttpOnly / SameSite flags; use synthetic sessions to validate protections without replaying real user tokens.",
        ]
    if counts["Possible Intrusion"]:
        lines += [
            "3. PRIORITY: Correlate suspected scanning with firewall and endpoint logs. Confirm whether an approved assessment or legitimate application caused it.",
        ]
    if "HTTP GET request" in titles or "HTTP response observed" in titles:
        lines += [
            "- HTTP: Review the reconstructed TCP evidence, noting capture gaps, HTTP/2, chunked bodies, and encrypted TLS are not fully decoded. Not-observed does not mean absent.",
        ]
    if "TCP connection attempt" in titles:
        lines += [
            "- TCP: Validate whether SYN attempts completed. A SYN alone does not establish that a destination port is open.",
        ]
    if "DNS lookup observed" in titles:
        lines += [
            "- DNS: Group repeated service-discovery requests; use records to form an inventory hypothesis, not a verdict about hosted content or compromise.",
        ]
    if not findings:
        lines += ["- Establish a baseline first; the data does not support any risk conclusions yet."]
    lines += [
        "", "## Server discovery: evidence limitations",
        "DNS queries, service names, and contacted ports can suggest potential servers but cannot establish hosting ownership, site content, or illegality. Obtain asset inventories and approved server logs for confirmation.",
        "", "## Completion criteria",
        "- Confirm each conclusion using the correct visibility point, in-scope evidence, and appropriate owner approval.",
        "- Report severity, evidence, uncertainty, remediation owner, and retest result.",
        "- Avoid retaining or exporting live passwords and session tokens.",
        "- For v0.4, verify headers and declared-length bodies reassembled from TCP sequence numbers. Missing packets and unsupported HTTP encodings can still hide details.",
    ]
    if elaborate:
        lines += [
            "", "## Elaborate: Why the observations matter",
            "A captured header name is not the same as a usable credential. For an authorized lab, compare HTTP against HTTPS to illustrate why encryption prevents passive reading of application content.",
            "An open port reports reachable network service state, not proof of a vulnerability. A passive SYN observation by itself cannot establish a service's state.",
            "Tor onion services avoid ordinary exit relays. A local packet capture does not reveal the underlying server simply because traffic uses Tor.",
            "Test suspected weaknesses with synthetic accounts and approved endpoints, then document mitigations.",
        ]
    return "\n".join(lines)
