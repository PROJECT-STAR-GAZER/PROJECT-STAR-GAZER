# JesterWire v0.7 | Project Star Gazer

**Architect:** Jester  
**Coder:** ChatGPT (OpenAI)

JesterWire is a Python network evidence explorer and authorized security-assessment companion. Version 0.7 adds **Wireshark's TShark protocol-analysis engine** to the existing PCAP recorder, security-finding categories, HTTP reassembly, and pentest-plan interface.

## What changed in v0.7

**TShark Explorer** is now a button on the main toolbar. It opens a separate window showing the selected PCAP through Wireshark's mature dissectors:

- **Packet list** with frame number, relative time, source/destination, protocol, length, and Info column.
- **Wireshark display filters**, including `tcp`, `http`, `dns`, `tcp.stream == 0`, `ip.addr == 192.0.2.25`.
- **Decoded Packet Details**, supplied by TShark's `-V` option.
- **Hex / ASCII**, supplied by TShark's `-x` option.
- **Follow TCP Stream**, supplied by TShark's standard ASCII follow output. Select a TCP packet first.
- **TCP Packets Only** narrows the packet list to the chosen stream.
- **Quick Statistics** summarizes protocols, visible TCP stream IDs, and top source addresses in the current preview.
- **Open in Wireshark** opens the same local file in the native Wireshark interface when available.
- **Build Plan for Packet** creates an evidence-linked checklist for the selected packet (or a full-report plan if none is selected).

These are general-purpose inspection features, **not** automated credential collection, login attempts, session replay, or exploitation. Original PCAP bytes are preserved without modification. Treat PCAPs and packet-inspection outputs as potentially sensitive.

### Setup on Windows

1. Install **Python 3.11+** and [Wireshark](https://www.wireshark.org/download.html) with the **TShark** component installed. Confirm `C:\Program Files\Wireshark\tshark.exe` exists. If Wireshark is installed somewhere else, set the `TSHARK_PATH` environment variable to the full path of `tshark.exe`.
2. For **live capture**, install/enable [Npcap](https://npcap.com/), choose an adapter, and ensure you have permission to capture traffic on it.
3. Extract the ZIP and run `setup_windows.bat` followed by `launch_windows.bat`.
4. **First try it without network access:** click **Try Training PCAP**, then **TShark Explorer**. The bundled sample contains fictional `jester` / `jester123` and `session=jw9fj29fj29f` over plain HTTP for controlled education.
5. Try a display filter such as `http` or `tcp`. Select a packet, click **Decoded Packet Details** or **Hex / ASCII**. For a TCP packet, click **Follow TCP Stream**.

### Record a new PCAP

Choose an authorized interface and click **Start + Save PCAP**. Select a unique `.pcap` filename. Stop recording to finalize it, click **Open Last Capture**, then **TShark Explorer**. Do not share PCAPs publicly, and never publish private network traces to GitHub.

**PCAP != JSON.** Raw packet evidence is saved in `.pcap` files. Export Report writes a separate summarized `.json`. Old JSON-only reports cannot be turned back into PCAPs.

## Why a report may show no vulnerabilities

Many legitimate captures contain DNS queries, encrypted web traffic, routine service discovery, and ordinary TCP connections. This does not mean the capture failed. The TShark Explorer gives you packet-level evidence even when none of the heuristic detection rules raise an alert. An open port, HTTP request, or suspicious-looking hostname by itself is not confirmation of compromise.

## Limits and expectations

- **TShark is a separate executable.** `requirements.txt` installs Python packages but **does not install Wireshark/TShark**.
- Wireshark display filters are different from capture filters. The TShark Explorer filters the **existing PCAP**; capture filtering still happens at recording time.
- The viewer limits its packet preview to the first **50,000 frames read** and **2,500 matching rows** to remain responsive. Broader captures and late matches may need Wireshark or a narrower recording.
- Individual decoded output and TCP stream display are capped in size for the UI, but the underlying PCAP is never truncated by these view limits.
- HTTP/2, TLS, QUIC, and other protocols are decoded as far as TShark supports them; ordinary HTTPS payloads are still encrypted without appropriate endpoint secrets.
- The legacy HTTP findings and JSON summary still omit secret values; the **TShark Explorer is a separate generic packet-dissection view**. The app does not automatically extract or classify usable authentication secrets from third-party sessions.
- Live capture is still handled by Scapy/Npcap; v0.7 is a **hybrid integration**, not full feature parity with every Wireshark dialog.
- The development environment did **not** have a real TShark installation or Windows/Npcap hardware. TShark command construction was checked against the official CLI documentation, and the GUI was smoke-tested with a simulated TShark backend. Live integration needs testing on your Windows computer.

## Troubleshooting

If the TShark Explorer shows **TShark missing**:

- Check that `tshark.exe` exists in your Wireshark installation folder.
- In PowerShell, run `& "C:\Program Files\Wireshark\tshark.exe" --version` (adjust path if needed).
- Reinstall Wireshark and include TShark if that executable is absent.

If it opens but shows **No packets matched**, clear the display filter. Confirm the PCAP is a real packet capture, not a JSON report, and consider the 50,000-frame preview limit.

If you want to confirm the new mode is connected to the correct file, start with the bundled training PCAP and inspect frame #1, then filter `http`.

## Tests

```powershell
.venv\Scripts\python.exe -m unittest discover -s tests -p test_tshark_bridge.py -v
```

More Python tests are under `tests/`. The `tests/verify_v07_ui.py` GUI smoke test was run using a simulated TShark/Scapy environment; it doesn't verify a real Windows Wireshark install.

## Credits

**Project:** Star Gazer  
**Application:** JesterWire  
**Architect:** Jester  
**Coder:** ChatGPT (OpenAI)

Official TShark documentation: <https://www.wireshark.org/docs/man-pages/tshark>
