"""Read-only Wireshark/TShark integration for JesterWire.

This module does not capture packets, modify PCAPs, log in to services, or
search for authentication secrets. It invokes TShark's standard packet viewer
and TCP follow utilities for a user-selected local capture.
"""
from __future__ import annotations

import csv
from dataclasses import dataclass
import io
import os
from pathlib import Path
import shutil
import subprocess
import sys
from typing import Sequence


class TSharkError(RuntimeError):
    """A TShark availability or packet-processing error."""


SUPPORTED_EXTENSIONS = {'.pcap', '.pcapng', '.cap'}
MAX_LIST_INPUT_FRAMES = 50000
MAX_DISPLAY_ROWS = 2500
MAX_TEXT_CHARS = 200000
FIELDS = (
    'frame.number', 'frame.time_relative', 'ip.src', 'ipv6.src', 'ip.dst',
    'ipv6.dst', '_ws.col.Protocol', 'frame.len', 'tcp.stream',
    'tcp.srcport', 'tcp.dstport', 'udp.srcport', 'udp.dstport', '_ws.col.Info',
)


@dataclass(frozen=True)
class PacketRow:
    number: int
    time: str
    source: str
    destination: str
    protocol: str
    length: str
    source_port: str
    destination_port: str
    stream: int | None
    info: str


def locate_tshark() -> str | None:
    """Find a TShark executable without changing the user's PATH."""
    candidates = [os.environ.get('TSHARK_PATH'), shutil.which('tshark')]
    if sys.platform == 'win32':
        for base in (os.environ.get('ProgramFiles'), os.environ.get('ProgramFiles(x86)'),
                     r'C:\Program Files', r'C:\Program Files (x86)'):
            if base:
                candidates.append(str(Path(base) / 'Wireshark' / 'tshark.exe'))
    for item in candidates:
        if item and Path(item).is_file():
            return str(Path(item))
    return None


def _capture(path: str | Path) -> str:
    cap = Path(path).expanduser()
    if not cap.is_file():
        raise TSharkError('Choose an existing PCAP or PCAPNG file first.')
    if cap.suffix.lower() not in SUPPORTED_EXTENSIONS:
        raise TSharkError('Expected a .pcap, .pcapng, or .cap capture file.')
    return str(cap.resolve())


def _execute(args: Sequence[str], timeout: int = 40, output_limit: int = 7_000_000) -> str:
    tshark = locate_tshark()
    if tshark is None:
        raise TSharkError('TShark is not installed. Install Wireshark with TShark selected, '
                          'or set the TSHARK_PATH environment variable to tshark.exe.')
    # No shell=True, no TShark-supplied strings are treated as commands.
    try:
        result = subprocess.run([tshark, *args], stdin=subprocess.DEVNULL,
                                stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                timeout=timeout, check=False)
    except subprocess.TimeoutExpired as exc:
        raise TSharkError(f'TShark took longer than {timeout} seconds. Try a smaller capture or narrower filter.') from exc
    except OSError as exc:
        raise TSharkError('Could not run TShark: ' + str(exc)) from exc
    if result.returncode != 0:
        error = result.stderr.decode('utf-8', 'replace').strip()
        raise TSharkError('TShark could not analyze this capture: ' + error[:1200])
    if len(result.stdout) > output_limit:
        raise TSharkError('Output exceeds the viewer limit. Apply a narrower display filter.')
    return result.stdout.decode('utf-8', 'replace')


def tshark_version() -> str:
    result = _execute(['--version'], timeout=12, output_limit=200_000)
    return result.splitlines()[0] if result.strip() else 'TShark detected'


def list_packets(capture_path: str | Path, display_filter: str = '',
                 max_rows: int = MAX_DISPLAY_ROWS) -> tuple[list[PacketRow], str]:
    """Read a bounded summary table. TShark display filters are not shell commands.

    The frame-reading ceiling protects desktop responsiveness; a highly
    selective filter may produce fewer matches when packets are beyond it.
    """
    capture = _capture(capture_path)
    max_rows = max(1, min(int(max_rows), MAX_DISPLAY_ROWS))
    expression = display_filter.strip()
    if len(expression) > 512 or '\x00' in expression or '\n' in expression:
        raise TSharkError('Filter is too long or contains unsupported characters.')
    args = ['-n', '-r', capture, '-c', str(MAX_LIST_INPUT_FRAMES), '-T', 'fields',
            '-E', 'separator=/t', '-E', 'quote=d', '-E', 'occurrence=f',
            '-E', 'escape=y']
    for field in FIELDS:
        args.extend(['-e', field])
    if expression:
        args.extend(['-Y', expression])
    result = _execute(args, timeout=75, output_limit=18_000_000)
    rows: list[PacketRow] = []
    for cols in csv.reader(io.StringIO(result), delimiter='\t', quotechar='"'):
        if len(cols) < len(FIELDS):
            cols += [''] * (len(FIELDS) - len(cols))
        if not cols[0].strip().isdigit():
            continue
        stream = int(cols[8]) if cols[8].strip().isdigit() else None
        rows.append(PacketRow(
            number=int(cols[0]), time=cols[1][:24],
            source=(cols[2] or cols[3])[:80],
            destination=(cols[4] or cols[5])[:80],
            protocol=cols[6][:35], length=cols[7][:10], stream=stream,
            source_port=(cols[9] or cols[11])[:12],
            destination_port=(cols[10] or cols[12])[:12],
            info=cols[13].replace('\\n', ' ').replace('\\t', ' ')[:300],
        ))
        if len(rows) >= max_rows:
            break
    status = (f'Showing first {len(rows):,} matching packets from at most '
              f'{MAX_LIST_INPUT_FRAMES:,} input frames. Filter may exclude later frames.')
    return rows, status


def packet_details(capture_path: str | Path, packet_number: int,
                   hex_view: bool = False) -> str:
    if int(packet_number) < 1:
        raise TSharkError('Invalid packet number.')
    args = ['-n', '-r', _capture(capture_path), '-Y', f'frame.number == {int(packet_number)}']
    args.extend(['-x'] if hex_view else ['-V'])
    text = _execute(args, timeout=50, output_limit=4_000_000)
    if not text.strip():
        raise TSharkError('That packet was not found in this capture.')
    return text[:MAX_TEXT_CHARS] + ('\n... [viewer output limit reached]' if len(text)>MAX_TEXT_CHARS else '')


def follow_tcp(capture_path: str | Path, stream_number: int) -> str:
    """Standard TShark follow-tcp output; a general-purpose viewer only."""
    stream_number = int(stream_number)
    if stream_number < 0 or stream_number > 100_000_000:
        raise TSharkError('Invalid TCP stream index.')
    text = _execute(['-n', '-r', _capture(capture_path), '-q',
                     '-z', f'follow,tcp,ascii,{stream_number}'], timeout=60,
                    output_limit=5_000_000)
    if not text.strip():
        raise TSharkError('No stream contents were available.')
    return text[:MAX_TEXT_CHARS] + ('\n... [viewer output limit reached]' if len(text)>MAX_TEXT_CHARS else '')
