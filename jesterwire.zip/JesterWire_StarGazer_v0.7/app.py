"""JesterWire desktop app | Project Star Gazer | Jester (architect) + ChatGPT (coder)."""
from __future__ import annotations

from collections import Counter
from datetime import datetime
from pathlib import Path
import json
import socket
import ipaddress
import queue
import threading
import tkinter as tk
from tkinter import filedialog, messagebox, ttk
from typing import Any

from scapy.all import AsyncSniffer, PcapReader, conf, get_if_list

from engine import Detector, Finding, demo_findings
from captureio import CaptureWriter, default_capture_dir, suggested_filename, duplicate_pcap
from insights import grouped_dns, summarize_legacy_findings, SERVICE_HINTS
from plans import build_plan, build_overview_plan
from interfaces import Adapter, enumerate_adapters, adapter_explanation

BG = "#0B1020"
SURFACE = "#131C2E"
SURFACE2 = "#1B2840"
BORDER = "#2B3C56"
TEXT = "#EDF3FB"
MUTED = "#9DACBF"
ACCENT = "#56DDC5"
YELLOW = "#F8CA6B"
RED = "#FF7D90"

CATEGORIES = (
    "All Activity",
    "Credential Leaks",
    "Session/Cookie Risks",
    "Possible Intrusion",
    "Network Traffic",
)
SEVERITY_COLOR = {"HIGH": RED, "MEDIUM": YELLOW, "INFO": ACCENT}


class JesterWireApp(tk.Tk):
    def __init__(self) -> None:
        super().__init__()
        self.title("JesterWire v0.7 | Project Star Gazer")
        self.geometry("1330x790")
        self.minsize(1050, 650)
        self.configure(bg=BG)
        self.findings: list[Finding] = []
        self.display_ids: list[int] = []
        self.selected_category = "All Activity"
        self.selected_index: int | None = None
        self.packet_count = 0
        self.mode = "DEMO MODE"
        self.detector = Detector()
        self.loaded_summary: dict = {}
        self.sniffer: AsyncSniffer | None = None
        self.capture_writer: CaptureWriter | None = None
        self.capture_stopping = False
        self.last_capture_path: str | None = None
        self.active_pcap_path: str | None = None
        self.worker_running = False
        self.messages: queue.Queue[tuple[str, Any]] = queue.Queue()
        self.category_buttons: dict[str, tk.Button] = {}
        self.search_var = tk.StringVar()
        self.interface_var = tk.StringVar()
        self.focus_ip_var = tk.StringVar()
        self.interface_choices: dict[str, Adapter] = {}
        self._configure_styles()
        self._create_layout()
        self.after(125, self._poll_queue)
        self.after(200, self.load_demo)
        self.protocol("WM_DELETE_WINDOW", self._on_close)

    def _configure_styles(self) -> None:
        style = ttk.Style(self)
        style.theme_use("clam")
        style.configure("Dark.Treeview", background=SURFACE, foreground=TEXT, fieldbackground=SURFACE,
                        rowheight=36, borderwidth=0, font=("Segoe UI", 10))
        style.map("Dark.Treeview", background=[("selected", "#264A58")], foreground=[("selected", "#FFFFFF")])
        style.configure("Dark.Treeview.Heading", background=SURFACE2, foreground=MUTED,
                        font=("Segoe UI", 9, "bold"), relief="flat")
        style.map("Dark.Treeview.Heading", background=[("active", BORDER)])
        style.configure("Dark.TCombobox", fieldbackground=SURFACE2, background=SURFACE2,
                        foreground=TEXT, arrowcolor=ACCENT)

    def _make_button(self, parent: tk.Widget, title: str, command: Any, accent: bool = False,
                     width: int | None = None) -> tk.Button:
        kwargs = {"width": width} if width else {}
        return tk.Button(parent, text=title, command=command, bg=ACCENT if accent else SURFACE2,
                         fg=BG if accent else TEXT, activebackground="#42BDA9" if accent else BORDER,
                         activeforeground=BG if accent else TEXT, relief="flat", bd=0,
                         cursor="hand2", padx=14, pady=10, font=("Segoe UI", 9, "bold"), **kwargs)

    def _make_text(self, parent: tk.Widget, value: str, font_size: int = 10,
                   color: str = TEXT, bold: bool = False, **kw: Any) -> tk.Label:
        return tk.Label(parent, text=value, bg=kw.pop("bg", BG), fg=color,
                        font=("Segoe UI", font_size, "bold" if bold else "normal"), **kw)

    def _create_layout(self) -> None:
        top = tk.Frame(self, bg=BG)
        top.pack(fill="x", padx=24, pady=(18, 12))
        tk.Label(top, text="◈  JESTERWIRE", bg=BG, fg=TEXT,
                 font=("Segoe UI", 21, "bold")).pack(side="left")
        self.mode_label = self._make_text(top, "DEMO MODE", 9, YELLOW, True)
        self.mode_label.pack(side="left", padx=(18, 0), pady=9)
        self._make_button(top, "Credits", self.show_credits).pack(side="right", padx=(8, 0))
        self._make_button(top, "Export Report", self.export_report).pack(side="right", padx=(8, 0))
        self._make_button(top, "Build Pentest Plan", self.open_overview_plan, accent=True).pack(side="right", padx=(8, 0))
        self._make_button(top, "TShark Explorer", self.open_tshark_explorer, accent=True).pack(side="right", padx=(8, 0))
        self._make_button(top, "Explore Traffic", self.explore_traffic).pack(side="right", padx=(8, 0))
        self._make_button(top, "Load Demo", self.load_demo).pack(side="right")

        stats = tk.Frame(self, bg=BG)
        stats.pack(fill="x", padx=24, pady=(0, 14))
        self.stat_labels: dict[str, tk.Label] = {}
        for name, label in (("packets", "PACKETS REVIEWED"), ("findings", "FINDINGS"),
                            ("alerts", "POTENTIAL RISKS"), ("http", "HTTP MESSAGES")):
            box = tk.Frame(stats, bg=SURFACE, highlightbackground=BORDER, highlightthickness=1)
            box.pack(side="left", fill="x", expand=True, padx=(0, 10))
            self._make_text(box, label, 9, MUTED, True, bg=SURFACE).pack(anchor="w", padx=16, pady=(12, 1))
            number = self._make_text(box, "0", 23, TEXT, True, bg=SURFACE)
            number.pack(anchor="w", padx=16, pady=(0, 11))
            self.stat_labels[name] = number

        toolbar = tk.Frame(self, bg=SURFACE, highlightbackground=BORDER, highlightthickness=1)
        toolbar.pack(fill="x", padx=24, pady=(0, 12))
        self._make_button(toolbar, "Open PCAP", self.open_pcap).pack(side="left", padx=(10, 4), pady=8)
        self._make_button(toolbar, "Try Training PCAP", self.open_training_pcap).pack(side="left", padx=(0, 4), pady=8)
        self._make_button(toolbar, "Open JSON Report", self.open_report).pack(side="left", padx=(0, 6), pady=8)
        self._make_button(toolbar, "Start + Save PCAP", self.start_live, accent=True).pack(side="left", padx=(0, 8))
        self._make_button(toolbar, "Stop", self.stop_live).pack(side="left", padx=(0, 18))
        self._make_text(toolbar, "Adapter", 9, MUTED, bg=SURFACE).pack(side="left", padx=(0, 8))
        self.adapter = ttk.Combobox(toolbar, textvariable=self.interface_var, style="Dark.TCombobox", width=43, state="readonly")
        self.adapter.pack(side="left", pady=12)
        try:
            available = getattr(conf, "ifaces", None)
            records = list(available.values()) if available is not None else []
            choices = enumerate_adapters(get_if_list(), records)
            self.interface_choices = {choice.label: choice for choice in choices}
            self.adapter["values"] = [choice.label for choice in choices]
            if choices:
                default = str(conf.iface)
                chosen = next((choice for choice in choices if choice.capture_name == default), choices[0])
                self.interface_var.set(chosen.label)
        except Exception:
            pass
        self._make_button(toolbar, "Adapter Info", self.show_adapter_info).pack(side="left", padx=(7, 5))

        capturebar = tk.Frame(self, bg=BG)
        capturebar.pack(fill="x", padx=24, pady=(0, 12))
        self._make_button(capturebar, "Open Last Capture", self.open_last_capture).pack(side="left", padx=(0, 6))
        self._make_button(capturebar, "Save PCAP Copy", self.save_capture_copy).pack(side="left", padx=(0, 6))
        self._make_button(capturebar, "PCAP Help", self.show_pcap_help).pack(side="left", padx=(0, 16))
        self._make_text(capturebar, "Focus capture on IP (optional):", 9, MUTED).pack(side="left", padx=(0, 7))
        tk.Entry(capturebar, textvariable=self.focus_ip_var, bg=SURFACE2, fg=TEXT,
                 insertbackground=TEXT, width=22, relief="flat", font=("Segoe UI", 10)).pack(side="left", ipady=8)
        self.capture_label = self._make_text(capturebar, "Capture file: none", 9, MUTED)
        self.capture_label.pack(side="left", padx=(16, 0))

        main = tk.Frame(self, bg=BG)
        main.pack(fill="both", expand=True, padx=24, pady=(0, 14))

        sidebar = tk.Frame(main, bg=SURFACE, width=217, highlightbackground=BORDER, highlightthickness=1)
        sidebar.pack(side="left", fill="y", padx=(0, 12))
        sidebar.pack_propagate(False)
        self._make_text(sidebar, "DETECTION CATEGORIES", 9, MUTED, True, bg=SURFACE).pack(
            anchor="w", padx=14, pady=(18, 12))
        for category in CATEGORIES:
            button = tk.Button(sidebar, text=category, anchor="w", bg=SURFACE, fg=MUTED,
                               activebackground=SURFACE2, activeforeground=ACCENT,
                               relief="flat", bd=0, padx=14, pady=11, cursor="hand2",
                               wraplength=175, justify="left", font=("Segoe UI", 10),
                               command=lambda c=category: self.change_category(c))
            button.pack(fill="x", padx=7, pady=2)
            self.category_buttons[category] = button
        self._make_text(sidebar, "Project Star Gazer", 9, MUTED, bg=SURFACE).pack(side="bottom", pady=18)

        center = tk.Frame(main, bg=SURFACE, highlightbackground=BORDER, highlightthickness=1)
        center.pack(side="left", fill="both", expand=True, padx=(0, 12))
        header = tk.Frame(center, bg=SURFACE)
        header.pack(fill="x", padx=14, pady=(15, 12))
        self.section_title = self._make_text(header, "All Activity", 15, TEXT, True, bg=SURFACE)
        self.section_title.pack(side="left")
        search = tk.Entry(header, textvariable=self.search_var, width=29, bg=SURFACE2, fg=TEXT,
                          insertbackground=TEXT, relief="flat", bd=0, font=("Segoe UI", 10))
        search.pack(side="right", ipady=8, padx=2)
        self.search_var.trace_add("write", lambda *_: self.refresh_table())
        self._make_text(header, "Search  ", 9, MUTED, bg=SURFACE).pack(side="right")
        table_outer = tk.Frame(center, bg=SURFACE)
        table_outer.pack(fill="both", expand=True, padx=12, pady=(0, 12))
        self.table = ttk.Treeview(table_outer, columns=("time", "severity", "title", "src", "dst"),
                                  show="headings", selectmode="browse", style="Dark.Treeview")
        columns = {"time": ("TIME", 78), "severity": ("LEVEL", 76), "title": ("FINDING", 250),
                   "src": ("SOURCE", 116), "dst": ("DESTINATION", 116)}
        for key, (heading, width) in columns.items():
            self.table.heading(key, text=heading)
            self.table.column(key, width=width, minwidth=55,
                              stretch=key in ("title", "src", "dst"))
        self.table.tag_configure("HIGH", foreground=RED)
        self.table.tag_configure("MEDIUM", foreground=YELLOW)
        self.table.pack(side="left", fill="both", expand=True)
        scroll = ttk.Scrollbar(table_outer, orient="vertical", command=self.table.yview)
        scroll.pack(side="right", fill="y")
        self.table.configure(yscrollcommand=scroll.set)
        self.table.bind("<<TreeviewSelect>>", self.on_select)

        detail = tk.Frame(main, bg=SURFACE, width=300, highlightbackground=BORDER, highlightthickness=1)
        detail.pack(side="left", fill="y")
        detail.pack_propagate(False)
        self._make_text(detail, "JESTER EXPLAINS", 11, ACCENT, True, bg=SURFACE).pack(
            anchor="w", padx=15, pady=(18, 6))
        self.detail_title = self._make_text(detail, "Select a finding", 13, TEXT, True,
                                            bg=SURFACE, wraplength=268, justify="left")
        self.detail_title.pack(anchor="w", padx=15, pady=(4, 12))
        self.detail_text = tk.Text(detail, bg=SURFACE, fg=MUTED, relief="flat", bd=0,
                                   highlightthickness=0, wrap="word", font=("Segoe UI", 10),
                                   padx=15, pady=4, insertbackground=TEXT)
        self.detail_text.pack(fill="both", expand=True)
        self.detail_text.insert("1.0", "Select an event to see what happened, why it matters, and what evidence was detected.\n\nReal credential and cookie values are never saved in findings.")
        self.detail_text.configure(state="disabled")
        self.plan_button = self._make_button(detail, "Build Pentest Plan  →", self.open_plan, accent=True)
        self.plan_button.pack(fill="x", padx=14, pady=(12, 18))

        bottom = tk.Frame(self, bg=BG)
        bottom.pack(fill="x", padx=24, pady=(0, 15))
        self.status = self._make_text(bottom, "Ready", 9, MUTED)
        self.status.pack(side="left")
        self._make_text(bottom, "PCAP recording + TShark dissection • v0.7 • No AI chat yet", 9, MUTED).pack(side="right")
        self._update_category_style()

    def _update_category_style(self) -> None:
        counts = Counter(item.category for item in self.findings)
        for name, button in self.category_buttons.items():
            selected = name == self.selected_category
            count = len(self.findings) if name == "All Activity" else counts[name]
            button.configure(text=f"{name}  ({count})", bg=SURFACE2 if selected else SURFACE,
                             fg=ACCENT if selected else MUTED,
                             font=("Segoe UI", 10, "bold" if selected else "normal"))

    def _set_mode(self, mode: str, status: str) -> None:
        self.mode = mode
        self.mode_label.configure(text=mode, fg=YELLOW if mode == "DEMO MODE" else ACCENT)
        self.status.configure(text=status)
        self._update_stats()

    def _update_stats(self) -> None:
        self.stat_labels["packets"].configure(text=f"{self.packet_count:,}")
        self.stat_labels["http"].configure(text=f"{self.detector.http_message_count:,}" if self.mode != "REPORT REVIEW" else "—")
        self.stat_labels["findings"].configure(text=f"{len(self.findings):,}")
        self.stat_labels["alerts"].configure(text=f"{sum(f.severity != 'INFO' for f in self.findings):,}")
        self._update_category_style()

    def clear_findings(self) -> None:
        self.findings.clear()
        self.packet_count = 0
        self.selected_index = None
        self.table.delete(*self.table.get_children())
        self._show_details(None)
        self.loaded_summary = {}
        self._update_stats()

    def add_findings(self, new_findings: list[Finding]) -> None:
        if not new_findings:
            return
        self.findings.extend(new_findings)
        # In-memory results cap avoids runaway resource usage during long sessions.
        if len(self.findings) > 3000:
            self.findings = self.findings[-3000:]
            self.selected_index = None
            self._show_details(None)
        self.refresh_table()
        self._update_stats()

    def refresh_table(self) -> None:
        term = self.search_var.get().lower().strip()
        selected_finding = self.findings[self.selected_index] if (
            self.selected_index is not None and self.selected_index < len(self.findings)) else None
        self.table.delete(*self.table.get_children())
        self.display_ids = []
        for i, item in enumerate(self.findings):
            if self.selected_category != "All Activity" and item.category != self.selected_category:
                continue
            if term and not any(term in part.lower() for part in (
                    item.title, item.source, item.destination, item.protocol, item.description, item.category)):
                continue
            idx = len(self.display_ids)
            self.display_ids.append(i)
            self.table.insert("", "end", iid=str(idx), values=(
                item.timestamp, item.severity, item.title, item.source, item.destination),
                tags=(item.severity,))
        if selected_finding is not None:
            try:
                new_index = self.findings.index(selected_finding)
                visible = self.display_ids.index(new_index)
                self.table.selection_set(str(visible))
            except ValueError:
                pass
        self.section_title.configure(text=self.selected_category)

    def change_category(self, category: str) -> None:
        self.selected_category = category
        self._update_category_style()
        self.refresh_table()

    def on_select(self, _event: Any = None) -> None:
        selection = self.table.selection()
        if not selection:
            return
        position = int(selection[0])
        if position >= len(self.display_ids):
            return
        self.selected_index = self.display_ids[position]
        self._show_details(self.findings[self.selected_index])

    def _show_details(self, finding: Finding | None) -> None:
        self.detail_title.configure(text=finding.title if finding else "Select a finding")
        if finding:
            content = (f"{finding.category.upper()}  •  {finding.severity}\n\n"
                       f"{finding.description}\n\n"
                       f"Source: {finding.source}\n"
                       f"Destination: {finding.destination}\n"
                       f"Protocol: {finding.protocol}\n"
                       f"Time: {finding.timestamp}\n\n"
                       "EVIDENCE\n" + "\n".join(f"• {line}" for line in finding.evidence) +
                       "\n\nThis is an indicator for review, not proof of compromise.")
        else:
            content = "Select an event to inspect the evidence and generate a finding-specific pentest assessment plan."
        self.detail_text.configure(state="normal")
        self.detail_text.delete("1.0", "end")
        self.detail_text.insert("1.0", content)
        self.detail_text.configure(state="disabled")

    def load_demo(self) -> None:
        if self.worker_running or self.capture_stopping or (self.sniffer and self.sniffer.running):
            messagebox.showinfo("Capture running", "Stop the current capture or import first.")
            return
        self.clear_findings()
        self.active_pcap_path = None
        self.capture_label.configure(text="Demo: open Training PCAP to see packets")
        examples, count = demo_findings()
        self.packet_count = count
        self.detector = Detector()
        self.detector.http_message_count = sum(f.title.startswith("HTTP ") or f.title == "HTTP response observed" for f in examples)
        self.add_findings(examples)
        self.change_category("All Activity")
        self._set_mode("DEMO MODE", "Showing synthetic split HTTP login traffic and other examples. No real network capture is active.")

    def open_report(self) -> None:
        """Open reports previously exported by JesterWire v0.1 through v0.4."""
        if self.worker_running or self.capture_stopping or (self.sniffer and self.sniffer.running):
            messagebox.showinfo("Busy", "Stop the current capture first.")
            return
        path = filedialog.askopenfilename(title="Open JesterWire JSON report", filetypes=[
            ("JesterWire JSON", "*.json"), ("All files", "*.*")])
        if not path:
            return
        try:
            from pathlib import Path
            file_path = Path(path)
            if file_path.stat().st_size > 8 * 1024 * 1024:
                raise ValueError("Report exceeds the 8 MB import limit.")
            with file_path.open("r", encoding="utf-8") as file:
                report = json.load(file)
            if not isinstance(report, dict) or report.get("application") != "JesterWire":
                raise ValueError("This does not look like a JesterWire report.")
            raw = report.get("findings", [])
            if not isinstance(raw, list):
                raise ValueError("The report's findings must be a list.")
            loaded = []
            for entry in raw[:3000]:
                if not isinstance(entry, dict):
                    continue
                def field(key: str) -> str:
                    return str(entry.get(key, ""))[:400]
                evidence = entry.get("evidence", [])
                if not isinstance(evidence, list):
                    evidence = []
                # Imports are designed for JesterWire's own redacted evidence summaries.
                # Detect common accidentally embedded sensitive key/value forms and hide values.
                import re
                cleaned = []
                for part in evidence[:30]:
                    value = str(part)[:400]
                    if re.search(r"(?i)\b(password|passwd|token|authorization|set-cookie|cookie|api[_-]?key)\s*[:=]", value):
                        value = re.sub(r"(?i)(\b(?:password|passwd|token|authorization|set-cookie|cookie|api[_-]?key)\s*[:=])\s*\S+", r"\1 [VALUE HIDDEN]", value)
                    cleaned.append(value)
                loaded.append(Finding(field("category"), field("severity"), field("title"),
                                      field("description"), field("source"), field("destination"),
                                      field("protocol"), field("timestamp"), tuple(cleaned)))
            packet_count = max(0, int(report.get("packet_count", 0)))
        except (OSError, ValueError, TypeError, json.JSONDecodeError) as exc:
            messagebox.showerror("Report import failed", str(exc))
            return
        self.clear_findings()
        self.active_pcap_path = None
        self.capture_label.configure(text="JSON summary only: no PCAP")
        self.detector = Detector()
        self.loaded_summary = {
            'http': report.get('http_observations', []) if isinstance(report.get('http_observations', []),list) else [],
            'tcp': report.get('tcp_flows', []) if isinstance(report.get('tcp_flows', []),list) else [],
            'protocols': report.get('protocol_counts', {}) if isinstance(report.get('protocol_counts', {}),dict) else {},
            'peers': report.get('peer_counts', {}) if isinstance(report.get('peer_counts', {}),dict) else {},
            'dns': report.get('dns_observations', []) if isinstance(report.get('dns_observations', []),list) else [],
            'version': str(report.get('version','?'))[:16],
        }
        self.packet_count = packet_count
        self.add_findings(loaded)
        self.change_category("All Activity")
        self._set_mode("REPORT REVIEW", f"Loaded {len(loaded):,} saved findings from {file_path.name}. Reopen a PCAP to run reconstruction on the original packets.")

    def open_pcap(self, path: str | None = None) -> None:
        if self.worker_running or self.capture_stopping or (self.sniffer and self.sniffer.running):
            messagebox.showinfo("Busy", "Stop the current operation first.")
            return
        if path is None:
            path = filedialog.askopenfilename(title="Open a PCAP from an authorized capture", filetypes=[
                ("PCAP files", "*.pcap *.pcapng *.cap"), ("All files", "*.*")])
        if not path:
            return
        self.active_pcap_path = str(path)
        self.capture_label.configure(text="Loaded: " + Path(path).name[:50])
        self.clear_findings()
        self.detector = Detector()
        self.worker_running = True
        self._set_mode("PCAP REVIEW", f"Analyzing {path.replace(chr(92), '/').rsplit('/', 1)[-1]} ...")
        threading.Thread(target=self._pcap_worker, args=(path,), daemon=True).start()

    def _pcap_worker(self, path: str) -> None:
        try:
            # Scapy's PcapReader handles PCAP and many PCAPNG files; some
            # specialized capture formats need conversion with Wireshark.
            with PcapReader(path) as reader:
                for i, packet in enumerate(reader, start=1):
                    found = self.detector.analyze(packet)
                    if found and self.messages.qsize() < 10000:
                        self.messages.put(("findings", found))
                    if i % 200 == 0:
                        self.messages.put(("packet_count", i))
                    if i >= 200000:
                        self.messages.put(("status", "Stopped after 200,000 packets (v0.4 import limit)."))
                        break
            self.messages.put(("packet_count", self.detector.packet_count))
            self.messages.put(("finished", f"PCAP analysis complete. Reconstructed {self.detector.http_message_count:,} HTTP messages."))
        except Exception as exc:
            self.messages.put(("error", f"Couldn't read this capture: {exc}"))
        finally:
            self.messages.put(("worker_done", None))

    def show_pcap_help(self) -> None:
        messagebox.showinfo("JesterWire | What is a PCAP?",
            "A PCAP is the actual packet recording. HTTP is only one kind of traffic inside it.\n\n"
            "Start + Save PCAP: choose a filename and an adapter, then capture.\n"
            "Stop: finish writing the PCAP safely.\n"
            "Open Last Capture: reanalyze that saved recording in Evidence Explorer.\n"
            "Export Report: saves only a sanitized JSON summary, NOT packets.\n\n"
            "PCAP files may contain private unencrypted data. Keep them local and don't upload or share them publicly.\n"
            "Capture only traffic you're authorized to inspect.")

    def open_training_pcap(self) -> None:
        sample = Path(__file__).resolve().parent / "examples" / "synthetic_split_login.pcap"
        if not sample.is_file():
            messagebox.showerror("Missing training file", f"Cannot find {sample}")
            return
        self.open_pcap(str(sample))

    def open_last_capture(self) -> None:
        if not self.last_capture_path or not Path(self.last_capture_path).is_file():
            messagebox.showinfo("No saved PCAP yet", "Use Start + Save PCAP, stop the capture, then reopen it here.\nYou can also try the bundled Training PCAP.")
            return
        self.open_pcap(self.last_capture_path)

    def save_capture_copy(self) -> None:
        if self.capture_stopping or (self.sniffer and self.sniffer.running):
            messagebox.showinfo("Capture active", "Stop the live capture before making a copy of the PCAP.")
            return
        source = self.active_pcap_path or self.last_capture_path
        if not source or not Path(source).is_file():
            messagebox.showinfo("No PCAP to copy", "Load a PCAP or finish a live recording first. JSON reports don't contain raw packets.")
            return
        suffix = Path(source).suffix.lower()
        if suffix not in ('.pcap', '.pcapng'):
            messagebox.showerror("Unsupported format", "Only PCAP and PCAPNG files can be copied.")
            return
        dest = filedialog.asksaveasfilename(title="Save a copy of your capture", defaultextension=suffix,
                initialfile=Path(source).name, filetypes=[("Capture file", "*" + suffix)])
        if not dest:
            return
        try:
            duplicate_pcap(source, dest)
            self.status.configure(text="Saved a copy of " + Path(dest).name)
        except (OSError, ValueError) as exc:
            messagebox.showerror("Could not save PCAP copy", str(exc))

    def start_live(self) -> None:
        if self.worker_running or self.capture_stopping:
            messagebox.showinfo("Busy", "Finish the current operation first.")
            return
        if self.sniffer and self.sniffer.running:
            messagebox.showinfo("Already capturing", "Live capture is already running.")
            return
        selected = self.interface_choices.get(self.interface_var.get())
        if not selected:
            messagebox.showerror("No adapter selected", "Choose a network adapter first. Check Npcap if no adapters are shown.")
            return
        ip_filter = self.focus_ip_var.get().strip()
        if ip_filter:
            try:
                ip_filter = str(ipaddress.ip_address(ip_filter))
            except ValueError:
                messagebox.showerror("Invalid focus IP", "Enter one IPv4 or IPv6 address or leave this blank. Never enter a host name or filter expression here.")
                return
        folder = default_capture_dir()
        try:
            folder.mkdir(parents=True, exist_ok=True)
        except OSError as exc:
            messagebox.showerror("Cannot create capture folder", str(exc))
            return
        path = filedialog.asksaveasfilename(title="Save raw packet recording as PCAP", initialdir=str(folder),
            initialfile=suggested_filename(), defaultextension=".pcap",
            filetypes=[("Packet capture (.pcap)", "*.pcap")])
        if not path:
            self.status.configure(text="Capture canceled: no PCAP filename chosen.")
            return
        path = str(Path(path).with_suffix('.pcap'))
        if Path(path).exists():
            messagebox.showerror("File already exists", "Choose a new filename so an earlier capture can't be overwritten.")
            return
        if not messagebox.askyesno("Capture authorization and privacy",
            "Start recording visible packets on this adapter?\n\n"
            "Only record traffic you're authorized to inspect. The PCAP stores RAW packets and may contain private information, even though JSON findings hide secrets.\n\n"
            "The recording remains on this computer unless you choose to share it."):
            return
        writer = CaptureWriter(path)
        try:
            writer.start()
        except Exception as exc:
            messagebox.showerror("Cannot create PCAP", str(exc))
            return
        self.clear_findings()
        self.detector = Detector()
        self.capture_writer = writer
        try:
            self.sniffer = AsyncSniffer(iface=selected.capture_name, prn=self._on_live_packet,
                store=False, **({'filter': 'host ' + ip_filter} if ip_filter else {}))
            self.sniffer.start()
        except Exception as exc:
            writer.close()
            self.capture_writer = None
            self.sniffer = None
            messagebox.showerror("Live capture unavailable", f"Check Npcap, permissions, capture filter, and adapter.\n\n{exc}")
            return
        self.last_capture_path = str(path)
        self.active_pcap_path = str(path)
        self.capture_label.configure(text="Recording: " + Path(path).name[:45])
        scope = ('Focus IP ' + ip_filter) if ip_filter else 'All traffic visible on interface'
        self._set_mode("LIVE CAPTURE", f"Recording to {Path(path).name} | {selected.medium} | {scope}. Stop to finalize the file.")

    def _on_live_packet(self, packet: Any) -> None:
        writer = self.capture_writer
        if writer is not None and not writer.closed and not writer.error:
            try:
                writer.write(packet)
            except Exception as exc:
                self.messages.put(("capture_write_error", str(exc)))
        try:
            found = self.detector.analyze(packet)
            if found and self.messages.qsize() < 10000:
                self.messages.put(("findings", found))
            if self.detector.packet_count % 100 == 0:
                self.messages.put(("packet_count", self.detector.packet_count))
        except Exception:
            # Malformed packets should not terminate capture callbacks.
            pass

    def stop_live(self) -> None:
        if self.capture_stopping:
            return
        if not self.sniffer and not self.capture_writer:
            self.status.configure(text="No live capture is running.")
            return
        self.capture_stopping = True
        self.status.configure(text="Stopping capture and finalizing PCAP...")
        threading.Thread(target=self._stop_capture_worker, daemon=True).start()

    def _stop_capture_worker(self) -> None:
        errors: list[str] = []
        try:
            if self.sniffer and self.sniffer.running:
                self.sniffer.stop(join=True)
        except Exception as exc:
            errors.append('Sniffer stop: ' + str(exc))
        writer = self.capture_writer
        if writer:
            try:
                writer.close()
            except Exception as exc:
                errors.append('PCAP write: ' + str(exc))
            if writer.error:
                errors.append('Packet write: ' + writer.error)
        saved = writer and writer.path.is_file() and writer.path.stat().st_size > 24
        self.messages.put(("capture_stopped", {
            "saved": bool(saved), "path": str(writer.path) if writer else "",
            "packets_saved": writer.packet_count if writer else 0,
            "packets_seen": self.detector.packet_count,
            "errors": errors,
        }))

    def _poll_queue(self) -> None:
        batch: list[Finding] = []
        for _ in range(350):
            try:
                action, value = self.messages.get_nowait()
            except queue.Empty:
                break
            if action == "findings":
                batch.extend(value)
            elif action == "packet_count":
                self.packet_count = value
            elif action == "status":
                self.status.configure(text=value)
            elif action == "finished":
                self.status.configure(text=value)
            elif action == "error":
                self.status.configure(text=value)
                messagebox.showerror("JesterWire", value)
            elif action == "worker_done":
                self.worker_running = False
            elif action == "capture_write_error":
                self.status.configure(text="PCAP write error: " + str(value)[:180])
                self.stop_live()
            elif action == "capture_stopped":
                self.capture_stopping = False
                self.sniffer = None
                self.capture_writer = None
                self.packet_count = value['packets_seen']
                saved = value['saved'] and not value['errors']
                if saved:
                    self.capture_label.configure(text="Saved: " + Path(value['path']).name[:50])
                    self._set_mode("CAPTURE STOPPED", f"Saved {value['packets_saved']:,} raw packets to {value['path']}. Click Open Last Capture to inspect them.")
                else:
                    detail = '; '.join(value['errors']) or 'No packets were saved (the capture may have been empty).'
                    self._set_mode("CAPTURE STOPPED", "Capture stopped. PCAP incomplete or not saved: " + detail)
                    if value['errors']:
                        messagebox.showerror("PCAP recording issue", '; '.join(value['errors']))
        if batch:
            self.add_findings(batch)
        else:
            self._update_stats()
        self.after(125, self._poll_queue)

    def open_tshark_explorer(self) -> None:
        """Open full packet dissection on a saved PCAP (never the live writer)."""
        if self.capture_stopping or (self.sniffer and self.sniffer.running):
            messagebox.showinfo("Finish recording", "Stop the recording to finalize its PCAP before opening the TShark Explorer.")
            return
        source = self.active_pcap_path or self.last_capture_path
        if not source or not Path(source).is_file():
            messagebox.showinfo("No capture open", "Open a PCAP or use Try Training PCAP first. A JSON report cannot reconstruct raw packets.")
            return
        from tshark_explorer import launch_explorer
        from tshark_bridge import TSharkError
        try:
            launch_explorer(self, source, self.plan_from_packet)
        except TSharkError as exc:
            messagebox.showerror("TShark Explorer", str(exc))

    def plan_from_packet(self, row: Any = None) -> None:
        """Generate an evidence-linked assessment for one observed packet."""
        if row is None:
            self.open_overview_plan()
            return
        timestamp = str(getattr(row, 'time', '') or 'from saved PCAP')
        details = [
            f"Captured frame: #{getattr(row, 'number', '?')}",
            f"Protocol: {getattr(row, 'protocol', 'Unknown')}",
            f"Source port: {getattr(row, 'source_port', '')}",
            f"Destination port: {getattr(row, 'destination_port', '')}",
            f"Packet length: {getattr(row, 'length', '')} bytes",
        ]
        if getattr(row, 'stream', None) is not None:
            details.append(f"TCP stream number: {row.stream}")
        selected = Finding(
            category='Network Traffic', severity='INFO',
            title=f"Packet #{row.number} | {row.protocol}",
            description='Observed packet in a saved capture. No vulnerability has been established by this observation.',
            source=row.source, destination=row.destination,
            protocol=row.protocol, timestamp=timestamp, evidence=tuple(details))
        self._show_plan_dialog(selected)

    def explore_traffic(self) -> None:
        """Readable capture evidence; report-only imports never invent packet details."""
        popup = tk.Toplevel(self)
        popup.title('JesterWire | Evidence Explorer')
        popup.geometry('1100x780')
        popup.configure(bg=BG)
        tk.Label(popup, text='EVIDENCE EXPLORER', bg=BG, fg=ACCENT,
                 font=('Segoe UI', 17, 'bold')).pack(anchor='w',padx=18,pady=(15,6))
        tk.Label(popup, text='Only information observed at this capture point. A connection is not proof of a vulnerability.',
                 bg=BG,fg=MUTED,font=('Segoe UI',10)).pack(anchor='w',padx=18,pady=(0,12))
        notebook = ttk.Notebook(popup)
        notebook.pack(fill='both',expand=True,padx=17,pady=(0,16))
        def tab(name):
            f=tk.Frame(notebook,bg=SURFACE)
            notebook.add(f,text='  '+name+'  ')
            return f
        summary=tab('Summary')
        protocol_tab=tab('Protocol Breakdown')
        http_tab=tab('HTTP Messages')
        tcp_tab=tab('TCP Connections')
        dns_tab=tab('DNS Discovery')
        from tkinter.scrolledtext import ScrolledText
        def text_area(parent, editable=False):
            widget=ScrolledText(parent,bg=SURFACE,fg=TEXT,insertbackground=TEXT,
                    font=('Consolas',10),wrap='word',relief='flat',padx=16,pady=12)
            widget.pack(fill='both',expand=True)
            return widget
        info = text_area(summary)
        counts=Counter(f.category for f in self.findings)
        old=(self.mode=='REPORT REVIEW')
        http_rows=(self.loaded_summary.get('http',[]) if old else self.detector.http_observations)
        tcp_rows=(self.loaded_summary.get('tcp',[]) if old else list(self.detector.tcp_flows.values()))
        dns_rows=(self.loaded_summary.get('dns',[]) if old else self.detector.dns_observations)
        protocols = (self.loaded_summary.get('protocols', {}) if old else dict(self.detector.protocol_counts))
        top_peers = (self.loaded_summary.get('peers', {}) if old else dict(self.detector.peer_counts))
        lines=[f'Capture mode: {self.mode}', f'Packets reviewed: {self.packet_count:,}',
               f'Associated PCAP: {self.active_pcap_path or "Not available (JSON/demo has no original packets)"}',
               f'HTTP messages with retained metadata: {len(http_rows):,}',
               f'TCP conversations with retained metadata: {len(tcp_rows):,}',
               f'DNS observations with retained metadata: {len(dns_rows):,}',
               '', 'FINDINGS (NOT PROVEN VULNERABILITIES)']
        lines += [f'  {key}: {counts[key]}' for key in sorted(counts)]
        if old and not http_rows and not tcp_rows:
            lines += ['', 'IMPORTANT: This older JSON stores FINDINGS ONLY.',
                      'It does not contain packets or reconstructed HTTP headers.',
                      'To see real conversations, open an ORIGINAL PCAP in TShark Explorer.',
                      'A prior JSON cannot be reconstructed retroactively.']
        else:
            lines += ['', 'HOW TO INTERPRET THIS',
                      'HTTP Messages: which client contacted which server, method, safe route, header names.',
                      'TCP Connections: who communicated, volume and observed TCP handshake flags.',
                      'DNS Discovery: names requested, not proof of an active service.',
                      'Missing HTTP content may mean HTTPS, unsupported HTTP/2, or capture gaps.',
                      'Most modern web login traffic is encrypted. This tool does not decrypt it.']
        lines += ['', 'AUTHORIZED TEST NEXT STEPS',
                  '1. Establish written scope: permitted hosts, dates, methods.',
                  '2. Identify the particular asset you control in the TCP Connections tab.',
                  '3. Perform a non-destructive targeted validation on that owned asset.',
                  '4. Compare observed ports against expected services and configuration.',
                  '5. Run the Build Pentest Plan workflow for any confirmed exposure.',
                  '', 'Note: This app does not claim that passive traffic analysis is exploitation.']
        info.insert('1.0','\n'.join(lines)); info.configure(state='disabled')
        proto=text_area(protocol_tab)
        proto_lines=['ALL CAPTURED PACKETS, INCLUDING ONES THAT GENERATED NO FINDINGS',
            f'Total: {self.packet_count:,} packets',
            '', 'PROTOCOL GROUPS (heuristic port-based hints, not service proof)']
        if protocols:
            for name,count in sorted(protocols.items(),key=lambda x:-int(x[1])):
                fraction=100*int(count)/max(1,self.packet_count)
                proto_lines.append(f'{name}: {int(count):,} packets ({fraction:.1f}%)')
        else:
            proto_lines.append('Not available. Legacy JSON reports do not contain every packet.')
        proto_lines+=['', 'TOP TALKERS (source IP by packets seen)']
        if top_peers:
            for peer,count in sorted(top_peers.items(),key=lambda x:-int(x[1]))[:30]:
                proto_lines.append(f'{peer}: {int(count):,}')
        else:
            proto_lines.append('No per-host protocol information saved.')
        proto_lines+=['', 'NOTE: Port 443 suggests TLS/HTTPS/QUIC, but this does not prove the application protocol.',
            'Encrypted web traffic will not appear as reconstructed HTTP/1.x.',
            'A normal switched LAN interface cannot see every other device’s unicast connections.']
        proto.insert('1.0','\n'.join(proto_lines));proto.configure(state='disabled')

        # HTTP metadata table: reconstructed HTTP requests and responses, not secrets.
        columns=('time','type','source','destination','what','segments')
        ht=ttk.Treeview(http_tab,columns=columns,show='headings',height=13,style='Dark.Treeview')
        labels={'time':('TIME',83),'type':('TYPE',82),'source':('SOURCE',180),
                'destination':('DESTINATION',180),'what':('METHOD / ROUTE / STATUS',320),'segments':('SEGMENTS',95)}
        for key,(label,width) in labels.items():
            ht.heading(key,text=label); ht.column(key,width=width,minwidth=70)
        ht.pack(fill='both',expand=True,padx=8,pady=(8,0))
        detail_text=ScrolledText(http_tab,bg=SURFACE2,fg=TEXT,font=('Consolas',10),height=10,wrap='word',padx=12,pady=10)
        detail_text.pack(fill='both',expand=False,padx=8,pady=(8,8))
        for i,r in enumerate(http_rows[:750]):
            if not isinstance(r,dict):continue
            desc=(str(r.get('method',''))+' '+str(r.get('route',''))) if r.get('type')=='Request' else 'HTTP '+str(r.get('status',''))
            ht.insert('','end',iid=str(i),values=(r.get('time',''),r.get('type',''),
                f"{r.get('source','')}:{r.get('source_port','')}",f"{r.get('destination','')}:{r.get('destination_port','')}",desc,r.get('segments',0)))
        def on_http(_event=None):
            sel=ht.selection()
            if not sel:return
            r=http_rows[int(sel[0])]
            fields=[f"{key.replace('_',' ').title()}: {r.get(key,'')}" for key in
                ('time','type','method','route','status','source','source_port','destination','destination_port','content_type','segments','body_bytes_seen','body_complete','cookie_header','set_cookie_header','authorization_header')]
            fields+=['Header NAMES only: '+', '.join(r.get('header_names',[])),
                     '', 'Header/body values are not retained. HTTP messages are NOT evidence of an exploit.',
                     'Use test credentials and owned services to validate any suspected exposure.']
            detail_text.configure(state='normal');detail_text.delete('1.0','end');detail_text.insert('1.0','\n'.join(fields));detail_text.configure(state='disabled')
        ht.bind('<<TreeviewSelect>>',on_http)
        if http_rows:
            ht.selection_set('0');on_http()
        else:
            detail_text.insert('1.0','No HTTP message metadata available. Open an original PCAP, or try examples/synthetic_split_login.pcap.\n\nHTTPS packets normally cannot reveal HTTP payloads, even when their TCP conversations are visible.')
            detail_text.configure(state='disabled')

        tt=text_area(tcp_tab)
        sorted_flows=sorted((r for r in tcp_rows if isinstance(r,dict)),key=lambda r:-int(r.get('packets',0)))
        tcp_lines=['TCP CONNECTIONS (observed, not proof ports are open)','','Top connections by number of observed packets:']
        for r in sorted_flows[:130]:
            service=SERVICE_HINTS.get(r.get('target_port'),'unknown')
            flags=f"SYN {r.get('syn',0)} / SYN-ACK {r.get('syn_ack',0)} / RST {r.get('rst',0)} / FIN {r.get('fin',0)}"
            tcp_lines += [f"{r.get('a')}:{r.get('a_port')} <-> {r.get('b')}:{r.get('b_port')}",
                          f"    {r.get('packets',0)} packets | {r.get('payload_bytes',0)} payload bytes | {flags}",
                          f"    Initial SYN target: {r.get('target')}:{r.get('target_port')} | port hint: {service}", '']
        if not sorted_flows:
            tcp_lines += ['No individual flow data was saved. Legacy reports cannot recreate these from their findings.']
        tt.insert('1.0','\n'.join(tcp_lines));tt.configure(state='disabled')

        dd=text_area(dns_tab)
        dns_lines=['DNS / SERVICE-DISCOVERY REQUESTS','','Observed names (not proof the service exists):','']
        if dns_rows:
            dns_lines += [f"{r['domain']} | observations {r['count']} | sources: {r['sources']}" for r in grouped_dns(dns_rows)[:500]]
        else:
            legacy=summarize_legacy_findings([f.to_dict() for f in self.findings])
            dns_lines += [f'{name} | {count} saved finding(s)' for name,count in legacy['domains'].most_common(200)]
            if not legacy['domains']:dns_lines.append('No DNS data available.')
        dd.insert('1.0','\n'.join(dns_lines));dd.configure(state='disabled')

        # Single-port validation is explicit and non-destructive, with no port sweeps.
        lab=tab('Lab Port Check')
        wrap=tk.Frame(lab,bg=SURFACE);wrap.pack(anchor='nw',fill='x',padx=18,pady=18)
        tk.Label(wrap,text='ACTIVE VALIDATION - ONE TCP PORT',bg=SURFACE,fg=ACCENT,
                 font=('Segoe UI',13,'bold')).pack(anchor='w',pady=(0,12))
        tk.Label(wrap,text='Checks whether a single permitted local/private lab TCP endpoint accepts a connection.\n'
            'This is not vulnerability exploitation or a service fingerprint. Never test a third-party device without permission.',
            justify='left',bg=SURFACE,fg=TEXT,font=('Segoe UI',10)).pack(anchor='w')
        host=tk.StringVar(value='127.0.0.1');port=tk.StringVar(value='8000')
        controls=tk.Frame(wrap,bg=SURFACE);controls.pack(anchor='w',pady=14)
        for name,var,width in [('Target IP',host,22),('TCP port',port,8)]:
            tk.Label(controls,text=name,bg=SURFACE,fg=MUTED,font=('Segoe UI',10)).pack(side='left',padx=(0,8))
            tk.Entry(controls,textvariable=var,width=width,bg=SURFACE2,fg=TEXT,insertbackground=TEXT).pack(side='left',padx=(0,22),ipady=6)
        agree=tk.BooleanVar(value=False)
        tk.Checkbutton(wrap,text='I own this host or have explicit permission to test this IP and port',
            variable=agree,bg=SURFACE,fg=TEXT,activebackground=SURFACE,activeforeground=TEXT,
            selectcolor=SURFACE2).pack(anchor='w',pady=8)
        results=tk.StringVar(value='No test run.')
        def check():
            if not agree.get():
                results.set('Please confirm authorization first.');return
            try:
                addr=ipaddress.ip_address(host.get().strip())
                portnum=int(port.get())
                if addr.version!=4 or not (addr.is_private or addr.is_loopback) or not 1<=portnum<=65535:
                    raise ValueError('Use an explicit IPv4 private or loopback address and a TCP port from 1 to 65535.')
            except ValueError as exc:
                results.set('Invalid target: '+str(exc));return
            results.set('Attempting a single TCP connection...')
            def job():
                try:
                    with socket.create_connection((str(addr),portnum),timeout=2):
                        result='TCP connection accepted. This alone does not establish what service is running or whether it is vulnerable.'
                except (OSError,TimeoutError) as exc:
                    result='TCP connection not established ('+str(exc)[:100]+'). Filtered or closed cannot be distinguished reliably here.'
                popup.after(0,lambda:results.set(result) if popup.winfo_exists() else None)
            threading.Thread(target=job,daemon=True).start()
        self._make_button(wrap,'Run Single-Port Check',check,accent=True).pack(anchor='w',pady=8)
        tk.Label(wrap,textvariable=results,wraplength=800,justify='left',bg=SURFACE,fg=YELLOW,
            font=('Segoe UI',10)).pack(anchor='w',pady=10)

    def show_adapter_info(self) -> None:
        selected = self.interface_choices.get(self.interface_var.get())
        if not selected:
            messagebox.showinfo("JesterWire | Adapter", "Select an adapter first. If none appear, check Scapy and Npcap.")
            return
        messagebox.showinfo("JesterWire | Adapter Information", adapter_explanation(selected))

    def open_overview_plan(self) -> None:
        self._show_plan_dialog(None)

    def open_plan(self) -> None:
        # If no row is selected, produce an entire-report plan instead of
        # showing a dead-end message box.
        selected = (self.findings[self.selected_index]
                    if self.selected_index is not None and self.selected_index < len(self.findings)
                    else None)
        self._show_plan_dialog(selected)

    def _show_plan_dialog(self, finding: Finding | None) -> None:
        popup = tk.Toplevel(self)
        popup.title("JesterWire | Build Pentest Plan" + (" | Selected Finding" if finding else " | Full Report"))
        popup.geometry("850x700")
        popup.configure(bg=BG)
        tk.Label(popup, text="PENTEST ASSESSMENT | " + ("SELECTED FINDING" if finding else "FULL REPORT"), bg=BG, fg=ACCENT,
                 font=("Segoe UI", 14, "bold")).pack(anchor="w", padx=20, pady=(18, 10))
        phasebar = tk.Frame(popup, bg=BG)
        phasebar.pack(fill="x", padx=20, pady=(0, 10))
        self._make_text(phasebar, "Testing phase:", 10, MUTED).pack(side="left", padx=(0, 10))
        phase_var = tk.StringVar(value="Internal")
        phase = ttk.Combobox(phasebar, textvariable=phase_var,
                             values=("External", "Internal", "Lab"), width=18,
                             state="readonly", style="Dark.TCombobox")
        phase.pack(side="left")
        self._make_text(phasebar, "External = passive outside-in recon", 9, MUTED).pack(side="left", padx=(12, 0))
        viewer = tk.Text(popup, bg=SURFACE, fg=TEXT, wrap="word", relief="flat", bd=0,
                         padx=16, pady=16, font=("Consolas", 10))
        viewer.pack(fill="both", expand=True, padx=20)
        elaborate = tk.BooleanVar(value=False)

        def content() -> str:
            if finding is not None:
                return build_plan(finding, stage=phase_var.get(), elaborate=elaborate.get())
            adapter = self.interface_choices.get(self.interface_var.get())
            return build_overview_plan(self.findings, stage=phase_var.get(), elaborate=elaborate.get(),
                                       packet_count=self.packet_count, adapter=adapter.medium if adapter else "Unknown")

        def refresh(_event: Any = None) -> None:
            viewer.configure(state="normal")
            viewer.delete("1.0", "end")
            viewer.insert("1.0", content())
            viewer.configure(state="disabled")

        phase.bind("<<ComboboxSelected>>", refresh)
        refresh()
        bar = tk.Frame(popup, bg=BG)
        bar.pack(fill="x", padx=20, pady=16)

        def toggle_elaborate() -> None:
            elaborate.set(not elaborate.get())
            elaborate_button.configure(text="Hide Details" if elaborate.get() else "Elaborate Techniques")
            refresh()

        def save() -> None:
            dest = filedialog.asksaveasfilename(parent=popup, defaultextension=".md",
                                                filetypes=[("Markdown", "*.md"), ("Text", "*.txt")])
            if dest:
                try:
                    with open(dest, "w", encoding="utf-8") as file:
                        file.write(content())
                    messagebox.showinfo("Saved", "Assessment plan saved.", parent=popup)
                except OSError as exc:
                    messagebox.showerror("Save failed", str(exc), parent=popup)

        def copy() -> None:
            self.clipboard_clear()
            self.clipboard_append(content())
            messagebox.showinfo("Copied", "Assessment plan copied to clipboard.", parent=popup)

        elaborate_button = self._make_button(bar, "Elaborate Techniques", toggle_elaborate, accent=True)
        elaborate_button.pack(side="left", padx=(0, 8))
        self._make_button(bar, "Copy Plan", copy).pack(side="left", padx=(0, 8))
        self._make_button(bar, "Save Markdown", save).pack(side="left")

    def export_report(self) -> None:
        if not self.findings and not self.packet_count:
            messagebox.showinfo("No capture to export", "Load a demo, PCAP file, or live capture first.")
            return
        path = filedialog.asksaveasfilename(title="Export findings JSON", defaultextension=".json",
                                            filetypes=[("JSON report", "*.json")])
        if not path:
            return
        report = {
            "application": "JesterWire", "version": "0.7", "mode": self.mode,
            "exported_at": datetime.now().astimezone().isoformat(),
            "packet_count": self.packet_count,
            "pcap_filename": Path(self.active_pcap_path).name if self.active_pcap_path else None,
            "pcap_note": "A JSON report does not contain any raw packet data; the PCAP must be saved separately.",
            "protocol_counts": self.loaded_summary.get('protocols',{}) if self.mode == 'REPORT REVIEW' else dict(self.detector.protocol_counts),
            "peer_counts": self.loaded_summary.get('peers',{}) if self.mode == 'REPORT REVIEW' else dict(self.detector.peer_counts),
            "http_messages_reconstructed": self.detector.http_message_count if self.mode != "REPORT REVIEW" else None,
            "tcp_retransmissions_seen": self.detector.streams.retransmissions if self.mode != "REPORT REVIEW" else None,
            "tcp_out_of_order_segments": self.detector.streams.out_of_order if self.mode != "REPORT REVIEW" else None,
            "tcp_flow_buffers_dropped": self.detector.streams.dropped_flows if self.mode != "REPORT REVIEW" else None,
            "categories": dict(Counter(f.category for f in self.findings)),
            "adapter": self.interface_choices[self.interface_var.get()].medium if self.interface_var.get() in self.interface_choices else "Unknown",
            "notice": "Heuristic analysis. Sensitive values deliberately redacted. Authorized use only.",
            "findings": [finding.to_dict() for finding in self.findings],
            "http_observations": self.loaded_summary.get('http',[]) if self.mode == 'REPORT REVIEW' else self.detector.http_observations,
            "tcp_flows": self.loaded_summary.get('tcp',[]) if self.mode == 'REPORT REVIEW' else list(self.detector.tcp_flows.values()),
            "dns_observations": self.loaded_summary.get('dns',[]) if self.mode == 'REPORT REVIEW' else self.detector.dns_observations,
        }
        try:
            with open(path, "w", encoding="utf-8") as handle:
                json.dump(report, handle, indent=2, ensure_ascii=False)
            self.status.configure(text="Findings summary exported; PCAP not included.")
        except OSError as exc:
            messagebox.showerror("Export failed", str(exc))

    def show_credits(self) -> None:
        messagebox.showinfo("JesterWire | Credits",
            "JESTERWIRE  v0.7\nProject Star Gazer\n\n"
            "Architect: Jester\n"
            "Coder: ChatGPT (OpenAI)\n\n"
            "A beginner-friendly packet-analysis and authorized security review tool.\n\n"
            "Built for learning, visibility, and defense.\n"
            "Only inspect networks, endpoints, or captures you're authorized to analyze.")

    def _on_close(self) -> None:
        if self.capture_stopping:
            messagebox.showinfo("Finishing capture", "The PCAP is being finalized. Close again after the capture has stopped.")
            return
        if self.sniffer and self.sniffer.running:
            messagebox.showinfo("Save PCAP first", "Stop the live capture before closing so the PCAP is finalized correctly.")
            return
        if self.capture_writer:
            try:
                self.capture_writer.close()
            except Exception:
                pass
        self.destroy()


if __name__ == "__main__":
    app = JesterWireApp()
    app.mainloop()
